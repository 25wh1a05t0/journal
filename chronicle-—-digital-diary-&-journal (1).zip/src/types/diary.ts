/**
 * Types and interfaces for Chronicle — Digital Diary & Journal
 */

export type DiarySection =
  | 'calendar'
  | 'planner'
  | 'diary'
  | 'scrapbook'
  | 'sanctuary'
  | 'garden'
  | 'settings';

export type DrawingTool = 'pen' | 'pencil' | 'highlighter' | 'eraser';

export interface StrokePoint {
  x: number;
  y: number;
  pressure?: number;
}

export interface HandwritingStroke {
  tool: DrawingTool;
  color: string;
  width: number;
  points: StrokePoint[];
}

export interface DiaryEntry {
  date: string; // YYYY-MM-DD
  strokes: HandwritingStroke[];
  typedText: string;
  writingPrompt?: string;
  gratitudes?: [string, string, string];
  mood?: string;
  updatedAt: number;
}

export interface PriorityItem {
  id: string;
  text: string;
  done: boolean;
  level: 'high' | 'med' | 'low';
}

export interface TaskItem {
  id: string;
  text: string;
  done: boolean;
  category?: string;
}

export interface HourlyEvent {
  id: string;
  time: string; // e.g. "08:00 AM"
  title: string;
  category?: string;
}

export interface PlannerData {
  date: string;
  intention: string;
  priorities: PriorityItem[];
  tasks: TaskItem[];
  hourlyEvents: HourlyEvent[];
  notes: string;
}

export type CoverTheme =
  | 'espresso'
  | 'sage'
  | 'navy'
  | 'terracotta'
  | 'charcoal'
  | 'plum'
  | 'pastel_matcha'
  | 'pastel_rose'
  | 'pastel_lavender'
  | 'pastel_peach'
  | 'pastel_sky'
  | 'ivory';

export type PaperTone = 'cream' | 'chamois' | 'linen' | 'sage';
export type RulingType = 'ruled' | 'dotted' | 'blank';

export interface UserSettings {
  authorName: string;
  coverTheme: CoverTheme;
  paperTone: PaperTone;
  rulingType: RulingType;
  audioEnabled: boolean;
  isLocked: boolean;
  pinCode?: string;
  activePromptIndex?: number;
}

export type StickerType =
  | 'botanical'
  | 'stamp'
  | 'wax_seal'
  | 'washi_tape'
  | 'dried_flower'
  | 'emoji';

export type CollageLayout = 'freeform' | 'duo' | 'triptych' | 'grid4' | 'herbarium';

export interface ScrapbookItem {
  id: string;
  type: 'photo' | 'sticker' | 'caption';
  src?: string;
  caption?: string;
  stickerType?: StickerType;
  emojiChar?: string;
  x: number; // percentage
  y: number; // percentage
  width: number; // px or %
  rotation: number; // degrees
  cropAspect?: 'square' | 'portrait' | 'landscape' | 'circle' | 'original';
  zoom?: number;
  cropPanX?: number; // -50% to 50%
  cropPanY?: number; // -50% to 50%
  tapeStyle?: 'washi' | 'pin' | 'clip' | 'none';
  zIndex?: number;
}

export interface ScrapbookPageData {
  date: string;
  layout?: CollageLayout;
  items: ScrapbookItem[];
  drawingStrokes?: HandwritingStroke[];
  note?: string;
}

export interface AffirmationItem {
  id: string;
  text: string;
  theme: 'calm' | 'strength' | 'gentleness' | 'gratitude' | 'clarity' | 'growth' | 'solace';
  emoji?: string;
  isCustom?: boolean;
  isSaved?: boolean;
}

export interface WishItem {
  id: string;
  wish: string;
  createdDate: string;
  category: 'dream' | 'growth' | 'peace' | 'connection';
  emoji: string;
  fulfilled: boolean;
  starColor: string;
}

export type MoodType = 'peaceful' | 'joyful' | 'reflective' | 'tender' | 'fatigued' | 'starlit';

export interface MoodRecord {
  date: string;
  mood: MoodType;
  flowerType: 'lavender' | 'camellia' | 'fern' | 'sunflower' | 'moss_rose' | 'lily' | 'sakura' | 'moonflower' | 'wisteria' | 'marigold';
  reflection?: string;
}
