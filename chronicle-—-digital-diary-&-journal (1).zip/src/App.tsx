/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback } from 'react';
import { DiarySection, DiaryEntry, PlannerData, ScrapbookPageData, UserSettings, AffirmationItem, WishItem, MoodRecord } from './types/diary';
import {
  getTodayDateString,
  addDaysToDate,
  loadUserSettings,
  saveUserSettings,
  loadAllDiaryEntries,
  saveDiaryEntry,
  loadPlannerForDate,
  savePlannerForDate,
  loadScrapbookForDate,
  saveScrapbookForDate,
  loadWishes,
  saveWishes,
  loadAffirmations,
  saveAffirmations,
  loadMoodRecords,
  saveMoodRecords,
} from './utils/storage';
import { playPageTurnSound, playChimeSound } from './utils/audio';
import { TopNav } from './components/TopNav';
import { BookContainer } from './components/BookContainer';
import { CalendarSpread } from './components/CalendarSpread';
import { DearDiarySpread } from './components/DearDiarySpread';
import { PlannerSpread } from './components/PlannerSpread';
import { ScrapbookSpread } from './components/ScrapbookSpread';
import { SanctuarySpread } from './components/SanctuarySpread';
import { MoodGardenSpread } from './components/MoodGardenSpread';
import { VaultSettingsSpread } from './components/VaultSettingsSpread';
import { ClosingRitualModal } from './components/ClosingRitualModal';
import { LockScreen } from './components/LockScreen';
import { getThemeAesthetic } from './utils/theme';

export default function App() {
  const [selectedDate, setSelectedDate] = useState<string>(getTodayDateString());
  const [currentSection, setCurrentSection] = useState<DiarySection>('calendar');
  // Settings
  const [settings, setSettings] = useState<UserSettings>(loadUserSettings);
  const [isUnlocked, setIsUnlocked] = useState<boolean>(!settings.isLocked);
  const [isBookClosed, setIsBookClosed] = useState<boolean>(Boolean(settings.isLocked));
  const [showLockScreen, setShowLockScreen] = useState<boolean>(false);
  const [saveStatus, setSaveStatus] = useState<'saved' | 'saving'>('saved');
  const [isTurningPage, setIsTurningPage] = useState<boolean>(false);
  const [isClosingRitualOpen, setIsClosingRitualOpen] = useState<boolean>(false);

  // Data collections
  const [entries, setEntries] = useState<Record<string, DiaryEntry>>(loadAllDiaryEntries);
  const [plannerMap, setPlannerMap] = useState<Record<string, PlannerData>>({});
  const [scrapbookMap, setScrapbookMap] = useState<Record<string, ScrapbookPageData>>({});
  const [wishes, setWishes] = useState<WishItem[]>(loadWishes);
  const [affirmations, setAffirmations] = useState<AffirmationItem[]>(loadAffirmations);
  const [moods, setMoods] = useState<Record<string, MoodRecord>>(loadMoodRecords);

  // Load date-specific data
  useEffect(() => {
    if (!plannerMap[selectedDate]) {
      const data = loadPlannerForDate(selectedDate);
      setPlannerMap((prev) => ({ ...prev, [selectedDate]: data }));
    }
    if (!scrapbookMap[selectedDate]) {
      const data = loadScrapbookForDate(selectedDate);
      setScrapbookMap((prev) => ({ ...prev, [selectedDate]: data }));
    }
  }, [selectedDate, plannerMap, scrapbookMap]);

  // Page turn transition trigger
  const triggerPageFlip = useCallback(() => {
    setIsTurningPage(true);
    if (settings.audioEnabled) {
      playPageTurnSound(true);
    }
    setTimeout(() => {
      setIsTurningPage(false);
    }, 450);
  }, [settings.audioEnabled]);

  // Section switcher
  const handleSelectSection = (sec: DiarySection) => {
    if (isBookClosed && settings.isLocked && !isUnlocked) {
      setShowLockScreen(true);
      return;
    }
    if (currentSection !== sec) {
      triggerPageFlip();
      setCurrentSection(sec);
    }
    if (isBookClosed) {
      setIsBookClosed(false);
    }
  };

  // Open book handler - prompts for PIN if diary is protected
  const handleOpenBook = () => {
    if (settings.isLocked && !isUnlocked) {
      setShowLockScreen(true);
    } else {
      if (settings.audioEnabled) playPageTurnSound(true);
      setIsBookClosed(false);
      setCurrentSection('calendar');
    }
  };

  // Unlock handler when PIN is entered correctly
  const handleUnlock = () => {
    setIsUnlocked(true);
    setShowLockScreen(false);
    setIsBookClosed(false);
    setCurrentSection('calendar');
    if (settings.audioEnabled) playPageTurnSound(true);
  };

  // Date navigation
  const handleSelectDate = (date: string) => {
    if (date !== selectedDate) {
      triggerPageFlip();
      setSelectedDate(date);
    }
  };

  const handlePrevDay = () => {
    const prev = addDaysToDate(selectedDate, -1);
    handleSelectDate(prev);
  };

  const handleNextDay = () => {
    const next = addDaysToDate(selectedDate, 1);
    handleSelectDate(next);
  };

  // Book cover toggling - locks diary when closing
  const handleToggleBookCover = () => {
    if (settings.audioEnabled) {
      playPageTurnSound(true);
    }
    if (isBookClosed) {
      // Opening book: verify PIN if locked
      if (settings.isLocked && !isUnlocked) {
        setShowLockScreen(true);
        return;
      }
      setIsBookClosed(false);
    } else {
      // Closing book: relock so PIN is required next time
      if (settings.isLocked) {
        setIsUnlocked(false);
      }
      setIsBookClosed(true);
    }
  };

  // Save Handlers
  const handleSaveDiaryEntry = (entry: DiaryEntry) => {
    setSaveStatus('saving');
    setEntries((prev) => ({ ...prev, [entry.date]: entry }));
    saveDiaryEntry(entry);
    setTimeout(() => setSaveStatus('saved'), 350);
  };

  const handleSavePlannerData = (data: PlannerData) => {
    setSaveStatus('saving');
    setPlannerMap((prev) => ({ ...prev, [data.date]: data }));
    savePlannerForDate(data);
    setTimeout(() => setSaveStatus('saved'), 350);
  };

  const handleSaveScrapbookData = (data: ScrapbookPageData) => {
    setSaveStatus('saving');
    setScrapbookMap((prev) => ({ ...prev, [data.date]: data }));
    saveScrapbookForDate(data);
    setTimeout(() => setSaveStatus('saved'), 350);
  };

  const handleSaveWishes = (items: WishItem[]) => {
    setSaveStatus('saving');
    setWishes(items);
    saveWishes(items);
    setTimeout(() => setSaveStatus('saved'), 350);
  };

  const handleSaveAffirmations = (items: AffirmationItem[]) => {
    setSaveStatus('saving');
    setAffirmations(items);
    saveAffirmations(items);
    setTimeout(() => setSaveStatus('saved'), 350);
  };

  const handleSaveMood = (record: MoodRecord) => {
    setSaveStatus('saving');
    const updated = { ...moods, [record.date]: record };
    setMoods(updated);
    saveMoodRecords(updated);
    setTimeout(() => setSaveStatus('saved'), 350);
  };

  const handleSaveSettings = (newSettings: UserSettings) => {
    setSettings(newSettings);
    saveUserSettings(newSettings);
  };

  // Archival Export & Import
  const handleExportData = () => {
    const fullBackup = {
      settings,
      entries,
      plannerMap,
      scrapbookMap,
      wishes,
      affirmations,
      moods,
      exportedAt: new Date().toISOString(),
    };
    const jsonStr = JSON.stringify(fullBackup, null, 2);
    const blob = new Blob([jsonStr], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `chronicle-diary-backup-${selectedDate}.json`;
    a.click();
    URL.revokeObjectURL(url);
    if (settings.audioEnabled) playChimeSound(true);
  };

  const handleImportData = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (event) => {
      try {
        const parsed = JSON.parse(event.target?.result as string);
        if (parsed.settings) setSettings(parsed.settings);
        if (parsed.entries) setEntries(parsed.entries);
        if (parsed.plannerMap) setPlannerMap(parsed.plannerMap);
        if (parsed.scrapbookMap) setScrapbookMap(parsed.scrapbookMap);
        if (parsed.wishes) setWishes(parsed.wishes);
        if (parsed.affirmations) setAffirmations(parsed.affirmations);
        if (parsed.moods) setMoods(parsed.moods);
        alert('Diary restored successfully.');
      } catch {
        alert('Invalid backup file.');
      }
    };
    reader.readAsText(file);
  };

  // Current active date items
  const currentEntry: DiaryEntry = entries[selectedDate] || {
    date: selectedDate,
    strokes: [],
    typedText: '',
    gratitudes: ['', '', ''],
    updatedAt: Date.now(),
  };

  const currentPlanner: PlannerData = plannerMap[selectedDate] || loadPlannerForDate(selectedDate);
  const currentScrapbook: ScrapbookPageData =
    scrapbookMap[selectedDate] || loadScrapbookForDate(selectedDate);

  const paperToneClass =
    settings.paperTone === 'chamois'
      ? 'paper-chamois'
      : settings.paperTone === 'linen'
      ? 'paper-linen'
      : settings.paperTone === 'sage'
      ? 'paper-sage'
      : 'paper-cream';

  const themeAesthetic = getThemeAesthetic(settings.coverTheme);

  return (
    <div
      className="h-screen max-h-screen w-screen overflow-hidden flex flex-col relative font-sans select-none transition-colors duration-500"
      style={{ backgroundColor: themeAesthetic.appBg }}
    >
      {/* Privacy Lock Screen if active and required */}
      {showLockScreen && (
        <LockScreen
          correctPin={settings.pinCode || '0000'}
          onUnlock={handleUnlock}
          onCancel={() => setShowLockScreen(false)}
          audioEnabled={settings.audioEnabled}
        />
      )}

      {/* Top Floating Island Navigation Bar */}
      <TopNav
        currentSection={currentSection}
        onSelectSection={handleSelectSection}
        selectedDate={selectedDate}
        onSelectDate={handleSelectDate}
        onPrevDay={handlePrevDay}
        onNextDay={handleNextDay}
        isBookClosed={isBookClosed}
        onToggleBookCover={handleToggleBookCover}
        saveStatus={saveStatus}
        onOpenClosingRitual={() => setIsClosingRitualOpen(true)}
        coverTheme={settings.coverTheme}
      />

      {/* Main Centered Book Content Area - No window scroll */}
      <main className="flex-1 min-h-0 w-full overflow-hidden flex items-center justify-center relative p-1 sm:p-2">
        <BookContainer
          isBookClosed={isBookClosed}
          onOpenBook={handleOpenBook}
          coverTheme={settings.coverTheme || 'sage'}
          onChangeCoverTheme={(t) => handleSaveSettings({ ...settings, coverTheme: t })}
          paperTone={settings.paperTone}
          authorName={settings.authorName}
          isTurningPage={isTurningPage}
        >
          {/* Section 1: Monthly Calendar Spread */}
          {currentSection === 'calendar' && (
            <CalendarSpread
              selectedDate={selectedDate}
              onSelectDate={handleSelectDate}
              onOpenDaySection={(sec) => {
                triggerPageFlip();
                setCurrentSection(sec);
              }}
              entries={entries}
              plannerDataMap={plannerMap}
              scrapbookDataMap={scrapbookMap}
              moodsMap={moods}
              paperToneClass={paperToneClass}
            />
          )}

          {/* Section 2: Flagship Dear Diary with Natural Stylus Handwriting */}
          {currentSection === 'diary' && (
            <DearDiarySpread
              date={selectedDate}
              entry={currentEntry}
              onSaveEntry={handleSaveDiaryEntry}
              audioEnabled={settings.audioEnabled}
              rulingType={settings.rulingType}
              paperToneClass={paperToneClass}
            />
          )}

          {/* Section 3: Daily Planner Spread */}
          {currentSection === 'planner' && (
            <PlannerSpread
              date={selectedDate}
              data={currentPlanner}
              onSaveData={handleSavePlannerData}
              onOpenDiary={() => {
                triggerPageFlip();
                setCurrentSection('diary');
              }}
              paperToneClass={paperToneClass}
            />
          )}

          {/* Section 4: Scrapbook Spread */}
          {currentSection === 'scrapbook' && (
            <ScrapbookSpread
              date={selectedDate}
              data={currentScrapbook}
              onSaveData={handleSaveScrapbookData}
              paperToneClass={paperToneClass}
            />
          )}

          {/* Section 5: Sanctuary (Emotion Jar & Wish Jar) */}
          {currentSection === 'sanctuary' && (
            <SanctuarySpread
              affirmations={affirmations}
              onSaveAffirmations={handleSaveAffirmations}
              wishes={wishes}
              onSaveWishes={handleSaveWishes}
              audioEnabled={settings.audioEnabled}
              paperToneClass={paperToneClass}
            />
          )}

          {/* Section 6: Mood Garden */}
          {currentSection === 'garden' && (
            <MoodGardenSpread
              selectedDate={selectedDate}
              moodRecords={moods}
              onSaveMood={handleSaveMood}
              audioEnabled={settings.audioEnabled}
              paperToneClass={paperToneClass}
            />
          )}

          {/* Section 7: Vault & Settings */}
          {currentSection === 'settings' && (
            <VaultSettingsSpread
              settings={settings}
              onSaveSettings={handleSaveSettings}
              onExportData={handleExportData}
              onImportData={handleImportData}
              paperToneClass={paperToneClass}
            />
          )}
        </BookContainer>
      </main>

      {/* Evening Closing Ritual Modal */}
      <ClosingRitualModal
        date={selectedDate}
        isOpen={isClosingRitualOpen}
        onClose={() => setIsClosingRitualOpen(false)}
        onCompleteRitualAndCloseBook={() => {
          setIsClosingRitualOpen(false);
          setIsBookClosed(true);
          if (settings.isLocked) {
            setIsUnlocked(false);
          }
        }}
        audioEnabled={settings.audioEnabled}
      />
    </div>
  );
}
