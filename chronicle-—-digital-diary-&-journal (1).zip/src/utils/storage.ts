/**
 * Persistent storage management with local storage and graceful defaults
 */

import {
  DiaryEntry,
  PlannerData,
  ScrapbookPageData,
  WishItem,
  AffirmationItem,
  MoodRecord,
  UserSettings,
} from '../types/diary';

// Pre-generated asset paths
export const COVER_IMAGE_URL = '/src/assets/images/journal_leather_cover_1793018511534.jpg';
export const TEA_PHOTO_URL = '/src/assets/images/scrapbook_autumn_tea_1793018512483.jpg';
export const MORNING_PHOTO_URL = '/src/assets/images/scrapbook_morning_light_1793018512878.jpg';
export const FERN_PHOTO_URL = '/src/assets/images/scrapbook_botanical_fern_1793018512578.jpg';

// Date utility functions
export function getTodayDateString(): string {
  const d = new Date();
  const year = d.getFullYear();
  const month = String(d.getMonth() + 1).padStart(2, '0');
  const day = String(d.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export function formatSerifDate(dateStr: string): string {
  try {
    const [y, m, d] = dateStr.split('-').map(Number);
    const date = new Date(y, m - 1, d);
    return date.toLocaleDateString('en-US', {
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric',
    });
  } catch {
    return dateStr;
  }
}

export function formatShortDate(dateStr: string): string {
  try {
    const [y, m, d] = dateStr.split('-').map(Number);
    const date = new Date(y, m - 1, d);
    return date.toLocaleDateString('en-US', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
    });
  } catch {
    return dateStr;
  }
}

export function addDaysToDate(dateStr: string, days: number): string {
  const [y, m, d] = dateStr.split('-').map(Number);
  const date = new Date(y, m - 1, d);
  date.setDate(date.getDate() + days);
  const year = date.getFullYear();
  const month = String(date.getMonth() + 1).padStart(2, '0');
  const day = String(date.getDate()).padStart(2, '0');
  return `${year}-${month}-${day}`;
}

export const WRITING_PROMPTS = [
  'What quiet moment brought you unexpected solace today?',
  'What is something you learned about yourself this week?',
  'Describe the atmosphere, light, and sounds of this morning.',
  'What burden are you gently releasing this evening?',
  'Who or what made you feel genuinely understood recently?',
  'Write a short letter to your future self three seasons from now.',
  'What are three gentle truths you want to remember tomorrow?',
];

// Default initial state
const DEFAULT_SETTINGS: UserSettings = {
  authorName: 'Eleanor',
  coverTheme: 'sage',
  paperTone: 'cream',
  rulingType: 'ruled',
  audioEnabled: true,
  isLocked: false,
};

const DEFAULT_AFFIRMATIONS: AffirmationItem[] = [
  { id: 'aff-1', text: 'You do not have to carry everything all at once. Just breathe.', theme: 'calm', emoji: '🌿', isSaved: true },
  { id: 'aff-2', text: 'Quiet progress is still profound progress.', theme: 'strength', emoji: '✨', isSaved: true },
  { id: 'aff-3', text: 'Allow yourself the grace of unhurried time.', theme: 'gentleness', emoji: '🌸', isSaved: false },
  { id: 'aff-4', text: 'Your peace is worth protecting with soft, firm boundaries.', theme: 'strength', emoji: '🕯️', isSaved: true },
  { id: 'aff-5', text: 'Even the longest winter yields to gentle green shoots.', theme: 'growth', emoji: '🌱', isSaved: false },
  { id: 'aff-6', text: 'Today holds room for stillness, beauty, and wonder.', theme: 'clarity', emoji: '🌙', isSaved: false },
  { id: 'aff-7', text: 'Be tender with yourself; you are doing your very best.', theme: 'gentleness', emoji: '🤍', isSaved: true },
];

const DEFAULT_WISHES: WishItem[] = [
  {
    id: 'wish-1',
    wish: 'To cultivate a quiet reading nook lined with cedar shelves and soft light.',
    createdDate: '2026-10-24',
    category: 'dream',
    emoji: '⭐',
    fulfilled: false,
    starColor: '#e0a96d',
  },
  {
    id: 'wish-2',
    wish: 'Walk slowly along the coast at dawn and listen to the waves without looking at a clock.',
    createdDate: '2026-10-25',
    category: 'peace',
    emoji: '🌙',
    fulfilled: false,
    starColor: '#7ba087',
  },
  {
    id: 'wish-3',
    wish: 'Learn the delicate art of botanical watercolor painting this winter.',
    createdDate: '2026-10-26',
    category: 'growth',
    emoji: '🌸',
    fulfilled: true,
    starColor: '#c27d88',
  },
];

// Helper to safely load / save from localStorage
function getStored<T>(key: string, defaultValue: T): T {
  try {
    const val = localStorage.getItem(key);
    if (!val) return defaultValue;
    return JSON.parse(val) as T;
  } catch {
    return defaultValue;
  }
}

function setStored<T>(key: string, value: T): void {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch (err) {
    console.error('Failed to save to localStorage:', err);
  }
}

// Storage Accessors
export function loadUserSettings(): UserSettings {
  return getStored<UserSettings>('chronicle_settings', DEFAULT_SETTINGS);
}

export function saveUserSettings(settings: UserSettings): void {
  setStored('chronicle_settings', settings);
}

export function loadAllDiaryEntries(): Record<string, DiaryEntry> {
  const stored = getStored<Record<string, DiaryEntry>>('chronicle_diary_entries', {});
  const today = getTodayDateString();
  if (!stored[today]) {
    stored[today] = {
      date: today,
      strokes: [
        // A gentle welcoming handwriting stroke flourish
        {
          tool: 'pen',
          color: '#25201b',
          width: 3,
          points: [
            { x: 50, y: 130 },
            { x: 58, y: 124 },
            { x: 70, y: 120 },
            { x: 92, y: 122 },
            { x: 110, y: 132 },
            { x: 125, y: 148 },
            { x: 132, y: 165 },
            { x: 128, y: 178 },
            { x: 112, y: 184 },
            { x: 88, y: 178 },
            { x: 72, y: 156 },
            { x: 84, y: 136 },
            { x: 115, y: 132 },
            { x: 148, y: 142 },
          ],
        },
      ],
      typedText:
        'The morning was crisp, with golden October sunlight casting long shadows across the wooden floor. I brewed a warm cup of chamomile tea with a slice of dried citrus and sat quietly by the window. There is a profound sweetness in mornings that demand nothing from you except being present.',
      gratitudes: [
        'The quiet warmth of early tea before the world awakes',
        'Autumn leaves gathering on the garden path',
        'Finding time to write with real presence',
      ],
      writingPrompt: 'What quiet moment brought you unexpected solace today?',
      mood: 'peaceful',
      updatedAt: Date.now(),
    };
  }
  return stored;
}

export function saveDiaryEntry(entry: DiaryEntry): void {
  const all = loadAllDiaryEntries();
  all[entry.date] = { ...entry, updatedAt: Date.now() };
  setStored('chronicle_diary_entries', all);
}

export function loadPlannerForDate(dateStr: string): PlannerData {
  const all = getStored<Record<string, PlannerData>>('chronicle_planner_data', {});
  if (all[dateStr]) return all[dateStr];

  // Provide initial template for the day
  const defaultPlanner: PlannerData = {
    date: dateStr,
    intention: 'Move with unhurried grace; nurture quiet focus and preserve peace.',
    priorities: [
      { id: 'p1', text: 'Morning stillness & chamomile tea reflection', done: true, level: 'high' },
      { id: 'p2', text: 'Writing in the journal with stylus & ink', done: false, level: 'high' },
      { id: 'p3', text: 'Evening stroll through the autumn pines', done: false, level: 'med' },
    ],
    tasks: [
      { id: 't1', text: 'Read two chapters of poetry by the window', done: true, category: 'Reading' },
      { id: 't2', text: 'Press wild fern fronds in vintage linen book', done: false, category: 'Craft' },
      { id: 't3', text: 'Tidy cedar writing desk & refill fountain pen ink', done: false, category: 'Home' },
      { id: 't4', text: 'Quiet breathing practice at sunset', done: false, category: 'Ritual' },
    ],
    hourlyEvents: [
      { id: 'h1', time: '08:00 AM', title: 'Morning tea & gentle stretching', category: 'Morning' },
      { id: 'h2', time: '10:00 AM', title: 'Deep writing & reflection session', category: 'Focus' },
      { id: 'h3', time: '02:00 PM', title: 'Botanical garden stroll & sketchbook', category: 'Creative' },
      { id: 'h4', time: '06:30 PM', title: 'Warm hearth dinner & tea', category: 'Evening' },
      { id: 'h5', time: '08:30 PM', title: 'Evening closing ritual & soft reading', category: 'Ritual' },
    ],
    notes: 'Remember to look up at the clouds at noon. Notice how the light changes on the bookshelf.',
  };
  return defaultPlanner;
}

export function savePlannerForDate(data: PlannerData): void {
  const all = getStored<Record<string, PlannerData>>('chronicle_planner_data', {});
  all[data.date] = data;
  setStored('chronicle_planner_data', all);
}

export function loadScrapbookForDate(dateStr: string): ScrapbookPageData {
  const all = getStored<Record<string, ScrapbookPageData>>('chronicle_scrapbook_data', {});
  if (all[dateStr]) return all[dateStr];

  // Default aesthetic scrapbook spread with curated polaroids
  const defaultScrapbook: ScrapbookPageData = {
    date: dateStr,
    items: [
      {
        id: 'sb-1',
        type: 'photo',
        src: TEA_PHOTO_URL,
        caption: 'Warm chamomile & morning reading',
        x: 14,
        y: 18,
        width: 44,
        rotation: -2.5,
      },
      {
        id: 'sb-2',
        type: 'photo',
        src: MORNING_PHOTO_URL,
        caption: 'Golden hour in the bedroom sanctuary',
        x: 52,
        y: 22,
        width: 42,
        rotation: 3,
      },
      {
        id: 'sb-3',
        type: 'sticker',
        stickerType: 'washi_tape',
        x: 18,
        y: 14,
        width: 24,
        rotation: -4,
      },
      {
        id: 'sb-4',
        type: 'sticker',
        stickerType: 'wax_seal',
        x: 78,
        y: 65,
        width: 14,
        rotation: 8,
      },
      {
        id: 'sb-5',
        type: 'photo',
        src: FERN_PHOTO_URL,
        caption: 'Herbarium Specimen — Lady Fern',
        x: 24,
        y: 56,
        width: 38,
        rotation: -1,
      },
    ],
    note: 'October collection of textures, quiet moments, and pressed memories.',
  };
  return defaultScrapbook;
}

export function saveScrapbookForDate(data: ScrapbookPageData): void {
  const all = getStored<Record<string, ScrapbookPageData>>('chronicle_scrapbook_data', {});
  all[data.date] = data;
  setStored('chronicle_scrapbook_data', all);
}

export function loadWishes(): WishItem[] {
  return getStored<WishItem[]>('chronicle_wishes', DEFAULT_WishesList());
}

function DEFAULT_WishesList(): WishItem[] {
  return DEFAULT_WISHES;
}

export function saveWishes(wishes: WishItem[]): void {
  setStored('chronicle_wishes', wishes);
}

export function loadAffirmations(): AffirmationItem[] {
  return getStored<AffirmationItem[]>('chronicle_affirmations', DEFAULT_AFFIRMATIONS);
}

export function saveAffirmations(items: AffirmationItem[]): void {
  setStored('chronicle_affirmations', items);
}

export function loadMoodRecords(): Record<string, MoodRecord> {
  const today = getTodayDateString();
  const def: Record<string, MoodRecord> = {
    [today]: {
      date: today,
      mood: 'peaceful',
      flowerType: 'lavender',
      reflection: 'Calm morning tea and gentle writing.',
    },
    [addDaysToDate(today, -1)]: {
      date: addDaysToDate(today, -1),
      mood: 'joyful',
      flowerType: 'sunflower',
      reflection: 'Warm laughter and autumn sunshine.',
    },
    [addDaysToDate(today, -2)]: {
      date: addDaysToDate(today, -2),
      mood: 'reflective',
      flowerType: 'moss_rose',
      reflection: 'Quiet introspection by the fireside.',
    },
    [addDaysToDate(today, -3)]: {
      date: addDaysToDate(today, -3),
      mood: 'tender',
      flowerType: 'camellia',
      reflection: 'Gentle moments with old photographs.',
    },
    [addDaysToDate(today, -4)]: {
      date: addDaysToDate(today, -4),
      mood: 'starlit',
      flowerType: 'lily',
      reflection: 'Clear cold evening under the Orion constellation.',
    },
  };
  return getStored<Record<string, MoodRecord>>('chronicle_moods', def);
}

export function saveMoodRecords(records: Record<string, MoodRecord>): void {
  setStored('chronicle_moods', records);
}
