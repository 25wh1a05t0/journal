/**
 * Chronicle Dynamic Theme Aesthetics
 * Connects the 12 hardcover colors (6 Dark, 6 Pastel) to the entire application's
 * background, top island, ribbon bookmark, active pills, and interface accents.
 */

import { CoverTheme } from '../types/diary';

export interface ThemeAesthetic {
  id: CoverTheme;
  name: string;
  category: 'dark' | 'pastel';
  // Whole app background
  appBg: string;
  // Top Island styling
  islandBg: string;
  islandBorder: string;
  islandText: string;
  islandActiveBg: string;
  islandActiveText: string;
  islandActiveIcon: string;
  // Accents & book decorations
  ribbonColor: string;
  primaryAccent: string;
  bookEdgeShadow: string;
}

export const THEME_AESTHETICS: Record<CoverTheme, ThemeAesthetic> = {
  // --- 6 Dark Themes ---
  sage: {
    id: 'sage',
    name: 'Forest Sage',
    category: 'dark',
    appBg: '#eef3ef',
    islandBg: 'rgba(235, 242, 236, 0.95)',
    islandBorder: 'rgba(180, 200, 185, 0.7)',
    islandText: '#263829',
    islandActiveBg: '#2b3b2e',
    islandActiveText: '#ffffff',
    islandActiveIcon: '#c7dfcb',
    ribbonColor: '#2b3b2e',
    primaryAccent: '#2b3b2e',
    bookEdgeShadow: 'rgba(25, 40, 28, 0.25)',
  },
  espresso: {
    id: 'espresso',
    name: 'Espresso Noir',
    category: 'dark',
    appBg: '#f5f1eb',
    islandBg: 'rgba(242, 237, 230, 0.95)',
    islandBorder: 'rgba(210, 198, 185, 0.7)',
    islandText: '#3a281c',
    islandActiveBg: '#2d2018',
    islandActiveText: '#f5deb3',
    islandActiveIcon: '#e5c98d',
    ribbonColor: '#7c1d29',
    primaryAccent: '#2d2018',
    bookEdgeShadow: 'rgba(35, 20, 10, 0.25)',
  },
  navy: {
    id: 'navy',
    name: 'Midnight Navy',
    category: 'dark',
    appBg: '#edf2f7',
    islandBg: 'rgba(232, 239, 246, 0.95)',
    islandBorder: 'rgba(195, 210, 226, 0.7)',
    islandText: '#1b2c3d',
    islandActiveBg: '#1b2636',
    islandActiveText: '#ffffff',
    islandActiveIcon: '#b8d0ea',
    ribbonColor: '#1b2636',
    primaryAccent: '#1b2636',
    bookEdgeShadow: 'rgba(15, 25, 40, 0.25)',
  },
  terracotta: {
    id: 'terracotta',
    name: 'Deep Terracotta',
    category: 'dark',
    appBg: '#f7f1ec',
    islandBg: 'rgba(246, 236, 230, 0.95)',
    islandBorder: 'rgba(225, 202, 190, 0.7)',
    islandText: '#4e2417',
    islandActiveBg: '#6c3422',
    islandActiveText: '#ffffff',
    islandActiveIcon: '#f3c7b8',
    ribbonColor: '#7a2f1b',
    primaryAccent: '#6c3422',
    bookEdgeShadow: 'rgba(50, 20, 12, 0.25)',
  },
  charcoal: {
    id: 'charcoal',
    name: 'Charcoal Slate',
    category: 'dark',
    appBg: '#efefef',
    islandBg: 'rgba(238, 238, 238, 0.95)',
    islandBorder: 'rgba(205, 205, 205, 0.7)',
    islandText: '#222222',
    islandActiveBg: '#252525',
    islandActiveText: '#ffffff',
    islandActiveIcon: '#e0caa0',
    ribbonColor: '#303030',
    primaryAccent: '#252525',
    bookEdgeShadow: 'rgba(20, 20, 20, 0.25)',
  },
  plum: {
    id: 'plum',
    name: 'Velvet Plum',
    category: 'dark',
    appBg: '#f6eff3',
    islandBg: 'rgba(245, 235, 240, 0.95)',
    islandBorder: 'rgba(220, 198, 210, 0.7)',
    islandText: '#3c1d2a',
    islandActiveBg: '#3c1f2b',
    islandActiveText: '#ffffff',
    islandActiveIcon: '#e7c5d3',
    ribbonColor: '#4f1e33',
    primaryAccent: '#3c1f2b',
    bookEdgeShadow: 'rgba(40, 15, 25, 0.25)',
  },

  // --- 6 Pastel Themes ---
  pastel_matcha: {
    id: 'pastel_matcha',
    name: 'Matcha Mint',
    category: 'pastel',
    appBg: '#f3f7f3',
    islandBg: 'rgba(235, 244, 235, 0.95)',
    islandBorder: 'rgba(188, 212, 190, 0.7)',
    islandText: '#263a28',
    islandActiveBg: '#314e34',
    islandActiveText: '#ffffff',
    islandActiveIcon: '#bde0bf',
    ribbonColor: '#3c5a3f',
    primaryAccent: '#314e34',
    bookEdgeShadow: 'rgba(30, 50, 32, 0.18)',
  },
  pastel_rose: {
    id: 'pastel_rose',
    name: 'Blush Rose',
    category: 'pastel',
    appBg: '#faf1f3',
    islandBg: 'rgba(249, 237, 240, 0.95)',
    islandBorder: 'rgba(232, 200, 208, 0.7)',
    islandText: '#48212b',
    islandActiveBg: '#5c2b37',
    islandActiveText: '#ffffff',
    islandActiveIcon: '#f6cdd5',
    ribbonColor: '#7a3144',
    primaryAccent: '#5c2b37',
    bookEdgeShadow: 'rgba(50, 25, 35, 0.18)',
  },
  pastel_lavender: {
    id: 'pastel_lavender',
    name: 'Soft Lavender',
    category: 'pastel',
    appBg: '#f5f2fa',
    islandBg: 'rgba(243, 238, 249, 0.95)',
    islandBorder: 'rgba(216, 202, 235, 0.7)',
    islandText: '#332349',
    islandActiveBg: '#443060',
    islandActiveText: '#ffffff',
    islandActiveIcon: '#d8c7f2',
    ribbonColor: '#533b73',
    primaryAccent: '#443060',
    bookEdgeShadow: 'rgba(40, 30, 60, 0.18)',
  },
  pastel_peach: {
    id: 'pastel_peach',
    name: 'Warm Peach',
    category: 'pastel',
    appBg: '#faf2ed',
    islandBg: 'rgba(249, 239, 233, 0.95)',
    islandBorder: 'rgba(233, 208, 195, 0.7)',
    islandText: '#4a2515',
    islandActiveBg: '#613420',
    islandActiveText: '#ffffff',
    islandActiveIcon: '#f5cdb9',
    ribbonColor: '#7d3f23',
    primaryAccent: '#613420',
    bookEdgeShadow: 'rgba(50, 30, 20, 0.18)',
  },
  pastel_sky: {
    id: 'pastel_sky',
    name: 'Cloud Sky',
    category: 'pastel',
    appBg: '#edf3f8',
    islandBg: 'rgba(232, 240, 247, 0.95)',
    islandBorder: 'rgba(195, 216, 234, 0.7)',
    islandText: '#1c344d',
    islandActiveBg: '#224363',
    islandActiveText: '#ffffff',
    islandActiveIcon: '#bad5ee',
    ribbonColor: '#2b547d',
    primaryAccent: '#224363',
    bookEdgeShadow: 'rgba(20, 38, 58, 0.18)',
  },
  ivory: {
    id: 'ivory',
    name: 'Linen Alabaster',
    category: 'pastel',
    appBg: '#f7f4ed',
    islandBg: 'rgba(244, 239, 230, 0.95)',
    islandBorder: 'rgba(220, 210, 194, 0.7)',
    islandText: '#3a3225',
    islandActiveBg: '#3d3629',
    islandActiveText: '#ffffff',
    islandActiveIcon: '#e7d8bd',
    ribbonColor: '#635640',
    primaryAccent: '#3d3629',
    bookEdgeShadow: 'rgba(30, 25, 18, 0.18)',
  },
};

export const getThemeAesthetic = (theme?: CoverTheme): ThemeAesthetic => {
  return THEME_AESTHETICS[theme || 'sage'] || THEME_AESTHETICS.sage;
};
