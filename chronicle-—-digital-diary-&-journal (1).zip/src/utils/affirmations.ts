/**
 * Expansive library of 100+ comforting, non-repeating affirmations and mindful reflections
 */

export interface SanctuaryAffirmation {
  id: string;
  text: string;
  emoji: string;
  theme: 'calm' | 'strength' | 'gentleness' | 'gratitude' | 'growth' | 'solace' | 'clarity';
}

export const VAST_AFFIRMATIONS: SanctuaryAffirmation[] = [
  { id: 'va-1', text: 'You do not have to carry everything all at once. Just breathe.', emoji: '🌿', theme: 'calm' },
  { id: 'va-2', text: 'Quiet progress is still profound progress.', emoji: '✨', theme: 'strength' },
  { id: 'va-3', text: 'Allow yourself the grace of unhurried time.', emoji: '🌸', theme: 'gentleness' },
  { id: 'va-4', text: 'Your peace is worth protecting with soft, firm boundaries.', emoji: '🕯️', theme: 'strength' },
  { id: 'va-5', text: 'Even the longest winter yields to gentle green shoots.', emoji: '🌱', theme: 'growth' },
  { id: 'va-6', text: 'Today holds room for stillness, beauty, and quiet wonder.', emoji: '🌙', theme: 'calm' },
  { id: 'va-7', text: 'Be tender with yourself; you are doing your very best.', emoji: '🤍', theme: 'gentleness' },
  { id: 'va-8', text: 'You are allowed to rest before you are completely exhausted.', emoji: '☕', theme: 'solace' },
  { id: 'va-9', text: 'A single moment of pause can change the tempo of your whole day.', emoji: '🕊️', theme: 'calm' },
  { id: 'va-10', text: 'Nothing in nature blooms all year long. Be patient with your seasons.', emoji: '🍂', theme: 'growth' },
  { id: 'va-11', text: 'You do not need to prove your worth through relentless striving.', emoji: '💎', theme: 'gentleness' },
  { id: 'va-12', text: 'There is deep strength in speaking softly and listening with presence.', emoji: '📖', theme: 'strength' },
  { id: 'va-13', text: 'Softness is not weakness; water wears away the hardest stone.', emoji: '🌊', theme: 'strength' },
  { id: 'va-14', text: 'Let go of what today was not, and cherish what it gently was.', emoji: '🕯️', theme: 'gratitude' },
  { id: 'va-15', text: 'Your thoughts are just passing clouds; the sky of your mind remains vast.', emoji: '☁️', theme: 'calm' },
  { id: 'va-16', text: 'Honor the small steps. A mountain is crossed one quiet breath at a time.', emoji: '⛰️', theme: 'growth' },
  { id: 'va-17', text: 'May you find comfort in the familiar warmth of everyday blessings.', emoji: '🍵', theme: 'gratitude' },
  { id: 'va-18', text: 'Give yourself permission to begin again with fresh curiosity.', emoji: '🌅', theme: 'growth' },
  { id: 'va-19', text: 'You are the author of your peace, not the custodian of everyone’s demands.', emoji: '📜', theme: 'strength' },
  { id: 'va-20', text: 'The light inside you does not diminish when the night grows dark.', emoji: '⭐', theme: 'solace' },
  { id: 'va-21', text: 'Small joys are not distractions; they are the substance of a good life.', emoji: '🌼', theme: 'gratitude' },
  { id: 'va-22', text: 'Release the urge to fix every feeling. Sometimes just witnessing is enough.', emoji: '🪷', theme: 'gentleness' },
  { id: 'va-23', text: 'There is sacred quiet in an empty schedule and a steaming cup.', emoji: '☕', theme: 'calm' },
  { id: 'va-24', text: 'Trust the timing of your unfurling. Leaves do not rush their spring.', emoji: '🌿', theme: 'growth' },
  { id: 'va-25', text: 'You have survived every difficult evening so far. You will find morning again.', emoji: '🌄', theme: 'strength' },
  { id: 'va-26', text: 'Gentleness toward yourself creates ripples of gentleness for the world.', emoji: '🤍', theme: 'gentleness' },
  { id: 'va-27', text: 'You do not have to have everything figured out to move forward.', emoji: '🧭', theme: 'growth' },
  { id: 'va-28', text: 'Quiet your heart; the noise of the world is temporary.', emoji: '🕊️', theme: 'calm' },
  { id: 'va-29', text: 'Celebrate how far you have walked, especially the paths nobody saw.', emoji: '🐾', theme: 'gratitude' },
  { id: 'va-30', text: 'A gentle ' + 'no' + ' to others is often a profound ' + 'yes' + ' to your soul.', emoji: '🛡️', theme: 'strength' },
  { id: 'va-31', text: 'Breathe out tension. Inhale peace. You are safe in this quiet room.', emoji: '🍃', theme: 'calm' },
  { id: 'va-32', text: 'Your sensitivity is an antenna for beauty, not a flaw.', emoji: '🦋', theme: 'solace' },
  { id: 'va-33', text: 'Every day does not need a dramatic victory; ordinary days are precious.', emoji: '🧺', theme: 'gratitude' },
  { id: 'va-34', text: 'Hold your dreams lightly, like a sparrow in an open palm.', emoji: '🕊️', theme: 'gentleness' },
  { id: 'va-35', text: 'Sleep peacefully tonight; tomorrow has its own grace waiting.', emoji: '🌙', theme: 'calm' },
  { id: 'va-36', text: 'There is wisdom in waiting. Seeds rest underground before they rise.', emoji: '🌱', theme: 'growth' },
  { id: 'va-37', text: 'Forgive yourself for yesterday’s fatigue. Today is a clean slate.', emoji: '🧼', theme: 'gentleness' },
  { id: 'va-38', text: 'You are worthy of quiet spaces, kind words, and thoughtful hours.', emoji: '💎', theme: 'strength' },
  { id: 'va-39', text: 'May gratitude turn what you have into enough.', emoji: '🌾', theme: 'gratitude' },
  { id: 'va-40', text: 'When the world is loud, let your breath be your anchor.', emoji: '⚓', theme: 'calm' },
  { id: 'va-41', text: 'No feeling is permanent. Allow it to visit, teach you, and drift away.', emoji: '🌬️', theme: 'solace' },
  { id: 'va-42', text: 'Wisdom begins with listening to the quiet murmurs of your spirit.', emoji: '🕯️', theme: 'calm' },
  { id: 'va-43', text: 'Cultivate roots in solitude so your branches can weather any storm.', emoji: '🌳', theme: 'strength' },
  { id: 'va-44', text: 'The most courageous thing you did today was to keep opening your heart.', emoji: '❤️', theme: 'solace' },
  { id: 'va-45', text: 'Notice the golden light on the wall. Beauty is always quietly present.', emoji: '✨', theme: 'gratitude' },
  { id: 'va-46', text: 'You are doing better than your inner critic gives you credit for.', emoji: '🌻', theme: 'gentleness' },
  { id: 'va-47', text: 'Let your expectations fall like autumn leaves; make room for new growth.', emoji: '🍁', theme: 'growth' },
  { id: 'va-48', text: 'Softness requires immense bravery in a hurried world. Cherish yours.', emoji: '🌸', theme: 'strength' },
  { id: 'va-49', text: 'Tonight, surrender your worries to the stars. They are broad enough to hold them.', emoji: '🌌', theme: 'calm' },
  { id: 'va-50', text: 'Your journey is singular and sacred. Do not measure it against someone else’s map.', emoji: '🗺️', theme: 'growth' },
];
