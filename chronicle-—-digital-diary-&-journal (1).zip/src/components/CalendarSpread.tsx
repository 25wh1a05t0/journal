/**
 * Calendar Spread Component
 * Left Page: Monthly Calendar with refined typography and saved date indicators
 * Right Page: Curated Selected-Day Preview with primary action to open day
 */

import React, { useState } from 'react';
import {
  ChevronLeft,
  ChevronRight,
  BookOpen,
  Edit3,
  Image as ImageIcon,
  CheckCircle2,
  CalendarDays,
  Sparkles,
} from 'lucide-react';
import { DiaryEntry, PlannerData, ScrapbookPageData, MoodRecord } from '../types/diary';
import { formatSerifDate, getTodayDateString } from '../utils/storage';

interface CalendarSpreadProps {
  selectedDate: string;
  onSelectDate: (date: string) => void;
  onOpenDaySection: (section: 'diary' | 'planner') => void;
  entries: Record<string, DiaryEntry>;
  plannerDataMap: Record<string, PlannerData>;
  scrapbookDataMap: Record<string, ScrapbookPageData>;
  moodsMap: Record<string, MoodRecord>;
  paperToneClass: string;
}

export const CalendarSpread: React.FC<CalendarSpreadProps> = ({
  selectedDate,
  onSelectDate,
  onOpenDaySection,
  entries,
  plannerDataMap,
  scrapbookDataMap,
  moodsMap,
  paperToneClass,
}) => {
  // Parse year & month from selectedDate
  const [currYear, setCurrYear] = useState<number>(() => {
    const [y] = selectedDate.split('-').map(Number);
    return y || 2026;
  });
  const [currMonth, setCurrMonth] = useState<number>(() => {
    const [, m] = selectedDate.split('-').map(Number);
    return (m || 10) - 1; // 0-indexed
  });

  const todayStr = getTodayDateString();

  // Navigation handlers
  const handlePrevMonth = () => {
    if (currMonth === 0) {
      setCurrMonth(11);
      setCurrYear(currYear - 1);
    } else {
      setCurrMonth(currMonth - 1);
    }
  };

  const handleNextMonth = () => {
    if (currMonth === 11) {
      setCurrMonth(0);
      setCurrYear(currYear + 1);
    } else {
      setCurrMonth(currMonth + 1);
    }
  };

  const handleGoToday = () => {
    const d = new Date();
    setCurrYear(d.getFullYear());
    setCurrMonth(d.getMonth());
    onSelectDate(todayStr);
  };

  // Calendar Math
  const monthName = new Date(currYear, currMonth, 1).toLocaleDateString('en-US', {
    month: 'long',
  });

  // Days of week: Mon - Sun
  const weekDays = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];

  const firstDayOfMonth = new Date(currYear, currMonth, 1).getDay();
  // Adjust so Monday is 0, Sunday is 6
  const startOffset = (firstDayOfMonth + 6) % 7;
  const daysInCurrentMonth = new Date(currYear, currMonth + 1, 0).getDate();
  const daysInPrevMonth = new Date(currYear, currMonth, 0).getDate();

  // Generate cells
  const cells: { dateStr: string; dayNum: number; isCurrentMonth: boolean }[] = [];

  // Previous month trailing days
  for (let i = startOffset - 1; i >= 0; i--) {
    const dayNum = daysInPrevMonth - i;
    const prevMonthIdx = currMonth === 0 ? 11 : currMonth - 1;
    const prevYear = currMonth === 0 ? currYear - 1 : currYear;
    const dateStr = `${prevYear}-${String(prevMonthIdx + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
    cells.push({ dateStr, dayNum, isCurrentMonth: false });
  }

  // Current month days
  for (let d = 1; d <= daysInCurrentMonth; d++) {
    const dateStr = `${currYear}-${String(currMonth + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    cells.push({ dateStr, dayNum: d, isCurrentMonth: true });
  }

  // Next month leading days to complete grid (up to 35 or 42)
  const totalCells = cells.length > 35 ? 42 : 35;
  const remaining = totalCells - cells.length;
  for (let d = 1; d <= remaining; d++) {
    const nextMonthIdx = currMonth === 11 ? 0 : currMonth + 1;
    const nextYear = currMonth === 11 ? currYear + 1 : currYear;
    const dateStr = `${nextYear}-${String(nextMonthIdx + 1).padStart(2, '0')}-${String(d).padStart(2, '0')}`;
    cells.push({ dateStr, dayNum: d, isCurrentMonth: false });
  }

  // Selected date data preview
  const activeEntry = entries[selectedDate];
  const activePlanner = plannerDataMap[selectedDate];
  const activeScrapbook = scrapbookDataMap[selectedDate];
  const activeMood = moodsMap[selectedDate];

  const hasJournalContent = Boolean(
    activeEntry && ((activeEntry.strokes && activeEntry.strokes.length > 0) || activeEntry.typedText?.trim())
  );
  const hasPlannerContent = Boolean(activePlanner && activePlanner.priorities?.length > 0);
  const hasScrapbookContent = Boolean(activeScrapbook && activeScrapbook.items?.length > 0);

  return (
    <div className="w-full h-full flex flex-col md:flex-row divide-y md:divide-y-0 md:divide-x divide-stone-300/60 overflow-hidden">
      {/* LEFT PAGE: Monthly Calendar */}
      <div className={`flex-1 flex flex-col h-full relative ${paperToneClass} book-spine-left p-6 sm:p-8 select-none`}>
        {/* Sub-label & Month Navigation */}
        <div className="flex items-center justify-between border-b border-stone-200/80 pb-3 mb-4">
          <div>
            <span className="text-[11px] font-sans font-medium uppercase tracking-widest text-stone-500 block">
              Monthly Calendar Spread
            </span>
            <h2 className="font-serif text-2xl sm:text-3xl font-medium text-stone-900 mt-0.5">
              {monthName} <span className="font-normal text-stone-500">{currYear}</span>
            </h2>
          </div>

          <div className="flex items-center gap-1.5">
            <button
              onClick={handleGoToday}
              className="px-2.5 py-1 text-xs font-sans text-stone-600 hover:text-stone-900 bg-stone-100 hover:bg-stone-200/80 rounded-md transition-colors"
            >
              Today
            </button>
            <div className="h-4 w-px bg-stone-300 mx-0.5" />
            <button
              onClick={handlePrevMonth}
              title="Previous Month"
              className="p-1.5 text-stone-600 hover:text-stone-900 hover:bg-stone-100 rounded-md transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
            <button
              onClick={handleNextMonth}
              title="Next Month"
              className="p-1.5 text-stone-600 hover:text-stone-900 hover:bg-stone-100 rounded-md transition-colors"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        </div>

        {/* 7-column weekday headers */}
        <div className="grid grid-cols-7 gap-1 text-center mb-1">
          {weekDays.map((wd) => (
            <div
              key={wd}
              className="text-[11px] font-sans font-semibold tracking-wider text-stone-500 py-1"
            >
              {wd}
            </div>
          ))}
        </div>

        {/* 7-column date grid */}
        <div className="grid grid-cols-7 gap-1 flex-1 content-start">
          {cells.map((cell) => {
            const isSelected = cell.dateStr === selectedDate;
            const isToday = cell.dateStr === todayStr;
            const hasData =
              (entries[cell.dateStr]?.strokes?.length ?? 0) > 0 ||
              Boolean(entries[cell.dateStr]?.typedText) ||
              Boolean(plannerDataMap[cell.dateStr]) ||
              Boolean(scrapbookDataMap[cell.dateStr]);

            return (
              <button
                key={cell.dateStr}
                onClick={() => {
                  onSelectDate(cell.dateStr);
                  // Redirect directly to daily planner as requested
                  onOpenDaySection('planner');
                }}
                title={`Open planner for ${cell.dateStr}`}
                className={`relative aspect-square flex flex-col items-center justify-center rounded-lg transition-all text-xs font-serif ${
                  isSelected
                    ? 'bg-amber-900/10 text-amber-950 font-bold ring-1.5 ring-amber-800/80 shadow-xs'
                    : isToday
                    ? 'border border-amber-700/50 text-amber-900 font-semibold'
                    : cell.isCurrentMonth
                    ? 'text-stone-800 hover:bg-stone-100/70'
                    : 'text-stone-400 hover:text-stone-600'
                }`}
              >
                <span className="tabular-nums">{cell.dayNum}</span>

                {/* Restrained indicator dot for saved entries */}
                {hasData && (
                  <span
                    className={`w-1 h-1 rounded-full mt-0.5 ${
                      isSelected ? 'bg-amber-800' : 'bg-stone-400'
                    }`}
                  />
                )}
              </button>
            );
          })}
        </div>

        {/* Left Page Footer */}
        <div className="mt-auto pt-3 border-t border-stone-200/60 flex items-center justify-between text-[11px] text-stone-400 font-serif">
          <span>Monthly Archival View</span>
          <span>p. 1</span>
        </div>
      </div>

      {/* RIGHT PAGE: Selected-Day Restrained Preview */}
      <div className={`flex-1 flex flex-col h-full relative ${paperToneClass} book-spine-right p-6 sm:p-8 select-text`}>
        {/* Handwritten greeting */}
        <span className="font-handwriting text-2xl text-amber-900 block leading-none mb-1">
          A glance at your day…
        </span>

        {/* Full Serif Date */}
        <h3 className="font-serif text-2xl font-medium text-stone-900">
          {formatSerifDate(selectedDate)}
        </h3>

        {/* Delicate Hairline Divider */}
        <div className="h-px bg-stone-300/80 my-4" />

        {/* Content Previews */}
        <div className="flex-1 space-y-4 overflow-y-auto pr-1">
          {/* Mood of the Day */}
          {activeMood && (
            <div className="flex items-center gap-2 text-xs text-stone-600">
              <span className="text-stone-400 uppercase tracking-widest text-[10px]">Mood:</span>
              <span className="font-serif italic capitalize text-stone-800">{activeMood.mood}</span>
              {activeMood.reflection && (
                <span className="text-stone-500 truncate max-w-[220px]">
                  — {activeMood.reflection}
                </span>
              )}
            </div>
          )}

          {/* Daily Planner Summary */}
          <div className="p-3.5 bg-stone-100/60 border border-stone-200/70 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5 text-xs font-medium text-stone-700">
                <BookOpen className="w-3.5 h-3.5 text-amber-800" />
                <span>Daily Planner</span>
              </div>
              {activePlanner && (
                <span className="text-[11px] text-stone-500 font-sans">
                  {activePlanner.tasks.filter((t) => t.done).length}/{activePlanner.tasks.length} tasks
                </span>
              )}
            </div>

            {activePlanner ? (
              <div className="space-y-1.5">
                {activePlanner.intention && (
                  <p className="text-xs font-serif italic text-stone-600 truncate">
                    &ldquo;{activePlanner.intention}&rdquo;
                  </p>
                )}
                {activePlanner.priorities.slice(0, 2).map((p) => (
                  <div key={p.id} className="flex items-center gap-2 text-xs text-stone-700">
                    <CheckCircle2
                      className={`w-3 h-3 ${p.done ? 'text-emerald-700' : 'text-stone-300'}`}
                    />
                    <span className={`truncate ${p.done ? 'line-through text-stone-400' : ''}`}>
                      {p.text}
                    </span>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-xs text-stone-500 italic">No priorities planned for this day yet.</p>
            )}
          </div>

          {/* Dear Diary Summary */}
          <div className="p-3.5 bg-stone-100/60 border border-stone-200/70 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5 text-xs font-medium text-stone-700">
                <Edit3 className="w-3.5 h-3.5 text-amber-800" />
                <span>Dear Diary Writing</span>
              </div>
              {activeEntry && (
                <span className="text-[11px] text-stone-500 font-sans">
                  {activeEntry.strokes?.length || 0} strokes
                </span>
              )}
            </div>

            {activeEntry && activeEntry.typedText ? (
              <p className="font-body-serif text-xs leading-relaxed text-stone-700 line-clamp-3">
                {activeEntry.typedText}
              </p>
            ) : (
              <p className="text-xs text-stone-500 italic">
                Blank page waiting for your stylus or handwritten thoughts.
              </p>
            )}
          </div>

          {/* Scrapbook Summary */}
          <div className="p-3.5 bg-stone-100/60 border border-stone-200/70 rounded-lg">
            <div className="flex items-center justify-between mb-2">
              <div className="flex items-center gap-1.5 text-xs font-medium text-stone-700">
                <ImageIcon className="w-3.5 h-3.5 text-amber-800" />
                <span>Scrapbook Memories</span>
              </div>
              {activeScrapbook && (
                <span className="text-[11px] text-stone-500 font-sans">
                  {activeScrapbook.items.length} items
                </span>
              )}
            </div>
            {activeScrapbook && activeScrapbook.items.length > 0 ? (
              <p className="text-xs text-stone-600 truncate">
                {activeScrapbook.note || `${activeScrapbook.items.length} polaroids & memories saved`}
              </p>
            ) : (
              <p className="text-xs text-stone-500 italic">No scrapbook items added for this date.</p>
            )}
          </div>
        </div>

        {/* Primary Action Button */}
        <div className="pt-4 mt-auto border-t border-stone-200/80 flex items-center gap-3">
          <button
            onClick={() => onOpenDaySection('planner')}
            className="flex-1 py-2.5 px-4 bg-stone-900 hover:bg-stone-800 text-amber-50 text-xs font-medium rounded-lg transition-colors flex items-center justify-center gap-2 shadow-xs"
          >
            <BookOpen className="w-3.5 h-3.5 text-amber-300" />
            <span>Open Daily Planner for {formatSerifDate(selectedDate).split(',')[0]}</span>
          </button>
          <button
            onClick={() => onOpenDaySection('diary')}
            className="py-2.5 px-3 bg-[#ede6d8] hover:bg-[#e4dcce] text-stone-800 text-xs font-medium rounded-lg transition-colors flex items-center gap-1.5 border border-stone-300/80"
          >
            <Edit3 className="w-3.5 h-3.5 text-amber-900" />
            <span>Dear Diary</span>
          </button>
        </div>

        {/* Right Page Footer */}
        <div className="mt-3 pt-1 flex items-center justify-between text-[11px] text-stone-400 font-serif">
          <span>Daily Index</span>
          <span>p. 2</span>
        </div>
      </div>
    </div>
  );
};
