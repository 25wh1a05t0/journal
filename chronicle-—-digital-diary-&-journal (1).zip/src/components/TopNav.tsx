/**
 * Chronicle Top Island Navigation Bar
 * Responsive, zero-scroll floating island that automatically adapts to the chosen cover theme.
 * 3-Zone contract: [Book Cover & Date] — [7 Sections] — [Saving Status & Closing Ritual]
 */

import React, { useState } from 'react';
import {
  Book,
  ChevronLeft,
  ChevronRight,
  CheckCircle2,
  Calendar as CalendarIcon,
  BookOpen,
  Edit3,
  Image as ImageIcon,
  Smile,
  Sparkles,
  Lock,
  Moon,
  Loader2,
} from 'lucide-react';
import { DiarySection, CoverTheme } from '../types/diary';
import { formatShortDate } from '../utils/storage';
import { getThemeAesthetic } from '../utils/theme';

interface TopNavProps {
  currentSection: DiarySection;
  onSelectSection: (section: DiarySection) => void;
  selectedDate: string;
  onSelectDate: (date: string) => void;
  onPrevDay: () => void;
  onNextDay: () => void;
  isBookClosed: boolean;
  onToggleBookCover: () => void;
  saveStatus: 'saved' | 'saving';
  onOpenClosingRitual: () => void;
  coverTheme?: CoverTheme;
}

const SECTIONS: { id: DiarySection; label: string; icon: React.ElementType }[] = [
  { id: 'calendar', label: 'Calendar', icon: CalendarIcon },
  { id: 'planner', label: 'Planner', icon: BookOpen },
  { id: 'diary', label: 'Diary', icon: Edit3 },
  { id: 'scrapbook', label: 'Scrapbook', icon: ImageIcon },
  { id: 'sanctuary', label: 'Sanctuary', icon: Sparkles },
  { id: 'garden', label: 'Mood', icon: Smile },
  { id: 'settings', label: 'Settings', icon: Lock },
];

export const TopNav: React.FC<TopNavProps> = ({
  currentSection,
  onSelectSection,
  selectedDate,
  onSelectDate,
  onPrevDay,
  onNextDay,
  isBookClosed,
  onToggleBookCover,
  saveStatus,
  onOpenClosingRitual,
  coverTheme,
}) => {
  const [showDatePicker, setShowDatePicker] = useState(false);
  const theme = getThemeAesthetic(coverTheme);

  return (
    <header className="w-full shrink-0 px-2 sm:px-4 pt-1.5 pb-1 z-40 select-none overflow-hidden flex justify-center">
      {/* Floating Island Shell matching current cover theme */}
      <div
        className="w-full max-w-6xl flex items-center justify-between gap-1 sm:gap-2 px-2 sm:px-3 py-1 rounded-xl shadow-xs border transition-all duration-300 backdrop-blur-md overflow-hidden"
        style={{
          backgroundColor: theme.islandBg,
          borderColor: theme.islandBorder,
        }}
      >
        {/* Left Zone: Book Cover Toggle & Compact Date Navigator */}
        <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
          <button
            onClick={onToggleBookCover}
            title={isBookClosed ? 'Open Journal' : 'Close to Cover'}
            className="flex items-center gap-1 px-1.5 sm:px-2 py-0.5 rounded-md text-[10px] sm:text-xs font-medium transition-colors border"
            style={{
              borderColor: theme.islandBorder,
              color: theme.islandText,
              backgroundColor: 'rgba(255, 255, 255, 0.45)',
            }}
          >
            <Book className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
            <span className="hidden md:inline">{isBookClosed ? 'Open' : 'Cover'}</span>
          </button>

          <div
            className="h-3.5 w-px hidden sm:block opacity-40"
            style={{ backgroundColor: theme.islandText }}
            aria-hidden="true"
          />

          {/* Date controls */}
          <div className="flex items-center">
            <button
              onClick={onPrevDay}
              title="Previous Day"
              className="p-1 rounded hover:bg-black/5 transition-colors"
              style={{ color: theme.islandText }}
            >
              <ChevronLeft className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
            </button>

            <div className="relative">
              <button
                onClick={() => setShowDatePicker(!showDatePicker)}
                className="px-1 sm:px-1.5 py-0.5 text-[10px] sm:text-xs font-serif font-medium tracking-tight rounded hover:bg-black/5 transition-colors"
                style={{ color: theme.islandText }}
              >
                <span>{formatShortDate(selectedDate)}</span>
              </button>

              {showDatePicker && (
                <div className="absolute left-0 top-full mt-1.5 p-2 bg-[#fdfbf7] border border-stone-300 rounded-lg shadow-xl z-50">
                  <input
                    type="date"
                    value={selectedDate}
                    onChange={(e) => {
                      if (e.target.value) {
                        onSelectDate(e.target.value);
                        setShowDatePicker(false);
                      }
                    }}
                    className="text-xs p-1.5 bg-white border border-stone-200 rounded text-stone-800 focus:outline-hidden"
                  />
                </div>
              )}
            </div>

            <button
              onClick={onNextDay}
              title="Next Day"
              className="p-1 rounded hover:bg-black/5 transition-colors"
              style={{ color: theme.islandText }}
            >
              <ChevronRight className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
            </button>
          </div>
        </div>

        {/* Center Zone: The 7 Sections - Compact typography, zero scroll */}
        <nav className="flex items-center justify-center gap-0.5 sm:gap-1 flex-1 min-w-0 overflow-hidden px-0.5">
          {SECTIONS.map((sec) => {
            const isActive = currentSection === sec.id && !isBookClosed;
            const Icon = sec.icon;
            return (
              <button
                key={sec.id}
                onClick={() => onSelectSection(sec.id)}
                className={`flex items-center gap-0.5 sm:gap-1 px-1 sm:px-2 py-0.5 sm:py-1 rounded-md text-[10px] sm:text-[11px] font-sans font-medium transition-all duration-200 shrink-0 ${
                  isActive ? 'shadow-2xs font-semibold' : 'hover:bg-black/5'
                }`}
                style={
                  isActive
                    ? {
                        backgroundColor: theme.islandActiveBg,
                        color: theme.islandActiveText,
                      }
                    : {
                        color: theme.islandText,
                      }
                }
                title={sec.label}
              >
                <Icon
                  className="w-3 h-3 sm:w-3.5 sm:h-3.5 shrink-0"
                  style={isActive ? { color: theme.islandActiveIcon } : undefined}
                />
                <span className="truncate">{sec.label}</span>
              </button>
            );
          })}
        </nav>

        {/* Right Zone: Saving Status & Evening Ritual */}
        <div className="flex items-center gap-1 sm:gap-1.5 shrink-0">
          <div
            className="flex items-center gap-1 text-[10px] font-sans tracking-tight"
            style={{ color: theme.islandText }}
          >
            {saveStatus === 'saving' ? (
              <Loader2 className="w-3 h-3 animate-spin opacity-75" />
            ) : (
              <CheckCircle2 className="w-3 h-3 text-emerald-700" />
            )}
            <span className="hidden lg:inline">{saveStatus === 'saving' ? 'Saving' : 'Saved'}</span>
          </div>

          <div
            className="h-3.5 w-px hidden sm:block opacity-40"
            style={{ backgroundColor: theme.islandText }}
            aria-hidden="true"
          />

          <button
            onClick={onOpenClosingRitual}
            title="Evening Reflection & Closing Ritual"
            className="flex items-center gap-1 px-1.5 sm:px-2 py-0.5 rounded-md text-[10px] sm:text-xs font-medium transition-colors border"
            style={{
              borderColor: theme.islandBorder,
              color: theme.islandText,
              backgroundColor: 'rgba(255, 255, 255, 0.45)',
            }}
          >
            <Moon className="w-3 h-3 sm:w-3.5 sm:h-3.5" />
            <span className="hidden md:inline">Ritual</span>
          </button>
        </div>
      </div>
    </header>
  );
};
