/**
 * Daily Planner Spread Component
 * Left Page: Date heading, daily intention, 3 priorities, interactive to-do list
 * Right Page: Hourly schedule (07:00 to 22:00), notes & appointments
 */

import React, { useState } from 'react';
import {
  Plus,
  Trash2,
  Check,
  CheckCircle2,
  Clock,
  ListTodo,
  Sparkles,
  Edit2,
  Edit3,
  ArrowRight,
} from 'lucide-react';
import { PlannerData, PriorityItem, TaskItem, HourlyEvent } from '../types/diary';
import { formatSerifDate } from '../utils/storage';

interface PlannerSpreadProps {
  date: string;
  data: PlannerData;
  onSaveData: (data: PlannerData) => void;
  onOpenDiary?: () => void;
  paperToneClass: string;
}

const HOURS = [
  '07:00 AM',
  '08:00 AM',
  '09:00 AM',
  '10:00 AM',
  '11:00 AM',
  '12:00 PM',
  '01:00 PM',
  '02:00 PM',
  '03:00 PM',
  '04:00 PM',
  '05:00 PM',
  '06:00 PM',
  '07:00 PM',
  '08:00 PM',
  '09:00 PM',
  '10:00 PM',
];

export const PlannerSpread: React.FC<PlannerSpreadProps> = ({
  date,
  data,
  onSaveData,
  onOpenDiary,
  paperToneClass,
}) => {
  const [newTaskText, setNewTaskText] = useState('');
  const [newTaskCategory, setNewTaskCategory] = useState('Personal');
  const [editingEventHour, setEditingEventHour] = useState<string | null>(null);
  const [eventInputTitle, setEventInputTitle] = useState('');

  // Update intention
  const handleIntentionChange = (val: string) => {
    onSaveData({ ...data, intention: val });
  };

  // Priority toggles and text edits
  const handleTogglePriority = (id: string) => {
    const next = data.priorities.map((p) => (p.id === id ? { ...p, done: !p.done } : p));
    onSaveData({ ...data, priorities: next });
  };

  const handleEditPriorityText = (id: string, text: string) => {
    const next = data.priorities.map((p) => (p.id === id ? { ...p, text } : p));
    onSaveData({ ...data, priorities: next });
  };

  // Tasks operations
  const handleAddTask = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newTaskText.trim()) return;
    const newTask: TaskItem = {
      id: `task-${Date.now()}`,
      text: newTaskText.trim(),
      done: false,
      category: newTaskCategory,
    };
    onSaveData({ ...data, tasks: [...data.tasks, newTask] });
    setNewTaskText('');
  };

  const handleToggleTask = (id: string) => {
    const next = data.tasks.map((t) => (t.id === id ? { ...t, done: !t.done } : t));
    onSaveData({ ...data, tasks: next });
  };

  const handleDeleteTask = (id: string) => {
    const next = data.tasks.filter((t) => t.id !== id);
    onSaveData({ ...data, tasks: next });
  };

  // Hourly schedule events
  const handleSaveHourlyEvent = (time: string) => {
    if (!eventInputTitle.trim()) {
      // If empty, remove existing event for that time
      const next = data.hourlyEvents.filter((ev) => ev.time !== time);
      onSaveData({ ...data, hourlyEvents: next });
    } else {
      const existing = data.hourlyEvents.find((ev) => ev.time === time);
      let next: HourlyEvent[];
      if (existing) {
        next = data.hourlyEvents.map((ev) => (ev.time === time ? { ...ev, title: eventInputTitle.trim() } : ev));
      } else {
        next = [...data.hourlyEvents, { id: `event-${Date.now()}`, time, title: eventInputTitle.trim() }];
      }
      onSaveData({ ...data, hourlyEvents: next });
    }
    setEditingEventHour(null);
    setEventInputTitle('');
  };

  const handleDeleteHourlyEvent = (time: string) => {
    const next = data.hourlyEvents.filter((ev) => ev.time !== time);
    onSaveData({ ...data, hourlyEvents: next });
  };

  // Notes update
  const handleNotesChange = (val: string) => {
    onSaveData({ ...data, notes: val });
  };

  return (
    <div className="w-full h-full flex flex-col md:flex-row divide-y md:divide-y-0 md:divide-x divide-stone-300/60 overflow-hidden">
      {/* LEFT PAGE: Intention, 3 Priorities & To-Do List */}
      <div className={`flex-1 flex flex-col h-full relative ${paperToneClass} book-spine-left p-6 sm:p-8 select-text overflow-y-auto`}>
        {/* Date header */}
        <div className="border-b border-stone-200/80 pb-3 mb-4">
          <span className="text-[11px] font-sans font-medium uppercase tracking-widest text-stone-500 block">
            Daily Planner Spread
          </span>
          <h2 className="font-serif text-2xl sm:text-3xl font-medium text-stone-900 mt-0.5">
            {formatSerifDate(date)}
          </h2>
        </div>

        {/* Daily Intention */}
        <div className="mb-5 pb-3 border-b border-stone-200/60">
          <div className="flex items-center gap-1.5 mb-1 text-xs font-medium text-stone-600">
            <Sparkles className="w-3.5 h-3.5 text-amber-800" />
            <span className="font-handwriting text-lg text-amber-900">Today&apos;s Guiding Intention</span>
          </div>
          <input
            type="text"
            value={data.intention || ''}
            onChange={(e) => handleIntentionChange(e.target.value)}
            placeholder="What is your quiet purpose for today?"
            className="w-full text-xs sm:text-sm font-serif italic text-stone-800 bg-transparent border-b border-stone-300 focus:border-amber-700 py-1 placeholder-stone-400 focus:outline-hidden"
          />
        </div>

        {/* Three Core Priorities */}
        <div className="mb-6">
          <span className="text-xs font-sans font-semibold tracking-wide text-stone-700 uppercase mb-2 block">
            Three Core Priorities
          </span>
          <div className="space-y-2.5">
            {data.priorities.map((item, idx) => (
              <div
                key={item.id}
                className="flex items-center gap-2 p-2 rounded-md hover:bg-stone-100/50 transition-colors border border-stone-200/50"
              >
                <button
                  onClick={() => handleTogglePriority(item.id)}
                  title="Mark priority complete"
                  className={`w-5 h-5 rounded-md border flex items-center justify-center transition-colors shrink-0 ${
                    item.done
                      ? 'bg-amber-800 border-amber-800 text-white'
                      : 'border-stone-400 hover:border-amber-800'
                  }`}
                >
                  {item.done && <Check className="w-3.5 h-3.5" />}
                </button>
                <span className="text-xs font-serif text-stone-500 w-3">{idx + 1}.</span>
                <input
                  type="text"
                  value={item.text}
                  onChange={(e) => handleEditPriorityText(item.id, e.target.value)}
                  className={`flex-1 text-xs sm:text-sm font-serif bg-transparent focus:outline-hidden ${
                    item.done ? 'line-through text-stone-400' : 'text-stone-800'
                  }`}
                />
              </div>
            ))}
          </div>
        </div>

        {/* To-Do List */}
        <div className="flex-1 flex flex-col">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs font-sans font-semibold tracking-wide text-stone-700 uppercase">
              Action Items & Rituals
            </span>
            <span className="text-[11px] font-sans text-stone-500">
              {data.tasks.filter((t) => t.done).length}/{data.tasks.length} Done
            </span>
          </div>

          {/* New Task Form */}
          <form onSubmit={handleAddTask} className="flex items-center gap-2 mb-3">
            <input
              type="text"
              value={newTaskText}
              onChange={(e) => setNewTaskText(e.target.value)}
              placeholder="Add task or peaceful reminder..."
              className="flex-1 text-xs font-serif p-2 bg-[#f4efe5]/60 border border-stone-300 rounded-md text-stone-800 placeholder-stone-400 focus:outline-hidden focus:border-amber-700"
            />
            <select
              value={newTaskCategory}
              onChange={(e) => setNewTaskCategory(e.target.value)}
              className="text-[11px] font-sans p-2 bg-[#f4efe5]/60 border border-stone-300 rounded-md text-stone-700 focus:outline-hidden"
            >
              <option value="Personal">Personal</option>
              <option value="Creative">Creative</option>
              <option value="Focus">Focus</option>
              <option value="Ritual">Ritual</option>
            </select>
            <button
              type="submit"
              className="p-2 bg-stone-800 hover:bg-stone-900 text-white rounded-md transition-colors"
              title="Add task"
            >
              <Plus className="w-3.5 h-3.5" />
            </button>
          </form>

          {/* Task Items */}
          <div className="space-y-1.5 flex-1 overflow-y-auto pr-1">
            {data.tasks.map((task) => (
              <div
                key={task.id}
                className="group flex items-center justify-between gap-2 p-1.5 rounded hover:bg-stone-100/60 transition-colors border-b border-stone-200/40"
              >
                <div className="flex items-center gap-2 flex-1 min-w-0">
                  <button
                    onClick={() => handleToggleTask(task.id)}
                    className={`w-4 h-4 rounded-sm border flex items-center justify-center transition-colors shrink-0 ${
                      task.done
                        ? 'bg-stone-800 border-stone-800 text-white'
                        : 'border-stone-400 hover:border-stone-800'
                    }`}
                  >
                    {task.done && <Check className="w-3 h-3" />}
                  </button>
                  <span
                    className={`text-xs font-serif truncate ${
                      task.done ? 'line-through text-stone-400' : 'text-stone-800'
                    }`}
                  >
                    {task.text}
                  </span>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  {task.category && (
                    <span className="text-[10px] font-sans text-stone-400">
                      {task.category}
                    </span>
                  )}
                  <button
                    onClick={() => handleDeleteTask(task.id)}
                    className="opacity-0 group-hover:opacity-100 text-stone-400 hover:text-red-700 p-1 transition-opacity"
                    title="Delete item"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              </div>
            ))}
            {data.tasks.length === 0 && (
              <p className="text-xs text-stone-400 italic py-2">No tasks added for today.</p>
            )}
          </div>
        </div>

        {/* Left Page Footer */}
        <div className="mt-auto pt-3 border-t border-stone-200/60 flex items-center justify-between text-[11px] text-stone-400 font-serif">
          <span>Day Schedule</span>
          <span>p. 4</span>
        </div>
      </div>

      {/* RIGHT PAGE: Hourly Schedule & Daily Notes */}
      <div className={`flex-1 flex flex-col h-full relative ${paperToneClass} book-spine-right p-6 sm:p-8 select-text overflow-y-auto`}>
        {/* Header */}
        <div className="border-b border-stone-200/80 pb-3 mb-3 flex items-center justify-between">
          <div>
            <span className="font-serif text-lg font-semibold text-stone-900 tracking-tight">
              Hourly Rhythm & Appointments
            </span>
            <p className="text-xs text-stone-500 font-sans mt-0.5">
              07:00 AM &ndash; 10:00 PM Timeline
            </p>
          </div>
          <Clock className="w-4 h-4 text-stone-400" />
        </div>

        {/* Hourly Timeline */}
        <div className="space-y-1 mb-5 max-h-[380px] overflow-y-auto pr-1">
          {HOURS.map((hour) => {
            const ev = data.hourlyEvents.find((e) => e.time === hour);
            const isEditing = editingEventHour === hour;

            return (
              <div
                key={hour}
                className="flex items-center gap-3 py-1 px-1.5 rounded hover:bg-stone-100/60 transition-colors border-b border-stone-200/40 text-xs"
              >
                <span className="w-16 font-sans text-[11px] font-medium text-stone-400 tabular-nums shrink-0">
                  {hour}
                </span>

                {isEditing ? (
                  <div className="flex-1 flex items-center gap-1.5">
                    <input
                      type="text"
                      autoFocus
                      value={eventInputTitle}
                      onChange={(e) => setEventInputTitle(e.target.value)}
                      onKeyDown={(e) => {
                        if (e.key === 'Enter') handleSaveHourlyEvent(hour);
                        if (e.key === 'Escape') setEditingEventHour(null);
                      }}
                      placeholder="Appointment or focus block..."
                      className="flex-1 text-xs font-serif bg-white px-2 py-0.5 border border-stone-300 rounded text-stone-800 focus:outline-hidden"
                    />
                    <button
                      onClick={() => handleSaveHourlyEvent(hour)}
                      className="px-2 py-0.5 bg-stone-800 text-white rounded text-[11px]"
                    >
                      Save
                    </button>
                    <button
                      onClick={() => setEditingEventHour(null)}
                      className="text-stone-400 hover:text-stone-600 text-[11px]"
                    >
                      Cancel
                    </button>
                  </div>
                ) : (
                  <div
                    onClick={() => {
                      setEditingEventHour(hour);
                      setEventInputTitle(ev?.title || '');
                    }}
                    className="flex-1 cursor-pointer flex items-center justify-between group min-h-[22px]"
                  >
                    {ev ? (
                      <span className="font-serif text-stone-800 group-hover:text-amber-900 transition-colors">
                        {ev.title}
                      </span>
                    ) : (
                      <span className="text-stone-300 text-[11px] italic group-hover:text-stone-400 transition-colors">
                        + Add event
                      </span>
                    )}

                    {ev && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          handleDeleteHourlyEvent(hour);
                        }}
                        className="opacity-0 group-hover:opacity-100 text-stone-400 hover:text-red-700 p-0.5 transition-opacity"
                        title="Remove event"
                      >
                        <Trash2 className="w-3 h-3" />
                      </button>
                    )}
                  </div>
                )}
              </div>
            );
          })}
        </div>

        {/* Daily Notes Area */}
        <div className="flex-1 flex flex-col pt-2 border-t border-stone-200/80">
          <span className="text-xs font-sans font-semibold tracking-wide text-stone-700 uppercase mb-1">
            Notes & Epiphanies
          </span>
          <textarea
            value={data.notes || ''}
            onChange={(e) => handleNotesChange(e.target.value)}
            placeholder="Quick phone notes, reading quotes, ideas to explore..."
            className="flex-1 w-full bg-transparent resize-none font-body-serif text-xs leading-relaxed text-stone-800 focus:outline-hidden p-2 border border-stone-200/50 rounded-md"
            style={{
              backgroundImage:
                'repeating-linear-gradient(transparent, transparent 27px, rgba(180, 160, 140, 0.15) 27px, rgba(180, 160, 140, 0.15) 28px)',
              lineHeight: '28px',
            }}
          />
        </div>

        {/* Right Page Footer */}
        <div className="mt-auto pt-3 border-t border-stone-200/60 flex items-center justify-between text-[11px] text-stone-400 font-serif">
          <span>Notes & Agenda</span>
          {onOpenDiary ? (
            <button
              onClick={onOpenDiary}
              className="flex items-center gap-1.5 px-3 py-1.5 bg-stone-900 hover:bg-stone-800 text-amber-50 rounded-md text-xs font-sans transition-colors shadow-xs"
            >
              <Edit3 className="w-3.5 h-3.5 text-amber-300" />
              <span>Continue to Dear Diary</span>
              <ArrowRight className="w-3.5 h-3.5 text-stone-400" />
            </button>
          ) : (
            <span>p. 5</span>
          )}
        </div>
      </div>
    </div>
  );
};
