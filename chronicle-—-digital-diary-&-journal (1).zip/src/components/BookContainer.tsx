/**
 * Book Container Component
 * Features customizable plain-color hardcover themes (user-selectable),
 * open two-page spread with center spine, paper shadows, ribbon bookmark,
 * and 3D page-flip animations.
 */

import React from 'react';
import { CoverTheme, PaperTone } from '../types/diary';
import { BookOpen, Check, Palette } from 'lucide-react';
import { getThemeAesthetic } from '../utils/theme';

interface BookContainerProps {
  isBookClosed: boolean;
  onOpenBook: () => void;
  coverTheme: CoverTheme;
  onChangeCoverTheme: (theme: CoverTheme) => void;
  paperTone: PaperTone;
  children: React.ReactNode;
  authorName?: string;
  isTurningPage?: boolean;
}

export const COVER_THEMES: {
  id: CoverTheme;
  name: string;
  category: 'dark' | 'pastel';
  bgGradient: string;
  accentColor: string;
  spineShadow: string;
  borderColor: string;
  textColor: string;
  foilColor: string;
}[] = [
  // --- Dark Colors ---
  {
    id: 'sage',
    name: 'Forest Sage',
    category: 'dark',
    bgGradient: 'linear-gradient(135deg, #2b3b2e 0%, #202d23 100%)',
    accentColor: '#364b3a',
    spineShadow: 'rgba(15, 25, 18, 0.6)',
    borderColor: '#19241b',
    textColor: '#e8dbb5',
    foilColor: '#dfcf9f',
  },
  {
    id: 'espresso',
    name: 'Espresso Noir',
    category: 'dark',
    bgGradient: 'linear-gradient(135deg, #2d2018 0%, #1c140f 100%)',
    accentColor: '#3c2c22',
    spineShadow: 'rgba(20, 12, 8, 0.6)',
    borderColor: '#140c08',
    textColor: '#f5deb3',
    foilColor: '#e5c98d',
  },
  {
    id: 'navy',
    name: 'Midnight Navy',
    category: 'dark',
    bgGradient: 'linear-gradient(135deg, #1b2636 0%, #101924 100%)',
    accentColor: '#243449',
    spineShadow: 'rgba(10, 16, 25, 0.6)',
    borderColor: '#0b121c',
    textColor: '#e0e7ee',
    foilColor: '#dbe2ea',
  },
  {
    id: 'terracotta',
    name: 'Deep Terracotta',
    category: 'dark',
    bgGradient: 'linear-gradient(135deg, #6c3422 0%, #522517 100%)',
    accentColor: '#7e3e2a',
    spineShadow: 'rgba(40, 15, 10, 0.6)',
    borderColor: '#3a170e',
    textColor: '#fae5d8',
    foilColor: '#eed2c0',
  },
  {
    id: 'charcoal',
    name: 'Charcoal Slate',
    category: 'dark',
    bgGradient: 'linear-gradient(135deg, #252525 0%, #181818 100%)',
    accentColor: '#333333',
    spineShadow: 'rgba(10, 10, 10, 0.7)',
    borderColor: '#101010',
    textColor: '#dedede',
    foilColor: '#e0caa0',
  },
  {
    id: 'plum',
    name: 'Velvet Plum',
    category: 'dark',
    bgGradient: 'linear-gradient(135deg, #3c1f2b 0%, #2a141e 100%)',
    accentColor: '#4f2c3a',
    spineShadow: 'rgba(30, 12, 20, 0.6)',
    borderColor: '#200d16',
    textColor: '#f3e5eb',
    foilColor: '#e5cdd8',
  },
  // --- Pastel Colors ---
  {
    id: 'pastel_matcha',
    name: 'Matcha Mint',
    category: 'pastel',
    bgGradient: 'linear-gradient(135deg, #d8e5d9 0%, #c5d7c6 100%)',
    accentColor: '#b4cbb6',
    spineShadow: 'rgba(40, 60, 45, 0.25)',
    borderColor: '#a9c1ab',
    textColor: '#243926',
    foilColor: '#334e36',
  },
  {
    id: 'pastel_rose',
    name: 'Blush Rose',
    category: 'pastel',
    bgGradient: 'linear-gradient(135deg, #fae2e6 0%, #edd1d7 100%)',
    accentColor: '#e2bcc5',
    spineShadow: 'rgba(60, 35, 45, 0.25)',
    borderColor: '#d8afb9',
    textColor: '#4a2530',
    foilColor: '#632e3e',
  },
  {
    id: 'pastel_lavender',
    name: 'Soft Lavender',
    category: 'pastel',
    bgGradient: 'linear-gradient(135deg, #ece5f7 0%, #ded3f0 100%)',
    accentColor: '#cbbee6',
    spineShadow: 'rgba(50, 40, 70, 0.25)',
    borderColor: '#c3b3e0',
    textColor: '#322549',
    foilColor: '#493568',
  },
  {
    id: 'pastel_peach',
    name: 'Warm Peach',
    category: 'pastel',
    bgGradient: 'linear-gradient(135deg, #fce8dd 0%, #f6d8c8 100%)',
    accentColor: '#edc4b0',
    spineShadow: 'rgba(70, 40, 30, 0.25)',
    borderColor: '#e5b69f',
    textColor: '#4e2918',
    foilColor: '#69361e',
  },
  {
    id: 'pastel_sky',
    name: 'Cloud Sky',
    category: 'pastel',
    bgGradient: 'linear-gradient(135deg, #e0ecf7 0%, #ccdff0 100%)',
    accentColor: '#b3cfe8',
    spineShadow: 'rgba(30, 45, 65, 0.25)',
    borderColor: '#a3c3e0',
    textColor: '#1f354d',
    foilColor: '#2b4766',
  },
  {
    id: 'ivory',
    name: 'Linen Alabaster',
    category: 'pastel',
    bgGradient: 'linear-gradient(135deg, #f5efe6 0%, #e6ded2 100%)',
    accentColor: '#dcd1c2',
    spineShadow: 'rgba(60, 50, 40, 0.25)',
    borderColor: '#c9bca9',
    textColor: '#3a3328',
    foilColor: '#6a5940',
  },
];

export const BookContainer: React.FC<BookContainerProps> = ({
  isBookClosed,
  onOpenBook,
  coverTheme,
  onChangeCoverTheme,
  paperTone,
  children,
  authorName = 'Eleanor',
  isTurningPage = false,
}) => {
  const currentTheme = COVER_THEMES.find((t) => t.id === coverTheme) || COVER_THEMES[0];
  const themeAesthetic = getThemeAesthetic(coverTheme);
  const [filterMode, setFilterMode] = React.useState<'all' | 'dark' | 'pastel'>('all');

  const visibleThemes =
    filterMode === 'all'
      ? COVER_THEMES
      : COVER_THEMES.filter((t) => t.category === filterMode);

  // If book is closed, render the plain customizable hardcover
  if (isBookClosed) {
    return (
      <div className="w-full flex-1 flex flex-col items-center justify-center p-4 sm:p-8 perspective-book select-none">
        {/* Cover Color Selection Ribbon with Dark & Pastel filter */}
        <div className="mb-4 flex flex-wrap items-center justify-center gap-2 bg-[#f0ebd9]/95 px-4 py-2 rounded-full border border-stone-300/80 shadow-xs backdrop-blur-xs max-w-xl">
          <Palette className="w-3.5 h-3.5 text-stone-600 shrink-0" />
          <div className="flex items-center gap-1 text-[11px] font-sans font-medium text-stone-600 mr-1">
            <button
              onClick={() => setFilterMode('all')}
              className={`px-2 py-0.5 rounded transition-colors ${
                filterMode === 'all' ? 'bg-stone-300 text-stone-900 font-semibold' : 'hover:text-stone-900'
              }`}
            >
              All
            </button>
            <button
              onClick={() => setFilterMode('dark')}
              className={`px-2 py-0.5 rounded transition-colors ${
                filterMode === 'dark' ? 'bg-stone-800 text-white font-semibold' : 'hover:text-stone-900'
              }`}
            >
              Dark
            </button>
            <button
              onClick={() => setFilterMode('pastel')}
              className={`px-2 py-0.5 rounded transition-colors ${
                filterMode === 'pastel' ? 'bg-rose-200 text-rose-950 font-semibold' : 'hover:text-stone-900'
              }`}
            >
              Pastel
            </button>
          </div>

          <div className="h-3 w-px bg-stone-300" />

          {/* Theme Color Swatches */}
          <div className="flex items-center gap-1.5 flex-wrap justify-center">
            {visibleThemes.map((theme) => (
              <button
                key={theme.id}
                onClick={(e) => {
                  e.stopPropagation();
                  onChangeCoverTheme(theme.id);
                }}
                title={`${theme.name} (${theme.category})`}
                className={`w-5 h-5 rounded-full transition-transform flex items-center justify-center border ${
                  coverTheme === theme.id
                    ? 'scale-125 ring-2 ring-stone-800 border-white shadow-xs'
                    : 'hover:scale-115 border-stone-400'
                }`}
                style={{ background: theme.bgGradient }}
              >
                {coverTheme === theme.id && (
                  <Check
                    className={`w-3 h-3 ${
                      theme.category === 'pastel' ? 'text-stone-800' : 'text-white'
                    }`}
                  />
                )}
              </button>
            ))}
          </div>
        </div>

        {/* The Hardcover Book */}
        <div
          onClick={onOpenBook}
          className="relative w-full max-w-sm sm:max-w-md aspect-[3/4] rounded-r-xl rounded-l-md shadow-2xl overflow-hidden cursor-pointer group transform transition-all duration-500 hover:scale-[1.02] border-r-8 border-b-8 border-t-2 border-l-4"
          style={{
            background: currentTheme.bgGradient,
            borderColor: currentTheme.borderColor,
            boxShadow: `20px 25px 50px -10px ${currentTheme.spineShadow}, -6px 0 16px -2px rgba(20, 10, 5, 0.3)`,
          }}
        >
          {/* Subtle clothbound linen texture overlay */}
          <div
            className="absolute inset-0 opacity-15 pointer-events-none"
            style={{
              backgroundImage:
                'repeating-linear-gradient(45deg, rgba(255,255,255,0.08) 0, rgba(255,255,255,0.08) 1px, transparent 0, transparent 4px)',
            }}
          />

          {/* Spine Crease Overlay */}
          <div className="absolute left-0 top-0 bottom-0 w-8 bg-gradient-to-r from-black/50 via-black/20 to-transparent shadow-inner" />
          <div className="absolute left-7 top-0 bottom-0 w-0.5 bg-black/40 blur-[0.5px]" />

          {/* Gold Debossed Monogram & Inscription Frame */}
          <div
            className="absolute inset-8 sm:inset-10 border rounded-xs flex flex-col items-center justify-between p-6 sm:p-8 pointer-events-none transition-colors"
            style={{ borderColor: `${currentTheme.foilColor}55` }}
          >
            {/* Monogram Seal */}
            <div
              className="w-9 h-9 rounded-full border flex items-center justify-center shadow-xs"
              style={{ borderColor: currentTheme.foilColor }}
            >
              <span
                className="font-serif text-sm font-bold tracking-widest"
                style={{ color: currentTheme.foilColor }}
              >
                {authorName.charAt(0).toUpperCase()}
              </span>
            </div>

            {/* Central Typography Title */}
            <div className="text-center space-y-2">
              <span
                className="text-[10px] sm:text-xs font-sans tracking-[0.3em] uppercase block opacity-80"
                style={{ color: currentTheme.foilColor }}
              >
                The Personal Journal
              </span>
              <h1
                className="font-serif text-3xl sm:text-4xl font-medium tracking-widest drop-shadow-xs"
                style={{ color: currentTheme.textColor }}
              >
                CHRONICLE
              </h1>
              <p
                className="font-serif italic text-xs sm:text-sm opacity-90"
                style={{ color: currentTheme.foilColor }}
              >
                Observations, Plans & Quiet Thoughts
              </p>
              <div
                className="w-16 h-px mx-auto mt-2"
                style={{ backgroundColor: `${currentTheme.foilColor}66` }}
              />
              <p
                className="font-sans text-[11px] tracking-widest uppercase pt-1 opacity-70"
                style={{ color: currentTheme.foilColor }}
              >
                {authorName}&apos;s Book
              </p>
            </div>

            {/* Tap to Open Prompt */}
            <div
              className="flex items-center gap-2 text-xs font-sans px-3.5 py-1.5 rounded-full border backdrop-blur-xs group-hover:scale-105 transition-all shadow-xs"
              style={{
                backgroundColor: currentTheme.id === 'ivory' ? '#ffffffcc' : '#00000044',
                borderColor: `${currentTheme.foilColor}66`,
                color: currentTheme.textColor,
              }}
            >
              <BookOpen className="w-3.5 h-3.5" style={{ color: currentTheme.foilColor }} />
              <span>Tap to Open Journal</span>
            </div>
          </div>

          {/* Silk Ribbon Bookmark draped outside */}
          <div
            className="absolute -bottom-8 right-16 w-5 h-16 shadow-lg rounded-b-xs transform -rotate-2 group-hover:translate-y-1 transition-transform"
            style={{
              backgroundColor: themeAesthetic.ribbonColor,
              clipPath: 'polygon(0% 0%, 100% 0%, 100% 100%, 50% 85%, 0% 100%)',
            }}
          />
        </div>
      </div>
    );
  }

  return (
    <div className="w-full h-full flex-1 min-h-0 flex flex-col items-center justify-center p-1 sm:p-2 perspective-book select-none overflow-hidden">
      {/* Outer book wrapper with layered paper edge depth and shadow */}
      <div
        className="w-full max-w-6xl h-full max-h-[calc(100vh-64px)] md:aspect-[1.45/1] rounded-lg relative flex flex-col shadow-2xl transition-all duration-300 transform-style-3d overflow-hidden"
        style={{
          boxShadow: `0 25px 60px -15px ${themeAesthetic.bookEdgeShadow}, 0 10px 25px -5px rgba(45, 30, 20, 0.12), 0 0 0 1px rgba(180, 160, 140, 0.3)`,
        }}
      >
        {/* Layered page edges on sides */}
        <div className="absolute inset-y-2 -left-1 w-2 bg-gradient-to-r from-stone-400/30 to-stone-200/20 rounded-l shadow-xs pointer-events-none" />
        <div className="absolute inset-y-2 -right-1 w-2 bg-gradient-to-l from-stone-400/30 to-stone-200/20 rounded-r shadow-xs pointer-events-none" />

        {/* Central Spine Gutter Highlight & Shadow Line */}
        <div className="hidden md:block absolute top-0 bottom-0 left-1/2 -translate-x-1/2 w-8 z-30 pointer-events-none">
          <div className="w-full h-full bg-gradient-to-r from-black/10 via-black/25 to-black/10" />
          <div className="absolute top-0 bottom-0 left-1/2 -translate-x-1/2 w-0.5 bg-stone-900/30" />
        </div>

        {/* Subtle Silk Ribbon Bookmark hanging from spine top */}
        <div
          className="absolute -top-1 left-[50.5%] -translate-x-1/2 w-4 h-24 shadow-md z-35 pointer-events-none transform -rotate-1 rounded-b-xs"
          style={{
            backgroundColor: themeAesthetic.ribbonColor,
            clipPath: 'polygon(0% 0%, 100% 0%, 100% 100%, 50% 88%, 0% 100%)',
          }}
        />

        {/* Realistic Page Turn Animation Overlay */}
        {isTurningPage && (
          <div className="absolute inset-0 z-40 pointer-events-none bg-gradient-to-r from-stone-900/10 via-amber-900/15 to-transparent transition-opacity duration-500 animate-pulse" />
        )}

        {/* The Two Pages Content Spread */}
        <div className="w-full h-full flex flex-col md:flex-row relative z-20 overflow-hidden">
          {children}
        </div>
      </div>
    </div>
  );
};
