/**
 * Closing Ritual Modal Component
 * Evening reflection ritual with 3 mindful prompts before closing the journal
 */

import React, { useState } from 'react';
import { Moon, Sparkles, X, Check } from 'lucide-react';
import { formatSerifDate } from '../utils/storage';
import { playChimeSound, playPageTurnSound } from '../utils/audio';

interface ClosingRitualModalProps {
  date: string;
  isOpen: boolean;
  onClose: () => void;
  onCompleteRitualAndCloseBook: () => void;
  audioEnabled: boolean;
}

export const ClosingRitualModal: React.FC<ClosingRitualModalProps> = ({
  date,
  isOpen,
  onClose,
  onCompleteRitualAndCloseBook,
  audioEnabled,
}) => {
  const [gratitude, setGratitude] = useState('');
  const [release, setRelease] = useState('');
  const [tomorrowHope, setTomorrowHope] = useState('');

  if (!isOpen) return null;

  const handleFinish = () => {
    if (audioEnabled) {
      playChimeSound(true);
      setTimeout(() => {
        playPageTurnSound(true);
      }, 300);
    }
    onCompleteRitualAndCloseBook();
  };

  return (
    <div className="fixed inset-0 z-50 bg-stone-900/40 backdrop-blur-xs flex items-center justify-center p-4">
      <div className="bg-[#fbf8f2] border border-[#d8d0bf] rounded-2xl p-6 sm:p-8 max-w-lg w-full shadow-2xl relative select-none">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-stone-400 hover:text-stone-700 p-1"
        >
          <X className="w-4 h-4" />
        </button>

        {/* Header */}
        <div className="text-center mb-6">
          <div className="w-10 h-10 rounded-full bg-amber-900/10 text-amber-900 flex items-center justify-center mx-auto mb-2">
            <Moon className="w-5 h-5 text-amber-800" />
          </div>
          <span className="text-[11px] font-sans font-medium uppercase tracking-[0.2em] text-stone-500 block">
            Evening Closing Ritual
          </span>
          <h3 className="font-serif text-2xl font-medium text-stone-900 mt-1">
            Resting the Day
          </h3>
          <p className="font-serif italic text-xs text-stone-500 mt-1">
            {formatSerifDate(date)}
          </p>
        </div>

        {/* The 3 Mindful Prompts */}
        <div className="space-y-4 mb-6">
          <div>
            <label className="text-xs font-serif font-semibold text-stone-800 block mb-1">
              1. What quiet moment brought you gratitude today?
            </label>
            <input
              type="text"
              value={gratitude}
              onChange={(e) => setGratitude(e.target.value)}
              placeholder="The warmth of morning tea, laughter, gentle rain..."
              className="w-full text-xs font-serif p-2 bg-[#f4efe5]/60 border border-stone-300 rounded-md text-stone-800 placeholder-stone-400 focus:outline-hidden focus:border-amber-700"
            />
          </div>

          <div>
            <label className="text-xs font-serif font-semibold text-stone-800 block mb-1">
              2. What burden or tension are you gently releasing tonight?
            </label>
            <input
              type="text"
              value={release}
              onChange={(e) => setRelease(e.target.value)}
              placeholder="I release unfinished tasks; I am enough today..."
              className="w-full text-xs font-serif p-2 bg-[#f4efe5]/60 border border-stone-300 rounded-md text-stone-800 placeholder-stone-400 focus:outline-hidden focus:border-amber-700"
            />
          </div>

          <div>
            <label className="text-xs font-serif font-semibold text-stone-800 block mb-1">
              3. What hope will you welcome tomorrow with?
            </label>
            <input
              type="text"
              value={tomorrowHope}
              onChange={(e) => setTomorrowHope(e.target.value)}
              placeholder="Fresh morning light and unhurried steps..."
              className="w-full text-xs font-serif p-2 bg-[#f4efe5]/60 border border-stone-300 rounded-md text-stone-800 placeholder-stone-400 focus:outline-hidden focus:border-amber-700"
            />
          </div>
        </div>

        {/* Action Buttons */}
        <div className="flex items-center justify-end gap-3 pt-2 border-t border-stone-200">
          <button
            onClick={onClose}
            className="px-3.5 py-2 text-xs font-sans text-stone-600 hover:bg-stone-200/60 rounded-md transition-colors"
          >
            Keep Journal Open
          </button>
          <button
            onClick={handleFinish}
            className="px-4 py-2 bg-stone-900 hover:bg-stone-800 text-amber-50 text-xs font-medium rounded-md transition-colors flex items-center gap-1.5 shadow-xs"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Complete Ritual & Close Journal</span>
          </button>
        </div>
      </div>
    </div>
  );
};
