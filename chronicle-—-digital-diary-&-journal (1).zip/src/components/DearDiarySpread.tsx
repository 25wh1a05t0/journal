/**
 * Dear Diary Spread — Real Stylus Handwriting Engine & Reflective Writing Page
 */

import React, { useRef, useState, useEffect, useCallback } from 'react';
import {
  PenTool,
  Pencil,
  Highlighter,
  Eraser,
  Undo2,
  Redo2,
  Trash2,
  Type,
  Sparkles,
  ChevronDown,
} from 'lucide-react';
import { DiaryEntry, HandwritingStroke, DrawingTool, StrokePoint } from '../types/diary';
import { formatSerifDate, WRITING_PROMPTS } from '../utils/storage';
import { playPenStrokeSound } from '../utils/audio';

interface DearDiarySpreadProps {
  date: string;
  entry: DiaryEntry;
  onSaveEntry: (entry: DiaryEntry) => void;
  audioEnabled: boolean;
  rulingType: 'ruled' | 'dotted' | 'blank';
  paperToneClass: string;
}

const INK_PALETTE = [
  { name: 'Charcoal Ink', color: '#231f1c' },
  { name: 'Antique Terracotta', color: '#9a3412' },
  { name: 'Forest Pine', color: '#1e392a' },
  { name: 'Indigo Deep', color: '#1e293b' },
  { name: 'Dusty Rose', color: '#884a56' },
  { name: 'Walnut Ochre', color: '#593e2b' },
];

const STROKE_WIDTHS = [
  { label: 'Fine', value: 2 },
  { label: 'Medium', value: 4 },
  { label: 'Broad', value: 7 },
  { label: 'Chisel', value: 13 },
];

export const DearDiarySpread: React.FC<DearDiarySpreadProps> = ({
  date,
  entry,
  onSaveEntry,
  audioEnabled,
  rulingType,
  paperToneClass,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);

  // Drawing state
  const [activeTool, setActiveTool] = useState<DrawingTool>('pen');
  const [activeColor, setActiveColor] = useState<string>('#231f1c');
  const [strokeWidth, setStrokeWidth] = useState<number>(3);
  const [isDrawing, setIsDrawing] = useState(false);
  const [currentStroke, setCurrentStroke] = useState<StrokePoint[]>([]);
  const [strokes, setStrokes] = useState<HandwritingStroke[]>(entry.strokes || []);
  const [redoStack, setRedoStack] = useState<HandwritingStroke[]>([]);
  const [inputMode, setInputMode] = useState<'handwriting' | 'typed' | 'split'>('handwriting');
  const [typedContent, setTypedContent] = useState<string>(entry.typedText || '');
  const [currentPrompt, setCurrentPrompt] = useState<string>(
    entry.writingPrompt || WRITING_PROMPTS[0]
  );
  const [gratitudes, setGratitudes] = useState<[string, string, string]>(
    entry.gratitudes || ['', '', '']
  );
  const [showClearConfirm, setShowClearConfirm] = useState(false);

  // Sync when date changes
  useEffect(() => {
    setStrokes(entry.strokes || []);
    setRedoStack([]);
    setTypedContent(entry.typedText || '');
    setCurrentPrompt(entry.writingPrompt || WRITING_PROMPTS[0]);
    setGratitudes(entry.gratitudes || ['', '', '']);
  }, [date, entry]);

  // Render all strokes onto canvas with scale factor
  const redrawCanvas = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    // Clear canvas
    ctx.clearRect(0, 0, canvas.width, canvas.height);

    // Draw all strokes
    strokes.forEach((s) => {
      if (!s.points || s.points.length === 0) return;

      ctx.save();
      ctx.beginPath();
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      if (s.tool === 'highlighter') {
        ctx.strokeStyle = s.color + '45'; // Translucent
        ctx.lineWidth = s.width * 2.4;
        ctx.globalCompositeOperation = 'multiply';
      } else if (s.tool === 'eraser') {
        ctx.strokeStyle = '#fcfaf5'; // Paper color
        ctx.lineWidth = s.width * 3.5;
        ctx.globalCompositeOperation = 'destination-out';
      } else if (s.tool === 'pencil') {
        ctx.strokeStyle = s.color + 'cc';
        ctx.lineWidth = Math.max(1, s.width * 0.9);
      } else {
        // Pen
        ctx.strokeStyle = s.color;
        ctx.lineWidth = s.width;
      }

      if (s.points.length === 1) {
        ctx.arc(s.points[0].x, s.points[0].y, ctx.lineWidth / 2, 0, Math.PI * 2);
        ctx.fillStyle = ctx.strokeStyle;
        ctx.fill();
      } else {
        ctx.moveTo(s.points[0].x, s.points[0].y);
        for (let i = 1; i < s.points.length; i++) {
          const prev = s.points[i - 1];
          const curr = s.points[i];
          const midX = (prev.x + curr.x) / 2;
          const midY = (prev.y + curr.y) / 2;
          ctx.quadraticCurveTo(prev.x, prev.y, midX, midY);
        }
        const last = s.points[s.points.length - 1];
        ctx.lineTo(last.x, last.y);
        ctx.stroke();
      }
      ctx.restore();
    });
  }, [strokes]);

  // Resize canvas when container bounds change without triggering ResizeObserver loop errors
  useEffect(() => {
    const canvas = canvasRef.current;
    const container = containerRef.current;
    if (!canvas || !container) return;

    let rafId: number | null = null;
    let prevWidth = 0;
    let prevHeight = 0;

    const resizeObserver = new ResizeObserver((entries) => {
      if (!entries || entries.length === 0) return;
      const entry = entries[0];
      const width = Math.round(entry.contentRect.width);
      const height = Math.round(entry.contentRect.height);

      if (width === 0 || height === 0) return;
      if (width === prevWidth && height === prevHeight) return;

      prevWidth = width;
      prevHeight = height;

      if (rafId !== null) {
        cancelAnimationFrame(rafId);
      }

      rafId = window.requestAnimationFrame(() => {
        if (!canvas) return;
        const dpr = window.devicePixelRatio || 1;
        canvas.width = width * dpr;
        canvas.height = height * dpr;

        const ctx = canvas.getContext('2d');
        if (ctx) {
          ctx.scale(dpr, dpr);
        }
        redrawCanvas();
      });
    });

    resizeObserver.observe(container);
    return () => {
      if (rafId !== null) {
        cancelAnimationFrame(rafId);
      }
      resizeObserver.disconnect();
    };
  }, [redrawCanvas]);

  // Debounced auto-save
  const triggerSave = useCallback(
    (newStrokes: HandwritingStroke[], text: string, grats: [string, string, string], prompt: string) => {
      onSaveEntry({
        ...entry,
        date,
        strokes: newStrokes,
        typedText: text,
        gratitudes: grats,
        writingPrompt: prompt,
        updatedAt: Date.now(),
      });
    },
    [date, entry, onSaveEntry]
  );

  // Pointer event handlers for natural stylus, touch, mouse
  const handlePointerDown = (e: React.PointerEvent<HTMLCanvasElement>) => {
    e.preventDefault();
    const canvas = canvasRef.current;
    if (!canvas) return;

    // Stylus / palm rejection handling: primary button or pen touch
    if (e.buttons !== 1 && e.pointerType === 'mouse') return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const pressure = e.pressure && e.pressure > 0 ? e.pressure : 0.5;

    setIsDrawing(true);
    setCurrentStroke([{ x, y, pressure }]);

    if (audioEnabled) {
      playPenStrokeSound(true);
    }
  };

  const handlePointerMove = (e: React.PointerEvent<HTMLCanvasElement>) => {
    if (!isDrawing) return;
    e.preventDefault();

    const canvas = canvasRef.current;
    if (!canvas) return;

    const rect = canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const pressure = e.pressure && e.pressure > 0 ? e.pressure : 0.5;

    const updatedPoints = [...currentStroke, { x, y, pressure }];
    setCurrentStroke(updatedPoints);

    // Live preview stroke directly on canvas
    const ctx = canvas.getContext('2d');
    if (ctx && updatedPoints.length >= 2) {
      ctx.save();
      const p1 = updatedPoints[updatedPoints.length - 2];
      const p2 = updatedPoints[updatedPoints.length - 1];

      ctx.beginPath();
      ctx.lineCap = 'round';
      ctx.lineJoin = 'round';

      const effectiveWidth =
        activeTool === 'pen'
          ? Math.max(1, strokeWidth * (0.6 + pressure * 0.8))
          : activeTool === 'pencil'
          ? strokeWidth * 0.8
          : activeTool === 'highlighter'
          ? strokeWidth * 2.4
          : strokeWidth * 3.5;

      ctx.lineWidth = effectiveWidth;

      if (activeTool === 'highlighter') {
        ctx.strokeStyle = activeColor + '45';
        ctx.globalCompositeOperation = 'multiply';
      } else if (activeTool === 'eraser') {
        ctx.strokeStyle = '#fcfaf5';
        ctx.globalCompositeOperation = 'destination-out';
      } else if (activeTool === 'pencil') {
        ctx.strokeStyle = activeColor + 'b3';
      } else {
        ctx.strokeStyle = activeColor;
      }

      ctx.moveTo(p1.x, p1.y);
      ctx.lineTo(p2.x, p2.y);
      ctx.stroke();
      ctx.restore();
    }
  };

  const handlePointerUp = () => {
    if (!isDrawing) return;
    setIsDrawing(false);

    if (currentStroke.length > 0) {
      const newStroke: HandwritingStroke = {
        tool: activeTool,
        color: activeColor,
        width: strokeWidth,
        points: currentStroke,
      };
      const updated = [...strokes, newStroke];
      setStrokes(updated);
      setRedoStack([]); // Clear redo after new action
      triggerSave(updated, typedContent, gratitudes, currentPrompt);
    }
    setCurrentStroke([]);
  };

  const handleUndo = () => {
    if (strokes.length === 0) return;
    const last = strokes[strokes.length - 1];
    const updated = strokes.slice(0, -1);
    setStrokes(updated);
    setRedoStack((prev) => [...prev, last]);
    triggerSave(updated, typedContent, gratitudes, currentPrompt);
  };

  const handleRedo = () => {
    if (redoStack.length === 0) return;
    const strokeToRestore = redoStack[redoStack.length - 1];
    const updatedRedo = redoStack.slice(0, -1);
    const updatedStrokes = [...strokes, strokeToRestore];
    setStrokes(updatedStrokes);
    setRedoStack(updatedRedo);
    triggerSave(updatedStrokes, typedContent, gratitudes, currentPrompt);
  };

  const handleClear = () => {
    setStrokes([]);
    setRedoStack([]);
    setShowClearConfirm(false);
    triggerSave([], typedContent, gratitudes, currentPrompt);
  };

  const cyclePrompt = () => {
    const idx = WRITING_PROMPTS.indexOf(currentPrompt);
    const next = WRITING_PROMPTS[(idx + 1) % WRITING_PROMPTS.length];
    setCurrentPrompt(next);
    triggerSave(strokes, typedContent, gratitudes, next);
  };

  const handleTextChange = (val: string) => {
    setTypedContent(val);
    triggerSave(strokes, val, gratitudes, currentPrompt);
  };

  const handleGratitudeChange = (index: number, val: string) => {
    const next: [string, string, string] = [...gratitudes] as [string, string, string];
    next[index] = val;
    setGratitudes(next);
    triggerSave(strokes, typedContent, next, currentPrompt);
  };

  const rulingClass =
    rulingType === 'ruled'
      ? 'paper-ruled'
      : rulingType === 'dotted'
      ? 'paper-dotted'
      : '';

  return (
    <div className="w-full h-full flex flex-col md:flex-row divide-y md:divide-y-0 md:divide-x divide-stone-300/60 overflow-hidden">
      {/* LEFT PAGE: Handwritten Digital Writing Canvas */}
      <div className={`flex-1 flex flex-col h-full relative ${paperToneClass} book-spine-left p-6 sm:p-8 select-none`}>
        {/* Page Header */}
        <div className="flex items-start justify-between border-b border-stone-200/80 pb-3 mb-3">
          <div>
            <span className="font-handwriting text-2xl sm:text-3xl text-amber-900 tracking-wide block leading-none">
              Dear Diary,
            </span>
            <p className="font-serif text-xs sm:text-sm text-stone-600 mt-1">
              {formatSerifDate(date)}
            </p>
          </div>

          {/* Minimal Prompt Switcher */}
          <button
            onClick={cyclePrompt}
            title="Click to cycle inspiration prompt"
            className="flex items-center gap-1.5 text-[11px] font-sans text-stone-500 hover:text-stone-800 bg-stone-100/70 hover:bg-stone-200/60 px-2.5 py-1 rounded-md transition-colors max-w-[200px] truncate"
          >
            <Sparkles className="w-3 h-3 text-amber-700 shrink-0" />
            <span className="truncate italic">{currentPrompt}</span>
          </button>
        </div>

        {/* Floating Minimal Writing Toolbar */}
        <div className="mb-2 flex items-center justify-between gap-2 p-1.5 bg-[#f4efe5]/90 border border-stone-300/70 rounded-lg shadow-xs backdrop-blur-xs z-20">
          {/* Drawing Tools */}
          <div className="flex items-center gap-1">
            <button
              onClick={() => setActiveTool('pen')}
              title="Ink Pen (Stylus Pressure Support)"
              className={`p-1.5 rounded-md transition-colors ${
                activeTool === 'pen' ? 'bg-[#e2d8c3] text-stone-900 shadow-xs' : 'text-stone-600 hover:bg-stone-200/60'
              }`}
            >
              <PenTool className="w-4 h-4" />
            </button>
            <button
              onClick={() => setActiveTool('pencil')}
              title="Graphite Pencil"
              className={`p-1.5 rounded-md transition-colors ${
                activeTool === 'pencil' ? 'bg-[#e2d8c3] text-stone-900 shadow-xs' : 'text-stone-600 hover:bg-stone-200/60'
              }`}
            >
              <Pencil className="w-4 h-4" />
            </button>
            <button
              onClick={() => setActiveTool('highlighter')}
              title="Highlighter"
              className={`p-1.5 rounded-md transition-colors ${
                activeTool === 'highlighter' ? 'bg-[#e2d8c3] text-stone-900 shadow-xs' : 'text-stone-600 hover:bg-stone-200/60'
              }`}
            >
              <Highlighter className="w-4 h-4" />
            </button>
            <button
              onClick={() => setActiveTool('eraser')}
              title="Eraser"
              className={`p-1.5 rounded-md transition-colors ${
                activeTool === 'eraser' ? 'bg-[#e2d8c3] text-stone-900 shadow-xs' : 'text-stone-600 hover:bg-stone-200/60'
              }`}
            >
              <Eraser className="w-4 h-4" />
            </button>
          </div>

          <div className="h-4 w-px bg-stone-300" aria-hidden="true" />

          {/* Stroke Width Picker */}
          <div className="flex items-center gap-1">
            {STROKE_WIDTHS.map((sw) => (
              <button
                key={sw.label}
                onClick={() => setStrokeWidth(sw.value)}
                title={`${sw.label} (${sw.value}px)`}
                className={`w-6 h-6 rounded-md flex items-center justify-center transition-colors ${
                  strokeWidth === sw.value ? 'bg-[#e2d8c3]' : 'hover:bg-stone-200/60'
                }`}
              >
                <span
                  className="rounded-full bg-stone-800"
                  style={{ width: `${sw.value + 1}px`, height: `${sw.value + 1}px` }}
                />
              </button>
            ))}
          </div>

          <div className="h-4 w-px bg-stone-300" aria-hidden="true" />

          {/* Ink Palette */}
          <div className="flex items-center gap-1">
            {INK_PALETTE.map((ink) => (
              <button
                key={ink.name}
                onClick={() => setActiveColor(ink.color)}
                title={ink.name}
                className={`w-5 h-5 rounded-full border transition-transform ${
                  activeColor === ink.color ? 'scale-115 border-stone-800 ring-2 ring-stone-400' : 'border-stone-300'
                }`}
                style={{ backgroundColor: ink.color }}
              />
            ))}
          </div>

          {/* Mode Switcher: Stylus vs Type vs Both */}
          <div className="flex items-center gap-1 bg-[#ebe3d3] p-0.5 rounded-md border border-stone-300">
            <button
              onClick={() => setInputMode('handwriting')}
              title="Stylus Drawing Mode"
              className={`flex items-center gap-1 px-2 py-1 text-[11px] font-sans rounded transition-colors ${
                inputMode === 'handwriting'
                  ? 'bg-white text-stone-900 font-semibold shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <PenTool className="w-3 h-3 text-amber-800" />
              <span className="hidden sm:inline">Stylus</span>
            </button>
            <button
              onClick={() => setInputMode('typed')}
              title="Keyboard Typed Text Mode"
              className={`flex items-center gap-1 px-2 py-1 text-[11px] font-sans rounded transition-colors ${
                inputMode === 'typed'
                  ? 'bg-white text-stone-900 font-semibold shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Type className="w-3 h-3 text-amber-800" />
              <span className="hidden sm:inline">Type</span>
            </button>
            <button
              onClick={() => setInputMode('split')}
              title="Dual Layered Mode (Type & Draw with Stylus Together)"
              className={`flex items-center gap-1 px-2 py-1 text-[11px] font-sans rounded transition-colors ${
                inputMode === 'split'
                  ? 'bg-white text-stone-900 font-semibold shadow-xs'
                  : 'text-stone-600 hover:text-stone-900'
              }`}
            >
              <Sparkles className="w-3 h-3 text-amber-800" />
              <span className="hidden sm:inline">Both</span>
            </button>
          </div>

          <div className="h-4 w-px bg-stone-300" aria-hidden="true" />

          {/* History Controls */}
          <div className="flex items-center gap-0.5">
            <button
              onClick={handleUndo}
              disabled={strokes.length === 0}
              title="Undo Stroke"
              className="p-1.5 text-stone-600 hover:bg-stone-200/60 rounded-md disabled:opacity-30 disabled:cursor-not-allowed"
            >
              <Undo2 className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={handleRedo}
              disabled={redoStack.length === 0}
              title="Redo Stroke"
              className="p-1.5 text-stone-600 hover:bg-stone-200/60 rounded-md disabled:opacity-30 disabled:cursor-not-allowed"
            >
              <Redo2 className="w-3.5 h-3.5" />
            </button>
            <button
              onClick={() => setShowClearConfirm(true)}
              title="Clear Canvas"
              className="p-1.5 text-stone-600 hover:text-red-700 hover:bg-red-50 rounded-md"
            >
              <Trash2 className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>

        {/* Clear Confirmation Modal */}
        {showClearConfirm && (
          <div className="absolute inset-0 bg-stone-900/30 backdrop-blur-xs flex items-center justify-center z-50 p-4">
            <div className="bg-[#fdfbf7] border border-stone-300 rounded-xl p-5 max-w-xs w-full shadow-xl">
              <h4 className="font-serif text-base font-semibold text-stone-800">Clear Handwritten Page?</h4>
              <p className="text-xs text-stone-600 mt-2">
                This will remove all drawn strokes for this date. You can start fresh or write again.
              </p>
              <div className="mt-4 flex justify-end gap-2">
                <button
                  onClick={() => setShowClearConfirm(false)}
                  className="px-3 py-1.5 text-xs text-stone-600 hover:bg-stone-100 rounded-md"
                >
                  Cancel
                </button>
                <button
                  onClick={handleClear}
                  className="px-3 py-1.5 text-xs bg-red-700 text-white rounded-md hover:bg-red-800"
                >
                  Clear Page
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Active Writing Surface Container with Dual Stylus & Typing Support */}
        <div
          ref={containerRef}
          className={`flex-1 relative w-full rounded-md border border-stone-200/60 shadow-inner overflow-hidden ${
            inputMode === 'typed' ? 'cursor-text' : 'cursor-crosshair'
          } ${rulingClass}`}
          style={{ touchAction: inputMode === 'typed' ? 'auto' : 'none' }}
        >
          {/* Direct On-Page Textarea for typing into the lined paper */}
          {(inputMode === 'typed' || inputMode === 'split') && (
            <textarea
              value={typedContent}
              onChange={(e) => handleTextChange(e.target.value)}
              placeholder="Start typing your diary entry here... It flows seamlessly across the paper lines."
              className={`absolute inset-0 w-full h-full p-4 bg-transparent resize-none focus:outline-hidden font-handwriting text-xl sm:text-2xl leading-8 text-stone-800 ${
                inputMode === 'split' ? 'z-10' : 'z-20'
              }`}
              style={{ lineHeight: '32px' }}
            />
          )}

          {/* Prompt when empty */}
          {strokes.length === 0 && !typedContent && inputMode === 'handwriting' && (
            <div className="absolute inset-0 flex items-center justify-center pointer-events-none opacity-40 select-none z-5">
              <p className="font-handwriting text-2xl text-stone-400">
                Write freely with your stylus or pen…
              </p>
            </div>
          )}

          {/* Drawing Canvas */}
          <canvas
            ref={canvasRef}
            onPointerDown={handlePointerDown}
            onPointerMove={handlePointerMove}
            onPointerUp={handlePointerUp}
            onPointerLeave={handlePointerUp}
            onPointerCancel={handlePointerUp}
            className={`w-full h-full block ${
              inputMode === 'typed'
                ? 'pointer-events-none z-10 opacity-70'
                : inputMode === 'split'
                ? 'pointer-events-auto z-20'
                : 'pointer-events-auto z-20'
            }`}
          />

          {/* Quick toggle banner in split mode */}
          {inputMode === 'split' && (
            <div className="absolute bottom-2 right-2 z-30 flex items-center gap-1 bg-[#f4efe5]/90 border border-stone-300 px-2 py-1 rounded-md text-[10px] font-sans text-stone-600 shadow-xs">
              <span className="font-medium text-amber-900">Dual Mode:</span>
              <span>Type below &amp; draw with stylus above</span>
            </div>
          )}
        </div>

        {/* Left Page Footer */}
        <div className="mt-3 flex items-center justify-between text-[11px] text-stone-400 font-serif">
          <span>Strokes: {strokes.length} &bull; Mode: {inputMode === 'split' ? 'Dual' : inputMode === 'typed' ? 'Type' : 'Stylus'}</span>
          <span>p. 142</span>
        </div>
      </div>

      {/* RIGHT PAGE: Editorial Journal Entry & Daily Gratitudes */}
      <div className={`flex-1 flex flex-col h-full relative ${paperToneClass} book-spine-right p-6 sm:p-8 select-text`}>
        {/* Right Page Header */}
        <div className="border-b border-stone-200/80 pb-3 mb-4 flex items-center justify-between">
          <div>
            <span className="font-serif text-lg font-semibold text-stone-900 tracking-tight">
              Quiet Reflections
            </span>
            <p className="text-xs text-stone-500 font-sans mt-0.5">
              Typed entry & evening gratitude
            </p>
          </div>
          <span className="text-xs font-handwriting text-amber-800 text-lg">
            A little reflection
          </span>
        </div>

        {/* Typed Journal Entry with Ruled Texture */}
        <div className="flex-1 flex flex-col mb-4">
          <label className="text-[11px] font-sans font-medium text-stone-500 tracking-wider uppercase mb-1">
            Thoughts & Observations
          </label>
          <div className="flex-1 relative">
            <textarea
              value={typedContent}
              onChange={(e) => handleTextChange(e.target.value)}
              placeholder="Reflect on the day here, or capture feelings that words can express..."
              className="w-full h-full bg-transparent resize-none font-body-serif text-sm leading-relaxed text-stone-800 focus:outline-hidden p-2 border border-stone-200/50 rounded-md"
              style={{
                backgroundImage:
                  'repeating-linear-gradient(transparent, transparent 31px, rgba(180, 160, 140, 0.15) 31px, rgba(180, 160, 140, 0.15) 32px)',
                lineHeight: '32px',
              }}
            />
          </div>
        </div>

        {/* Daily Gratitudes Section */}
        <div className="pt-3 border-t border-stone-200/80">
          <span className="font-handwriting text-xl text-stone-700 block mb-2">
            Three Quiet Gratitudes
          </span>
          <div className="space-y-2">
            {[0, 1, 2].map((i) => (
              <div key={i} className="flex items-center gap-2">
                <span className="font-serif text-xs text-amber-800 w-3">{i + 1}.</span>
                <input
                  type="text"
                  value={gratitudes[i] || ''}
                  onChange={(e) => handleGratitudeChange(i, e.target.value)}
                  placeholder={
                    i === 0
                      ? 'A warm cup of morning tea...'
                      : i === 1
                      ? 'Kind words from a friend...'
                      : 'The quiet hour before sunset...'
                  }
                  className="flex-1 text-xs font-serif bg-transparent border-b border-stone-300 focus:border-amber-700 py-1 text-stone-800 placeholder-stone-400 focus:outline-hidden"
                />
              </div>
            ))}
          </div>
        </div>

        {/* Right Page Footer */}
        <div className="mt-4 pt-2 border-t border-stone-200/60 flex items-center justify-between text-[11px] text-stone-400 font-serif">
          <span>Words: {typedContent.trim() ? typedContent.trim().split(/\s+/).length : 0}</span>
          <span>p. 143</span>
        </div>
      </div>
    </div>
  );
};
