/**
 * Lock Screen Component
 * Refined antique lock screen for private diary protection with PIN pad
 */

import React, { useState } from 'react';
import { Lock, KeyRound, ShieldAlert } from 'lucide-react';
import { playChimeSound } from '../utils/audio';

interface LockScreenProps {
  correctPin?: string;
  onUnlock: () => void;
  onCancel?: () => void;
  audioEnabled: boolean;
}

export const LockScreen: React.FC<LockScreenProps> = ({
  correctPin = '0000',
  onUnlock,
  onCancel,
  audioEnabled,
}) => {
  const [pin, setPin] = useState('');
  const [hasError, setHasError] = useState(false);

  const handleKeyPress = (num: string) => {
    if (pin.length < 4) {
      const next = pin + num;
      setPin(next);
      setHasError(false);

      if (next.length === 4) {
        if (next === correctPin) {
          if (audioEnabled) playChimeSound(true);
          onUnlock();
        } else {
          setHasError(true);
          setTimeout(() => setPin(''), 600);
        }
      }
    }
  };

  const handleBackspace = () => {
    setPin((prev) => prev.slice(0, -1));
    setHasError(false);
  };

  return (
    <div className="fixed inset-0 z-50 bg-[#25201b]/80 backdrop-blur-md flex items-center justify-center p-4 select-none">
      <div className="bg-[#fbf8f2] border border-[#d8d0bf] rounded-2xl p-6 sm:p-8 max-w-xs w-full shadow-2xl text-center">
        <div className="w-12 h-12 rounded-full bg-amber-900/10 text-amber-900 flex items-center justify-center mx-auto mb-3">
          <Lock className="w-6 h-6 text-amber-900" />
        </div>

        <h3 className="font-serif text-2xl font-medium text-stone-900">Private Journal</h3>
        <p className="text-xs text-stone-500 font-sans mt-1">Enter your 4-digit passcode to open</p>

        {/* PIN Dots */}
        <div className="flex items-center justify-center gap-3 my-6">
          {[0, 1, 2, 3].map((i) => (
            <div
              key={i}
              className={`w-3.5 h-3.5 rounded-full border transition-all ${
                pin.length > i
                  ? hasError
                    ? 'bg-red-700 border-red-700'
                    : 'bg-amber-900 border-amber-900 scale-110'
                  : 'border-stone-400 bg-stone-200/50'
              }`}
            />
          ))}
        </div>

        {hasError && (
          <p className="text-xs text-red-700 font-medium -mt-3 mb-3">
            Incorrect passcode. Please try again.
          </p>
        )}

        {/* Numpad */}
        <div className="grid grid-cols-3 gap-2 max-w-[200px] mx-auto mb-2">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((digit) => (
            <button
              key={digit}
              onClick={() => handleKeyPress(digit)}
              className="w-14 h-14 rounded-full bg-[#eee7d8] hover:bg-[#e4dcce] text-stone-800 text-lg font-serif font-medium transition-colors flex items-center justify-center shadow-xs mx-auto"
            >
              {digit}
            </button>
          ))}
          <div />
          <button
            onClick={() => handleKeyPress('0')}
            className="w-14 h-14 rounded-full bg-[#eee7d8] hover:bg-[#e4dcce] text-stone-800 text-lg font-serif font-medium transition-colors flex items-center justify-center shadow-xs mx-auto"
          >
            0
          </button>
          <button
            onClick={handleBackspace}
            className="w-14 h-14 rounded-full bg-[#eee7d8] hover:bg-[#e4dcce] text-stone-600 text-xs font-sans transition-colors flex items-center justify-center mx-auto"
          >
            Delete
          </button>
        </div>

        {onCancel && (
          <button
            onClick={onCancel}
            className="mt-3 text-xs text-stone-500 hover:text-stone-800 font-sans transition-colors"
          >
            Cancel &amp; Return to Cover
          </button>
        )}
      </div>
    </div>
  );
};
