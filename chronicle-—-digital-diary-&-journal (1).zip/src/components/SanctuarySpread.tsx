/**
 * Sanctuary Spread Component
 * Left Page: Emotion Jar with continuously floating animated symbols,
 * unlimited non-repeating affirmations queue, and custom notes.
 * Right Page: Celestial Wish Jar holding hopes as glowing starry emojis.
 */

import React, { useState, useEffect } from 'react';
import {
  Sparkles,
  Plus,
  Bookmark,
  Check,
  Trash2,
  BookmarkCheck,
  RotateCcw,
} from 'lucide-react';
import { AffirmationItem, WishItem } from '../types/diary';
import { playChimeSound } from '../utils/audio';
import { VAST_AFFIRMATIONS, SanctuaryAffirmation } from '../utils/affirmations';

interface SanctuarySpreadProps {
  affirmations: AffirmationItem[];
  onSaveAffirmations: (items: AffirmationItem[]) => void;
  wishes: WishItem[];
  onSaveWishes: (wishes: WishItem[]) => void;
  audioEnabled: boolean;
  paperToneClass: string;
}

const AESTHETIC_EMOJIS = ['⭐', '🌙', '✨', '🌸', '🌿', '🕊️', '🕯️', '🦋', '💎', '☕', '🤍', '🍀', '🍄'];

// Floating objects definition for the jar interior with individual floating trajectories
const JAR_FLOATING_OBJECTS = [
  { emoji: '🌸', anim: 'animate-float-1', left: '18%', bottom: '22%', size: 'text-lg', delay: '0s' },
  { emoji: '✨', anim: 'animate-float-2', left: '46%', bottom: '38%', size: 'text-base', delay: '0.4s' },
  { emoji: '🌙', anim: 'animate-float-3', left: '72%', bottom: '26%', size: 'text-xl', delay: '0.8s' },
  { emoji: '🕊️', anim: 'animate-float-1', left: '32%', bottom: '58%', size: 'text-base', delay: '1.2s' },
  { emoji: '🦋', anim: 'animate-float-2', left: '62%', bottom: '52%', size: 'text-lg', delay: '0.2s' },
  { emoji: '🕯️', anim: 'animate-float-3', left: '16%', bottom: '48%', size: 'text-base', delay: '1.5s' },
  { emoji: '🌿', anim: 'animate-float-1', left: '78%', bottom: '42%', size: 'text-base', delay: '0.6s' },
  { emoji: '💎', anim: 'animate-float-2', left: '42%', bottom: '18%', size: 'text-lg', delay: '1.8s' },
  { emoji: '🤍', anim: 'animate-float-3', left: '54%', bottom: '66%', size: 'text-sm', delay: '1.0s' },
  { emoji: '⭐', anim: 'animate-float-1', left: '26%', bottom: '32%', size: 'text-base', delay: '2.0s' },
];

export const SanctuarySpread: React.FC<SanctuarySpreadProps> = ({
  affirmations,
  onSaveAffirmations,
  wishes,
  onSaveWishes,
  audioEnabled,
  paperToneClass,
}) => {
  // Non-repeating affirmations deck
  const [unseenQueue, setUnseenQueue] = useState<SanctuaryAffirmation[]>(() => {
    const customList: SanctuaryAffirmation[] = affirmations
      .filter((a) => a.isCustom)
      .map((a) => ({
        id: a.id,
        text: a.text,
        emoji: a.emoji || '✨',
        theme: a.theme,
      }));
    const all = [...VAST_AFFIRMATIONS, ...customList];
    return [...all].sort(() => Math.random() - 0.5);
  });

  const [activeAffirmation, setActiveAffirmation] = useState<SanctuaryAffirmation | AffirmationItem | null>(() => {
    return VAST_AFFIRMATIONS[0];
  });
  const [drawnCount, setDrawnCount] = useState<number>(1);
  const [isJarFloating, setIsJarFloating] = useState(false);
  const [newAffText, setNewAffText] = useState('');
  const [newAffEmoji, setNewAffEmoji] = useState('✨');
  const [isAddingAff, setIsAddingAff] = useState(false);

  // Wish Jar state
  const [newWishText, setNewWishText] = useState('');
  const [newWishEmoji, setNewWishEmoji] = useState('⭐');
  const [selectedWish, setSelectedWish] = useState<WishItem | null>(null);
  const [isAddingWish, setIsAddingWish] = useState(false);

  // Draw non-repeating affirmation from the floating jar
  const handleTapEmotionJar = () => {
    setIsJarFloating(true);
    if (audioEnabled) playChimeSound(true);

    setTimeout(() => {
      let currentDeck = [...unseenQueue];
      if (currentDeck.length === 0) {
        // Reshuffle complete library when all have been experienced
        const customList: SanctuaryAffirmation[] = affirmations
          .filter((a) => a.isCustom)
          .map((a) => ({
            id: a.id,
            text: a.text,
            emoji: a.emoji || '✨',
            theme: a.theme,
          }));
        const all = [...VAST_AFFIRMATIONS, ...customList];
        currentDeck = [...all].sort(() => Math.random() - 0.5);
      }

      const nextQuote = currentDeck.pop();
      if (nextQuote) {
        setActiveAffirmation(nextQuote);
        setUnseenQueue(currentDeck);
        setDrawnCount((prev) => prev + 1);
      }
      setIsJarFloating(false);
    }, 400);
  };

  const handleToggleSaveAffirmation = (aff: SanctuaryAffirmation | AffirmationItem) => {
    const existing = affirmations.find((a) => a.text === aff.text);
    if (existing) {
      const next = affirmations.map((a) => (a.id === existing.id ? { ...a, isSaved: !a.isSaved } : a));
      onSaveAffirmations(next);
    } else {
      const newItem: AffirmationItem = {
        id: `aff-saved-${Date.now()}`,
        text: aff.text,
        theme: aff.theme,
        emoji: aff.emoji || '✨',
        isSaved: true,
      };
      onSaveAffirmations([...affirmations, newItem]);
    }
  };

  const handleCreateAffirmation = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newAffText.trim()) return;
    const newItem: AffirmationItem = {
      id: `aff-custom-${Date.now()}`,
      text: newAffText.trim(),
      theme: 'calm',
      emoji: newAffEmoji,
      isCustom: true,
      isSaved: true,
    };
    onSaveAffirmations([...affirmations, newItem]);
    const asSanctuary: SanctuaryAffirmation = {
      id: newItem.id,
      text: newItem.text,
      theme: newItem.theme,
      emoji: newItem.emoji || '✨',
    };
    // Prepend to unseen queue so user immediately sees their own affirmation
    setUnseenQueue((prev) => [asSanctuary, ...prev]);
    setActiveAffirmation(asSanctuary);
    setNewAffText('');
    setIsAddingAff(false);
    if (audioEnabled) playChimeSound(true);
  };

  // Add wish
  const handleCreateWish = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newWishText.trim()) return;
    const colors = ['#e0a96d', '#7ba087', '#c27d88', '#86a8cf', '#d19c6a', '#b784a7'];
    const newWish: WishItem = {
      id: `wish-${Date.now()}`,
      wish: newWishText.trim(),
      createdDate: new Date().toISOString().split('T')[0],
      category: 'dream',
      emoji: newWishEmoji,
      fulfilled: false,
      starColor: colors[Math.floor(Math.random() * colors.length)],
    };
    onSaveWishes([...wishes, newWish]);
    setSelectedWish(newWish);
    setNewWishText('');
    setIsAddingWish(false);
    if (audioEnabled) playChimeSound(true);
  };

  const handleToggleFulfillWish = (id: string) => {
    const next = wishes.map((w) => (w.id === id ? { ...w, fulfilled: !w.fulfilled } : w));
    onSaveWishes(next);
    if (selectedWish && selectedWish.id === id) {
      setSelectedWish({ ...selectedWish, fulfilled: !selectedWish.fulfilled });
    }
  };

  const handleDeleteWish = (id: string) => {
    const next = wishes.filter((w) => w.id !== id);
    onSaveWishes(next);
    if (selectedWish && selectedWish.id === id) {
      setSelectedWish(null);
    }
  };

  const isCurrentAffirmationSaved = Boolean(
    activeAffirmation && affirmations.some((a) => a.text === activeAffirmation.text && a.isSaved)
  );

  return (
    <div className="w-full h-full flex flex-col md:flex-row divide-y md:divide-y-0 md:divide-x divide-stone-300/60 overflow-hidden">
      {/* LEFT PAGE: Emotion Jar with Floating Emojis & Unlimited Non-Repeating Affirmations */}
      <div className={`flex-1 flex flex-col h-full relative ${paperToneClass} book-spine-left p-6 sm:p-8 select-none overflow-y-auto`}>
        {/* Header */}
        <div className="border-b border-stone-200/80 pb-3 mb-3 flex items-center justify-between">
          <div>
            <span className="text-[11px] font-sans font-medium uppercase tracking-widest text-stone-500 block">
              Sanctuary
            </span>
            <h2 className="font-serif text-2xl font-medium text-stone-900 mt-0.5">
              The Emotion Jar
            </h2>
            <p className="text-[11px] font-sans text-stone-500">
              Unlimited comforting reflections &bull; Never repeats back-to-back
            </p>
          </div>
          <button
            onClick={() => setIsAddingAff(!isAddingAff)}
            className="flex items-center gap-1 px-2.5 py-1 text-xs bg-stone-100 hover:bg-stone-200 rounded-md text-stone-700 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Add Note</span>
          </button>
        </div>

        {/* Add Custom Affirmation Form */}
        {isAddingAff && (
          <form onSubmit={handleCreateAffirmation} className="mb-4 p-3 bg-stone-100/80 border border-stone-200 rounded-lg">
            <span className="text-xs font-semibold text-stone-700 block mb-1">
              Add a Comforting Thought to the Jar
            </span>
            <div className="flex items-center gap-1.5 mb-2 overflow-x-auto no-scrollbar py-1">
              <span className="text-[11px] text-stone-500 font-sans">Symbol:</span>
              {AESTHETIC_EMOJIS.map((em) => (
                <button
                  key={em}
                  type="button"
                  onClick={() => setNewAffEmoji(em)}
                  className={`text-base p-1 rounded transition-transform ${
                    newAffEmoji === em ? 'scale-125 bg-amber-100 ring-1 ring-amber-400' : 'hover:scale-110'
                  }`}
                >
                  {em}
                </button>
              ))}
            </div>
            <input
              type="text"
              value={newAffText}
              onChange={(e) => setNewAffText(e.target.value)}
              placeholder="e.g. My peace is non-negotiable and precious..."
              className="w-full text-xs font-serif p-2 bg-white border border-stone-300 rounded text-stone-800 mb-2 focus:outline-hidden"
            />
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setIsAddingAff(false)}
                className="px-2 py-1 text-xs text-stone-500"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-3 py-1 text-xs bg-stone-800 text-white rounded hover:bg-stone-900"
              >
                Plant in Jar
              </button>
            </div>
          </form>
        )}

        {/* The Illustrated Glass Apothecary Jar with Live Floating Elements */}
        <div className="flex-1 flex flex-col items-center justify-center py-2">
          <div
            onClick={handleTapEmotionJar}
            className={`relative w-44 h-56 cursor-pointer transition-transform duration-300 group select-none ${
              isJarFloating ? 'scale-105' : 'hover:scale-[1.03]'
            }`}
            title="Click to release a fresh non-repeating affirmation"
          >
            {/* Jar Cork */}
            <div className="w-18 h-5 mx-auto bg-[#cbb89d] rounded-t-sm border border-[#ab9579] shadow-xs" />
            {/* Jar Neck */}
            <div className="w-22 h-3.5 mx-auto bg-stone-100/50 border-l border-r border-stone-300" />
            {/* Jar Glass Body */}
            <div className="w-44 h-48 rounded-b-3xl rounded-t-lg bg-gradient-to-b from-stone-100/35 via-amber-50/25 to-stone-200/35 border border-stone-300/80 shadow-md backdrop-blur-2xs p-3 relative overflow-hidden">
              {/* Glass reflection highlight */}
              <div className="absolute top-2 left-3 w-2.5 h-32 bg-white/40 rounded-full blur-[1px] transform -rotate-6 pointer-events-none" />

              {/* Continuously floating emojis and crystals inside the glass */}
              {JAR_FLOATING_OBJECTS.map((obj, i) => (
                <div
                  key={i}
                  className={`absolute ${obj.anim} ${obj.size} filter drop-shadow-xs pointer-events-none transition-transform`}
                  style={{
                    left: obj.left,
                    bottom: obj.bottom,
                    animationDelay: obj.delay,
                  }}
                >
                  <span>{obj.emoji}</span>
                </div>
              ))}
            </div>

            <div className="text-center mt-2">
              <span className="font-handwriting text-lg text-amber-900/80 group-hover:text-amber-950 transition-colors flex items-center justify-center gap-1">
                <span>Tap jar to draw peace</span>
                <Sparkles className="w-3.5 h-3.5 text-amber-700" />
              </span>
            </div>
          </div>

          {/* Active Revealed Affirmation Card */}
          {activeAffirmation && (
            <div className="mt-4 w-full p-4 bg-[#fbf9f4] border border-amber-800/20 rounded-xl shadow-xs transition-all animate-fadeIn">
              <div className="flex items-start justify-between gap-2">
                <div className="flex items-start gap-2.5">
                  <span className="text-2xl shrink-0 mt-0.5">{activeAffirmation.emoji || '✨'}</span>
                  <div>
                    <p className="font-serif italic text-sm sm:text-base text-stone-800 leading-relaxed">
                      &ldquo;{activeAffirmation.text}&rdquo;
                    </p>
                    <span className="text-[10px] font-sans text-stone-400 mt-1 block">
                      Affirmation #{drawnCount} &bull; Fresh &amp; Non-repeating
                    </span>
                  </div>
                </div>
                <button
                  onClick={() => handleToggleSaveAffirmation(activeAffirmation)}
                  title={isCurrentAffirmationSaved ? 'Saved to Sanctuary' : 'Save Affirmation'}
                  className="p-1 text-amber-800 hover:text-amber-950 transition-colors shrink-0"
                >
                  {isCurrentAffirmationSaved ? (
                    <BookmarkCheck className="w-4 h-4 text-amber-800 fill-amber-800" />
                  ) : (
                    <Bookmark className="w-4 h-4" />
                  )}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Saved Affirmations List */}
        <div className="mt-3 pt-3 border-t border-stone-200/60">
          <span className="text-[11px] font-sans font-semibold tracking-wider text-stone-500 uppercase block mb-1.5">
            Saved Affirmations ({affirmations.filter((a) => a.isSaved).length})
          </span>
          <div className="space-y-1 max-h-20 overflow-y-auto pr-1">
            {affirmations
              .filter((a) => a.isSaved)
              .map((aff) => (
                <div
                  key={aff.id}
                  onClick={() => setActiveAffirmation(aff)}
                  className="text-xs font-serif italic text-stone-700 hover:text-amber-900 cursor-pointer truncate py-0.5 flex items-center gap-1.5"
                >
                  <span>{aff.emoji || '✨'}</span>
                  <span className="truncate">&bull; {aff.text}</span>
                </div>
              ))}
          </div>
        </div>

        {/* Left Page Footer */}
        <div className="mt-auto pt-2 border-t border-stone-200/60 flex items-center justify-between text-[11px] text-stone-400 font-serif">
          <span>Sanctuary Collection</span>
          <span>p. 8</span>
        </div>
      </div>

      {/* RIGHT PAGE: The Celestial Wish Jar */}
      <div className={`flex-1 flex flex-col h-full relative ${paperToneClass} book-spine-right p-6 sm:p-8 select-text overflow-y-auto`}>
        {/* Header */}
        <div className="border-b border-stone-200/80 pb-3 mb-4 flex items-center justify-between">
          <div>
            <span className="text-[11px] font-sans font-medium uppercase tracking-widest text-stone-500 block">
              Hopes &amp; Intentions
            </span>
            <h2 className="font-serif text-2xl font-medium text-stone-900 mt-0.5">
              The Celestial Wish Jar
            </h2>
          </div>
          <button
            onClick={() => setIsAddingWish(!isAddingWish)}
            className="flex items-center gap-1 px-2.5 py-1 text-xs bg-stone-100 hover:bg-stone-200 rounded-md text-stone-700 transition-colors"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Plant Wish</span>
          </button>
        </div>

        {/* Add Wish Form with Emoji Selector */}
        {isAddingWish && (
          <form onSubmit={handleCreateWish} className="mb-4 p-3 bg-stone-100/70 border border-stone-200 rounded-lg">
            <span className="text-xs font-semibold text-stone-700 block mb-1">
              Whisper a Wish to the Heavens
            </span>
            <div className="flex items-center gap-1.5 mb-2 overflow-x-auto no-scrollbar py-1">
              <span className="text-[11px] text-stone-500 font-sans">Choose Symbol:</span>
              {AESTHETIC_EMOJIS.map((em) => (
                <button
                  key={em}
                  type="button"
                  onClick={() => setNewWishEmoji(em)}
                  className={`text-base p-1 rounded transition-transform ${
                    newWishEmoji === em ? 'scale-125 bg-amber-100' : 'hover:scale-110'
                  }`}
                >
                  {em}
                </button>
              ))}
            </div>
            <input
              type="text"
              value={newWishText}
              onChange={(e) => setNewWishText(e.target.value)}
              placeholder="What hope does your heart hold?"
              className="w-full text-xs font-serif p-2 bg-white border border-stone-300 rounded text-stone-800 mb-2 focus:outline-hidden"
            />
            <div className="flex justify-end gap-2">
              <button
                type="button"
                onClick={() => setIsAddingWish(false)}
                className="px-2 py-1 text-xs text-stone-500"
              >
                Cancel
              </button>
              <button
                type="submit"
                className="px-3 py-1 text-xs bg-stone-800 text-white rounded hover:bg-stone-900"
              >
                Release {newWishEmoji} Wish
              </button>
            </div>
          </form>
        )}

        {/* Wish Stars & Emojis Night-Sky Jar */}
        <div className="mb-4 p-4 rounded-xl bg-[#1c1a17] text-stone-200 shadow-inner relative overflow-hidden min-h-[170px] flex items-center justify-center">
          <div className="absolute inset-0 bg-[radial-gradient(#ffffff20_1px,transparent_1px)] bg-[size:16px_16px]" />

          <div className="relative z-10 flex flex-wrap items-center justify-center gap-3.5 p-2">
            {wishes.map((w) => {
              const isSelected = selectedWish?.id === w.id;
              return (
                <button
                  key={w.id}
                  onClick={() => setSelectedWish(w)}
                  title={w.wish}
                  className={`group relative flex items-center justify-center p-2 rounded-full transition-all ${
                    isSelected
                      ? 'scale-130 ring-2 ring-amber-300 bg-white/10 shadow-lg'
                      : 'hover:scale-115 hover:bg-white/5'
                  }`}
                >
                  <span className="text-xl filter drop-shadow-xs">{w.emoji || '⭐'}</span>
                  {w.fulfilled && (
                    <span className="absolute -top-0.5 -right-0.5 w-2 h-2 rounded-full bg-emerald-400 ring-1 ring-black" />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Selected Wish Inspector */}
        {selectedWish ? (
          <div className="p-3.5 bg-stone-100/70 border border-stone-200 rounded-lg mb-4">
            <div className="flex items-center justify-between mb-1.5">
              <div className="flex items-center gap-1.5">
                <span className="text-lg">{selectedWish.emoji || '⭐'}</span>
                <span className="text-[11px] font-sans font-medium text-stone-500">
                  Planted on {selectedWish.createdDate}
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <button
                  onClick={() => handleToggleFulfillWish(selectedWish.id)}
                  title={selectedWish.fulfilled ? 'Mark as ongoing' : 'Mark as Bloomed / Fulfilled'}
                  className={`flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-medium transition-colors ${
                    selectedWish.fulfilled
                      ? 'bg-emerald-100 text-emerald-800'
                      : 'bg-stone-200 text-stone-700 hover:bg-stone-300'
                  }`}
                >
                  <Check className="w-3 h-3" />
                  <span>{selectedWish.fulfilled ? 'Bloomed' : 'Fulfill'}</span>
                </button>
                <button
                  onClick={() => handleDeleteWish(selectedWish.id)}
                  className="p-1 text-stone-400 hover:text-red-700"
                  title="Remove wish"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
            <p className="font-serif italic text-sm text-stone-900 leading-relaxed">
              &ldquo;{selectedWish.wish}&rdquo;
            </p>
          </div>
        ) : (
          <p className="text-xs text-stone-500 italic mb-4">
            Select a glowing celestial symbol above to view its whispered intention.
          </p>
        )}

        {/* All Planted Wishes Archive */}
        <div className="flex-1 space-y-1.5 overflow-y-auto pr-1">
          <span className="text-xs font-sans font-semibold tracking-wide text-stone-700 uppercase block mb-1">
            Star &amp; Wish Archive ({wishes.length})
          </span>
          {wishes.map((w) => (
            <div
              key={w.id}
              onClick={() => setSelectedWish(w)}
              className="flex items-center justify-between p-2 rounded hover:bg-stone-100/60 cursor-pointer border-b border-stone-200/40 text-xs transition-colors"
            >
              <div className="flex items-center gap-2 truncate flex-1">
                <span className="text-sm shrink-0">{w.emoji || '⭐'}</span>
                <span className={`font-serif truncate ${w.fulfilled ? 'text-stone-500' : 'text-stone-800'}`}>
                  {w.wish}
                </span>
              </div>
              <span className="text-[10px] text-stone-400 shrink-0 ml-2">
                {w.fulfilled ? 'Fulfilled' : 'Growing'}
              </span>
            </div>
          ))}
        </div>

        {/* Right Page Footer */}
        <div className="mt-auto pt-2 border-t border-stone-200/60 flex items-center justify-between text-[11px] text-stone-400 font-serif">
          <span>Wishes &amp; Dreams</span>
          <span>p. 9</span>
        </div>
      </div>
    </div>
  );
};
