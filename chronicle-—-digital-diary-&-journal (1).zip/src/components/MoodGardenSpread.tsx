/**
 * Mood Garden Spread Component — "Daily Mood & Blooms"
 * Crystal-clear, intuitive daily mood check-in and monthly bloom calendar.
 * Select how you felt today, write an optional thought, and watch your monthly garden grow!
 */

import React, { useState } from 'react';
import {
  Sparkles,
  Droplets,
  Calendar,
  Heart,
  Smile,
  Check,
} from 'lucide-react';
import { MoodRecord, MoodType } from '../types/diary';
import { formatSerifDate, getTodayDateString } from '../utils/storage';
import { playChimeSound } from '../utils/audio';

interface MoodGardenSpreadProps {
  selectedDate: string;
  moodRecords: Record<string, MoodRecord>;
  onSaveMood: (record: MoodRecord) => void;
  audioEnabled: boolean;
  paperToneClass: string;
}

export const MOOD_CHOICES: {
  mood: MoodType;
  title: string;
  flowerName: string;
  emoji: string;
  bgColor: string;
  borderColor: string;
  flowerType: MoodRecord['flowerType'];
  vibe: string;
}[] = [
  {
    mood: 'joyful',
    title: 'Happy & Bright',
    flowerName: 'Golden Sunflower',
    emoji: '🌻',
    bgColor: '#fef3c7',
    borderColor: '#f59e0b',
    flowerType: 'sunflower',
    vibe: 'Full of smiles, warmth & energy',
  },
  {
    mood: 'peaceful',
    title: 'Calm & Peaceful',
    flowerName: 'Wild Lavender',
    emoji: '🪻',
    bgColor: '#ede9fe',
    borderColor: '#8b5cf6',
    flowerType: 'lavender',
    vibe: 'Relaxed, breathing easy & still',
  },
  {
    mood: 'tender',
    title: 'Soft & Tender',
    flowerName: 'Pink Camellia',
    emoji: '🌸',
    bgColor: '#fce7f3',
    borderColor: '#ec4899',
    flowerType: 'camellia',
    vibe: 'Sensitive, gentle & affectionate',
  },
  {
    mood: 'reflective',
    title: 'Thoughtful & Quiet',
    flowerName: 'Antique Rose',
    emoji: '🌹',
    bgColor: '#ffe4e6',
    borderColor: '#f43f5e',
    flowerType: 'moss_rose',
    vibe: 'Thinking deeply, nostalgic & artistic',
  },
  {
    mood: 'fatigued',
    title: 'Tired or Resting',
    flowerName: 'Forest Fern',
    emoji: '🌿',
    bgColor: '#dcfce7',
    borderColor: '#10b981',
    flowerType: 'fern',
    vibe: 'Needing gentle rest & quiet shelter',
  },
  {
    mood: 'starlit',
    title: 'Dreamy & Starlit',
    flowerName: 'Moon Lily',
    emoji: '🌙',
    bgColor: '#e0e7ff',
    borderColor: '#6366f1',
    flowerType: 'moonflower',
    vibe: 'Quiet nighttime peace & wonder',
  },
];

export const MoodGardenSpread: React.FC<MoodGardenSpreadProps> = ({
  selectedDate,
  moodRecords,
  onSaveMood,
  audioEnabled,
  paperToneClass,
}) => {
  const currentRecord = moodRecords[selectedDate];
  const [reflectionText, setReflectionText] = useState(currentRecord?.reflection || '');
  const [inspectedDate, setInspectedDate] = useState<string>(selectedDate);
  const [waterCount, setWaterCount] = useState(0);
  const [waterAnim, setWaterAnim] = useState(false);

  // Parse month for monthly calendar grid
  const [y, m] = selectedDate.split('-').map(Number);
  const year = y || 2026;
  const month = (m || 10) - 1; // 0-indexed
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const monthName = new Date(year, month, 1).toLocaleDateString('en-US', { month: 'long' });

  const handleSelectMood = (item: (typeof MOOD_CHOICES)[number]) => {
    const record: MoodRecord = {
      date: selectedDate,
      mood: item.mood,
      flowerType: item.flowerType,
      reflection: reflectionText.trim(),
    };
    onSaveMood(record);
    setInspectedDate(selectedDate);
    if (audioEnabled) playChimeSound(true);
  };

  const handleSaveReflection = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentRecord) return;
    const updated = { ...currentRecord, reflection: reflectionText.trim() };
    onSaveMood(updated);
    setInspectedDate(selectedDate);
    if (audioEnabled) playChimeSound(true);
  };

  const handleWaterToday = () => {
    setWaterAnim(true);
    setWaterCount((c) => c + 1);
    if (audioEnabled) playChimeSound(true);
    setTimeout(() => setWaterAnim(false), 800);
  };

  const activeInspectedRecord = moodRecords[inspectedDate];
  const activeInspectedChoice = activeInspectedRecord
    ? MOOD_CHOICES.find((c) => c.mood === activeInspectedRecord.mood) || MOOD_CHOICES[0]
    : null;

  const currentChoice = currentRecord
    ? MOOD_CHOICES.find((c) => c.mood === currentRecord.mood) || MOOD_CHOICES[0]
    : null;

  return (
    <div className="w-full h-full flex flex-col md:flex-row divide-y md:divide-y-0 md:divide-x divide-stone-300/60 overflow-hidden">
      {/* LEFT PAGE: Monthly Garden Bloom Calendar & Potted Living Flower */}
      <div className={`flex-1 flex flex-col h-full relative ${paperToneClass} book-spine-left p-6 sm:p-8 select-none overflow-y-auto`}>
        {/* Header */}
        <div className="border-b border-stone-200/80 pb-3 mb-3 flex items-center justify-between">
          <div>
            <span className="text-[11px] font-sans font-medium uppercase tracking-widest text-stone-500 block">
              Mood Garden
            </span>
            <h2 className="font-serif text-2xl font-medium text-stone-900 mt-0.5">
              My Monthly Flower Bed
            </h2>
            <p className="text-[11px] font-sans text-stone-500">
              {monthName} {year} &bull; Every mood you log blooms into a flower!
            </p>
          </div>
          <Calendar className="w-4 h-4 text-stone-400" />
        </div>

        {/* 31-day Flower Grid for the Month */}
        <div className="mb-4 p-3 bg-stone-100/60 border border-stone-200 rounded-xl">
          <span className="text-[11px] font-sans font-semibold text-stone-600 block mb-2 uppercase tracking-wide">
            {monthName} Blooms:
          </span>
          <div className="grid grid-cols-7 gap-1.5">
            {[...Array(daysInMonth)].map((_, i) => {
              const dayNum = i + 1;
              const dateStr = `${year}-${String(month + 1).padStart(2, '0')}-${String(dayNum).padStart(2, '0')}`;
              const record = moodRecords[dateStr];
              const choice = record ? MOOD_CHOICES.find((c) => c.mood === record.mood) : null;
              const isSelected = dateStr === inspectedDate;
              const isToday = dateStr === selectedDate;

              return (
                <button
                  key={dateStr}
                  onClick={() => setInspectedDate(dateStr)}
                  title={choice ? `${dateStr}: ${choice.title}` : `${dateStr}: Empty flower bed`}
                  className={`aspect-square rounded-lg flex flex-col items-center justify-center p-1 transition-all ${
                    isSelected
                      ? 'ring-2 ring-amber-800 bg-amber-50 shadow-xs'
                      : isToday
                      ? 'border border-amber-600/70 bg-white/80'
                      : 'bg-white/50 border border-stone-200/70 hover:bg-stone-50'
                  }`}
                >
                  <span className="text-[9px] font-sans text-stone-500 tabular-nums">
                    {dayNum}
                  </span>
                  {choice ? (
                    <span className="text-base leading-none mt-0.5">{choice.emoji}</span>
                  ) : (
                    <span className="w-1.5 h-1.5 rounded-full bg-stone-300 mt-1" />
                  )}
                </button>
              );
            })}
          </div>
        </div>

        {/* Inspected Day Details */}
        {activeInspectedRecord && activeInspectedChoice ? (
          <div
            className="p-3.5 rounded-xl border mb-3 transition-all"
            style={{
              backgroundColor: activeInspectedChoice.bgColor,
              borderColor: activeInspectedChoice.borderColor,
            }}
          >
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-2">
                <span className="text-2xl">{activeInspectedChoice.emoji}</span>
                <div>
                  <h4 className="font-serif text-sm font-semibold text-stone-900 leading-tight">
                    {formatSerifDate(inspectedDate)}
                  </h4>
                  <span className="text-[11px] font-sans text-stone-600 font-medium">
                    Felt: {activeInspectedChoice.title} ({activeInspectedChoice.flowerName})
                  </span>
                </div>
              </div>
            </div>
            {activeInspectedRecord.reflection ? (
              <p className="font-serif italic text-xs text-stone-800 mt-1 pl-2 border-l-2 border-stone-400">
                &ldquo;{activeInspectedRecord.reflection}&rdquo;
              </p>
            ) : (
              <p className="text-[11px] text-stone-500 italic mt-1">No note written for this day.</p>
            )}
          </div>
        ) : (
          <div className="p-3 bg-stone-100/50 border border-stone-200/60 rounded-xl mb-3 text-center">
            <p className="text-xs text-stone-500 italic">
              Click any date above to view your flower, or pick today&apos;s mood on the right page.
            </p>
          </div>
        )}

        {/* Living Flower Pot with Water Interaction */}
        <div className="mt-auto pt-2 border-t border-stone-200/60 flex items-center justify-between">
          <div className="flex items-center gap-2.5">
            <div
              className={`w-10 h-10 rounded-full flex items-center justify-center text-xl bg-[#eee7d8] border border-stone-300 transition-transform ${
                waterAnim ? 'scale-125 rotate-6' : ''
              }`}
            >
              {currentChoice ? currentChoice.emoji : '🌱'}
            </div>
            <div>
              <span className="text-xs font-serif font-semibold text-stone-800 block leading-tight">
                {currentChoice ? currentChoice.flowerName : 'Today’s Little Shoot'}
              </span>
              <span className="text-[10px] text-stone-500 font-sans">
                Watered {waterCount} times &bull; Blooming with love
              </span>
            </div>
          </div>

          <button
            onClick={handleWaterToday}
            className="flex items-center gap-1 px-2.5 py-1 text-xs bg-emerald-50 hover:bg-emerald-100 text-emerald-900 border border-emerald-300 rounded-md transition-colors shadow-2xs"
          >
            <Droplets className="w-3.5 h-3.5 text-emerald-700" />
            <span>Water Plant</span>
          </button>
        </div>
      </div>

      {/* RIGHT PAGE: Today's Friendly Mood Picker & Heart Note */}
      <div className={`flex-1 flex flex-col h-full relative ${paperToneClass} book-spine-right p-6 sm:p-8 select-text overflow-y-auto`}>
        {/* Header */}
        <div className="border-b border-stone-200/80 pb-3 mb-4">
          <span className="font-handwriting text-2xl text-amber-900 block leading-none">
            How Did Today Feel?
          </span>
          <h3 className="font-serif text-xl font-medium text-stone-900 mt-1">
            {formatSerifDate(selectedDate)}
          </h3>
          <p className="text-xs text-stone-500 font-sans mt-0.5">
            Choose the emotion that best matches your day:
          </p>
        </div>

        {/* The 6 Clear Friendly Mood Buttons */}
        <div className="grid grid-cols-2 gap-2.5 mb-5">
          {MOOD_CHOICES.map((item) => {
            const isSelected = currentRecord?.mood === item.mood;
            return (
              <button
                key={item.mood}
                onClick={() => handleSelectMood(item)}
                className={`p-3 rounded-xl border text-left transition-all relative overflow-hidden group ${
                  isSelected
                    ? 'ring-2 ring-amber-800 font-medium shadow-sm'
                    : 'bg-white/80 border-stone-200 hover:border-stone-300 hover:bg-white'
                }`}
                style={{
                  backgroundColor: isSelected ? item.bgColor : undefined,
                  borderColor: isSelected ? item.borderColor : undefined,
                }}
              >
                <div className="flex items-center gap-2 mb-1">
                  <span className="text-2xl group-hover:scale-115 transition-transform">
                    {item.emoji}
                  </span>
                  <div>
                    <span className="text-xs font-semibold text-stone-900 block leading-tight">
                      {item.title}
                    </span>
                    <span className="text-[10px] text-stone-500 font-sans italic">
                      {item.flowerName}
                    </span>
                  </div>
                </div>
                <p className="text-[10px] text-stone-600 font-sans line-clamp-1">
                  {item.vibe}
                </p>

                {isSelected && (
                  <div className="absolute top-2 right-2 w-4 h-4 rounded-full bg-amber-800 text-white flex items-center justify-center">
                    <Check className="w-2.5 h-2.5" />
                  </div>
                )}
              </button>
            );
          })}
        </div>

        {/* Reflection Note & Plant Button */}
        <form onSubmit={handleSaveReflection} className="flex-1 flex flex-col">
          <span className="text-xs font-sans font-semibold tracking-wide text-stone-700 uppercase mb-1">
            Heart Note (Optional)
          </span>
          <textarea
            value={reflectionText}
            onChange={(e) => setReflectionText(e.target.value)}
            placeholder="A short sentence about your day: 'Had warm tea with an old friend...', 'Took a quiet walk in the autumn air...'"
            className="flex-1 w-full bg-transparent resize-none font-body-serif text-xs leading-relaxed text-stone-800 focus:outline-hidden p-2 border border-stone-200/60 rounded-md mb-3"
            style={{
              backgroundImage:
                'repeating-linear-gradient(transparent, transparent 27px, rgba(180, 160, 140, 0.15) 27px, rgba(180, 160, 140, 0.15) 28px)',
              lineHeight: '28px',
            }}
          />
          <button
            type="submit"
            className="w-full py-2.5 bg-stone-900 hover:bg-stone-800 text-amber-50 text-xs font-medium rounded-lg transition-colors shadow-xs flex items-center justify-center gap-1.5"
          >
            <Sparkles className="w-3.5 h-3.5 text-amber-300" />
            <span>Plant Today&apos;s Flower in Garden</span>
          </button>
        </form>

        {/* Right Page Footer */}
        <div className="mt-auto pt-2 border-t border-stone-200/60 flex items-center justify-between text-[11px] text-stone-400 font-serif">
          <span>Daily Flower Record</span>
          <span>p. 11</span>
        </div>
      </div>
    </div>
  );
};
