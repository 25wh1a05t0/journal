/**
 * Scrapbook Spread Component
 * Clean, tactile, and intuitive journal scrapbook.
 * - Left Page: Freeform memory board with drag-to-position, corner snaps, and quick adjustments.
 * - Right Page: Focused photo inspector (when an image is selected) & spacious memory story journal.
 */

import React, { useState, useRef, useEffect, useCallback } from 'react';
import {
  Upload,
  Trash2,
  RotateCw,
  RotateCcw,
  Sparkles,
  X,
  Crop,
  Move,
  ArrowUpLeft,
  ArrowUpRight,
  ArrowDownLeft,
  ArrowDownRight,
  Dot,
  Check,
  Plus,
} from 'lucide-react';
import { ScrapbookPageData, ScrapbookItem, StickerType } from '../types/diary';
import { formatSerifDate, TEA_PHOTO_URL, MORNING_PHOTO_URL, FERN_PHOTO_URL } from '../utils/storage';

interface ScrapbookSpreadProps {
  date: string;
  data: ScrapbookPageData;
  onSaveData: (data: ScrapbookPageData) => void;
  paperToneClass: string;
}

const PRESET_PHOTOS = [
  { label: 'Chamomile & Book', url: TEA_PHOTO_URL },
  { label: 'Golden Morning', url: MORNING_PHOTO_URL },
  { label: 'Pressed Lady Fern', url: FERN_PHOTO_URL },
];

const STICKER_CATEGORIES: {
  category: string;
  items: { label: string; type: StickerType; emojiChar?: string }[];
}[] = [
  {
    category: 'Botanical',
    items: [
      { label: 'Lady Fern', type: 'botanical', emojiChar: '🌿' },
      { label: 'Blossom', type: 'botanical', emojiChar: '🌸' },
      { label: 'Maple Leaf', type: 'botanical', emojiChar: '🍂' },
      { label: 'Lavender', type: 'botanical', emojiChar: '🪻' },
      { label: 'Mushroom', type: 'botanical', emojiChar: '🍄' },
      { label: 'Sunflower', type: 'botanical', emojiChar: '🌻' },
    ],
  },
  {
    category: 'Ephemera',
    items: [
      { label: 'Crimson Seal', type: 'wax_seal' },
      { label: 'Postage Stamp', type: 'stamp' },
      { label: 'Washi Tape', type: 'washi_tape' },
      { label: 'Scroll', type: 'emoji', emojiChar: '📜' },
      { label: 'Ticket', type: 'emoji', emojiChar: '🎟️' },
      { label: 'Letter', type: 'emoji', emojiChar: '💌' },
    ],
  },
  {
    category: 'Aesthetic Icons',
    items: [
      { label: 'Moon', type: 'emoji', emojiChar: '🌙' },
      { label: 'Sparkles', type: 'emoji', emojiChar: '✨' },
      { label: 'Teacup', type: 'emoji', emojiChar: '☕' },
      { label: 'Book', type: 'emoji', emojiChar: '📖' },
      { label: 'Butterfly', type: 'emoji', emojiChar: '🦋' },
      { label: 'Candle', type: 'emoji', emojiChar: '🕯️' },
    ],
  },
];

export const ScrapbookSpread: React.FC<ScrapbookSpreadProps> = ({
  date,
  data,
  onSaveData,
  paperToneClass,
}) => {
  const boardRef = useRef<HTMLDivElement | null>(null);
  const dataRef = useRef(data);
  dataRef.current = data;

  const [selectedItemId, setSelectedItemId] = useState<string | null>(null);
  const [showStickerDrawer, setShowStickerDrawer] = useState(false);
  const [activeCategory, setActiveCategory] = useState(0);

  // Dragging state
  const [dragState, setDragState] = useState<{
    itemId: string;
    startX: number;
    startY: number;
    startItemX: number;
    startItemY: number;
    hasMoved: boolean;
  } | null>(null);

  // Resize state
  const [resizeState, setResizeState] = useState<{
    itemId: string;
    startX: number;
    startWidth: number;
  } | null>(null);

  // Stable updater
  const handleUpdateItem = useCallback(
    (id: string, updates: Partial<ScrapbookItem>) => {
      const next = dataRef.current.items.map((it) => (it.id === id ? { ...it, ...updates } : it));
      onSaveData({ ...dataRef.current, items: next });
    },
    [onSaveData]
  );

  // Window-level smooth dragging listener
  useEffect(() => {
    if (!dragState) return;

    const handleWindowPointerMove = (e: PointerEvent) => {
      if (!boardRef.current) return;
      const rect = boardRef.current.getBoundingClientRect();
      if (rect.width === 0 || rect.height === 0) return;

      const dxPx = e.clientX - dragState.startX;
      const dyPx = e.clientY - dragState.startY;

      // Small threshold to distinguish a pure click/selection from a drag
      if (!dragState.hasMoved && Math.hypot(dxPx, dyPx) > 3) {
        dragState.hasMoved = true;
      }

      const dx = (dxPx / rect.width) * 100;
      const dy = (dyPx / rect.height) * 100;

      const newX = Math.max(14, Math.min(86, dragState.startItemX + dx));
      const newY = Math.max(14, Math.min(86, dragState.startItemY + dy));

      handleUpdateItem(dragState.itemId, {
        x: Math.round(newX * 10) / 10,
        y: Math.round(newY * 10) / 10,
      });
    };

    const handleWindowPointerUp = () => {
      setDragState(null);
    };

    window.addEventListener('pointermove', handleWindowPointerMove);
    window.addEventListener('pointerup', handleWindowPointerUp);
    window.addEventListener('pointercancel', handleWindowPointerUp);

    return () => {
      window.removeEventListener('pointermove', handleWindowPointerMove);
      window.removeEventListener('pointerup', handleWindowPointerUp);
      window.removeEventListener('pointercancel', handleWindowPointerUp);
    };
  }, [dragState, handleUpdateItem]);

  // Window-level resizing listener
  useEffect(() => {
    if (!resizeState) return;

    const handleWindowResizeMove = (e: PointerEvent) => {
      if (!boardRef.current) return;
      const rect = boardRef.current.getBoundingClientRect();
      if (rect.width === 0) return;

      const dx = ((e.clientX - resizeState.startX) / rect.width) * 100;
      const newWidth = Math.max(22, Math.min(75, resizeState.startWidth + dx));

      handleUpdateItem(resizeState.itemId, {
        width: Math.round(newWidth),
      });
    };

    const handleWindowResizeUp = () => {
      setResizeState(null);
    };

    window.addEventListener('pointermove', handleWindowResizeMove);
    window.addEventListener('pointerup', handleWindowResizeUp);
    window.addEventListener('pointercancel', handleWindowResizeUp);

    return () => {
      window.removeEventListener('pointermove', handleWindowResizeMove);
      window.removeEventListener('pointerup', handleWindowResizeUp);
      window.removeEventListener('pointercancel', handleWindowResizeUp);
    };
  }, [resizeState, handleUpdateItem]);

  // File upload handler - creates photo and immediately selects it
  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const base64 = event.target?.result as string;
      const newItem: ScrapbookItem = {
        id: `photo-${Date.now()}`,
        type: 'photo',
        src: base64,
        caption: file.name.replace(/\.[^/.]+$/, ''),
        x: 50,
        y: 48,
        width: 44,
        rotation: (Math.random() - 0.5) * 4,
        cropAspect: 'square',
        zoom: 1,
        tapeStyle: 'washi',
      };
      onSaveData({ ...dataRef.current, items: [...dataRef.current.items, newItem] });
      // Keep selected so user can immediately adjust
      setSelectedItemId(newItem.id);
    };
    reader.readAsDataURL(file);
    e.target.value = '';
  };

  // Add preset photo
  const handleAddPresetPhoto = (url: string, label: string) => {
    const count = dataRef.current.items.length;
    const newItem: ScrapbookItem = {
      id: `photo-${Date.now()}`,
      type: 'photo',
      src: url,
      caption: label,
      x: 35 + (count % 3) * 15,
      y: 35 + (count % 2) * 20,
      width: 42,
      rotation: (Math.random() - 0.5) * 5,
      cropAspect: 'square',
      zoom: 1,
      tapeStyle: 'washi',
    };
    onSaveData({ ...dataRef.current, items: [...dataRef.current.items, newItem] });
    setSelectedItemId(newItem.id);
  };

  // Add sticker
  const handleAddSticker = (item: (typeof STICKER_CATEGORIES)[number]['items'][number]) => {
    const newItem: ScrapbookItem = {
      id: `sticker-${Date.now()}`,
      type: 'sticker',
      stickerType: item.type,
      emojiChar: item.emojiChar,
      x: 40 + Math.random() * 20,
      y: 40 + Math.random() * 20,
      width: item.type === 'washi_tape' ? 24 : item.type === 'wax_seal' ? 14 : 16,
      rotation: (Math.random() - 0.5) * 10,
    };
    onSaveData({ ...dataRef.current, items: [...dataRef.current.items, newItem] });
    setSelectedItemId(newItem.id);
    setShowStickerDrawer(false);
  };

  // Start dragging item
  const handleItemPointerDown = (e: React.PointerEvent, item: ScrapbookItem) => {
    if (e.button !== 0) return;
    e.stopPropagation();
    // Select immediately on click
    setSelectedItemId(item.id);

    setDragState({
      itemId: item.id,
      startX: e.clientX,
      startY: e.clientY,
      startItemX: item.x,
      startItemY: item.y,
      hasMoved: false,
    });
  };

  // Start resizing item
  const handleResizePointerDown = (e: React.PointerEvent, item: ScrapbookItem) => {
    if (e.button !== 0) return;
    e.stopPropagation();
    e.preventDefault();

    setResizeState({
      itemId: item.id,
      startX: e.clientX,
      startWidth: item.width,
    });
  };

  // Corner quick-alignment
  const handleSetCornerPosition = (
    position: 'top-left' | 'top-right' | 'center' | 'bottom-left' | 'bottom-right'
  ) => {
    if (!selectedItemId) return;
    const coords = {
      'top-left': { x: 26, y: 26 },
      'top-right': { x: 74, y: 26 },
      'center': { x: 50, y: 50 },
      'bottom-left': { x: 26, y: 74 },
      'bottom-right': { x: 74, y: 74 },
    }[position];

    handleUpdateItem(selectedItemId, coords);
  };

  const handleDeleteItem = (id: string) => {
    const next = data.items.filter((it) => it.id !== id);
    onSaveData({ ...data, items: next });
    if (selectedItemId === id) setSelectedItemId(null);
  };

  const handleRotate = (id: string, delta: number) => {
    const it = data.items.find((i) => i.id === id);
    if (!it) return;
    const newRot = Math.round((it.rotation + delta) % 360);
    handleUpdateItem(id, { rotation: newRot });
  };

  const selectedItem = data.items.find((i) => i.id === selectedItemId);

  return (
    <div className="w-full h-full flex flex-col md:flex-row divide-y md:divide-y-0 md:divide-x divide-stone-300/60 overflow-hidden">
      {/* LEFT PAGE: Interactive Memory Board */}
      <div
        className={`flex-1 flex flex-col h-full relative ${paperToneClass} book-spine-left p-3.5 sm:p-6 select-none overflow-hidden`}
        onPointerDown={(e) => {
          // Deselect only if clicking the background board directly
          if (e.target === boardRef.current) {
            setSelectedItemId(null);
          }
        }}
      >
        {/* Header with Title & Quick Add Actions */}
        <div className="flex items-center justify-between border-b border-stone-200/80 pb-2 mb-2 shrink-0">
          <div>
            <span className="font-handwriting text-xl sm:text-2xl text-amber-900 block leading-none">
              Memories &amp; Keepsakes
            </span>
            <p className="font-serif text-[11px] text-stone-500 mt-0.5">
              {formatSerifDate(date)} &bull; Click to select &amp; drag anywhere
            </p>
          </div>

          <div className="flex items-center gap-1.5" onClick={(e) => e.stopPropagation()}>
            <label className="flex items-center gap-1 px-2.5 py-1 text-xs font-sans font-medium text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-md cursor-pointer transition-colors border border-stone-300 shadow-2xs">
              <Upload className="w-3.5 h-3.5 text-stone-600" />
              <span>Add Photo</span>
              <input type="file" accept="image/*" onChange={handleFileUpload} className="hidden" />
            </label>

            <button
              onClick={() => setShowStickerDrawer(true)}
              className="flex items-center gap-1 px-2.5 py-1 text-xs font-sans font-medium text-stone-700 bg-stone-100 hover:bg-stone-200 rounded-md transition-colors border border-stone-300 shadow-2xs"
            >
              <Sparkles className="w-3.5 h-3.5 text-amber-800" />
              <span>Stickers</span>
            </button>
          </div>
        </div>

        {/* Sticker Drawer Modal */}
        {showStickerDrawer && (
          <div
            onClick={(e) => e.stopPropagation()}
            className="absolute inset-3 z-50 bg-[#fdfbf7]/98 border border-stone-300 rounded-xl shadow-2xl p-3 flex flex-col backdrop-blur-md"
          >
            <div className="flex items-center justify-between pb-1.5 border-b border-stone-200">
              <span className="font-serif text-sm font-semibold text-stone-800">
                Stickers &amp; Ephemera
              </span>
              <button
                onClick={() => setShowStickerDrawer(false)}
                className="p-1 text-stone-400 hover:text-stone-700 rounded-md"
              >
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Category tabs */}
            <div className="flex items-center gap-1 my-1.5 overflow-x-auto no-scrollbar">
              {STICKER_CATEGORIES.map((cat, idx) => (
                <button
                  key={cat.category}
                  onClick={() => setActiveCategory(idx)}
                  className={`px-2 py-0.5 rounded text-xs whitespace-nowrap transition-colors ${
                    activeCategory === idx
                      ? 'bg-amber-900 text-white font-medium shadow-2xs'
                      : 'bg-stone-100 text-stone-700 hover:bg-stone-200'
                  }`}
                >
                  {cat.category}
                </button>
              ))}
            </div>

            {/* Items Grid */}
            <div className="grid grid-cols-3 sm:grid-cols-4 gap-1.5 flex-1 overflow-y-auto pr-1 py-1">
              {STICKER_CATEGORIES[activeCategory].items.map((stk) => (
                <button
                  key={stk.label}
                  onClick={() => handleAddSticker(stk)}
                  className="flex flex-col items-center justify-center p-2 rounded-lg bg-stone-50 hover:bg-amber-50 border border-stone-200 hover:border-amber-700 transition-all text-center group"
                >
                  <span className="text-2xl mb-1 group-hover:scale-115 transition-transform">
                    {stk.emojiChar || (stk.type === 'wax_seal' ? '🔴' : stk.type === 'stamp' ? '📮' : '🩹')}
                  </span>
                  <span className="text-[10px] font-sans text-stone-700 truncate w-full">
                    {stk.label}
                  </span>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Selected Item Floating On-Canvas Mini Toolbar */}
        {selectedItem && (
          <div
            onClick={(e) => e.stopPropagation()}
            className="mb-1.5 px-2.5 py-1 bg-[#fffdf8] border border-amber-800/30 rounded-lg shadow-sm flex items-center justify-between gap-1 text-xs shrink-0 animate-in fade-in"
          >
            <div className="flex items-center gap-1 text-stone-700 font-sans">
              <span className="text-[10px] uppercase font-bold text-amber-900">Corners:</span>
              <button
                onClick={() => handleSetCornerPosition('top-left')}
                className="p-1 bg-stone-100 hover:bg-amber-100 text-stone-700 rounded border border-stone-300"
                title="Top-Left"
              >
                <ArrowUpLeft className="w-3 h-3" />
              </button>
              <button
                onClick={() => handleSetCornerPosition('top-right')}
                className="p-1 bg-stone-100 hover:bg-amber-100 text-stone-700 rounded border border-stone-300"
                title="Top-Right"
              >
                <ArrowUpRight className="w-3 h-3" />
              </button>
              <button
                onClick={() => handleSetCornerPosition('center')}
                className="p-1 bg-stone-100 hover:bg-amber-100 text-stone-700 rounded border border-stone-300"
                title="Center"
              >
                <Dot className="w-3 h-3" />
              </button>
              <button
                onClick={() => handleSetCornerPosition('bottom-left')}
                className="p-1 bg-stone-100 hover:bg-amber-100 text-stone-700 rounded border border-stone-300"
                title="Bottom-Left"
              >
                <ArrowDownLeft className="w-3 h-3" />
              </button>
              <button
                onClick={() => handleSetCornerPosition('bottom-right')}
                className="p-1 bg-stone-100 hover:bg-amber-100 text-stone-700 rounded border border-stone-300"
                title="Bottom-Right"
              >
                <ArrowDownRight className="w-3 h-3" />
              </button>
            </div>

            {selectedItem.type === 'photo' && (
              <div className="flex items-center gap-0.5">
                {(['square', 'portrait', 'landscape'] as const).map((asp) => (
                  <button
                    key={asp}
                    onClick={() => handleUpdateItem(selectedItem.id, { cropAspect: asp })}
                    className={`px-1.5 py-0.5 rounded text-[10px] font-sans capitalize ${
                      (selectedItem.cropAspect || 'square') === asp
                        ? 'bg-amber-900 text-white font-medium'
                        : 'bg-stone-100 text-stone-700 hover:bg-stone-200 border border-stone-200'
                    }`}
                  >
                    {asp === 'square' ? '1:1' : asp === 'portrait' ? '3:4' : '4:3'}
                  </button>
                ))}
              </div>
            )}

            <div className="flex items-center gap-1">
              <button
                onClick={() => handleRotate(selectedItem.id, 6)}
                className="p-1 text-stone-600 hover:text-stone-900 bg-stone-100 hover:bg-stone-200 rounded border border-stone-300"
                title="Rotate"
              >
                <RotateCw className="w-3 h-3" />
              </button>
              <button
                onClick={() => handleDeleteItem(selectedItem.id)}
                className="p-1 text-stone-400 hover:text-red-700 hover:bg-red-50 rounded"
                title="Delete"
              >
                <Trash2 className="w-3 h-3" />
              </button>
            </div>
          </div>
        )}

        {/* The Freeform Scrapbook Board */}
        <div
          ref={boardRef}
          className="flex-1 relative w-full rounded-md border border-stone-200/60 bg-[#faf6ee]/40 overflow-hidden cursor-default touch-none"
        >
          {data.items.length === 0 && (
            <div className="absolute inset-0 flex flex-col items-center justify-center pointer-events-none p-4 text-center">
              <span className="font-handwriting text-2xl text-stone-400">
                A quiet canvas for your favorite moments…
              </span>
              <p className="text-xs text-stone-400 font-serif mt-1">
                Click &ldquo;Add Photo&rdquo; or pick a preset from the right page.
              </p>
            </div>
          )}

          {data.items.map((item) => {
            const isSelected = item.id === selectedItemId;
            const isDragging = dragState?.itemId === item.id;

            if (item.type === 'photo' && item.src) {
              const aspectClass =
                item.cropAspect === 'portrait'
                  ? 'aspect-[3/4]'
                  : item.cropAspect === 'landscape'
                  ? 'aspect-[4/3]'
                  : item.cropAspect === 'circle'
                  ? 'aspect-square rounded-full'
                  : 'aspect-square';

              const zoomScale = item.zoom || 1;

              return (
                <div
                  key={item.id}
                  onPointerDown={(e) => handleItemPointerDown(e, item)}
                  className={`absolute touch-none select-none transition-shadow ${
                    isDragging ? 'cursor-grabbing z-40 scale-102 shadow-2xl opacity-95' : 'cursor-grab z-10'
                  } ${
                    isSelected
                      ? 'ring-2 ring-amber-800 ring-offset-2 z-30 shadow-lg'
                      : 'hover:ring-1 hover:ring-amber-600/50'
                  }`}
                  style={{
                    left: `${item.x}%`,
                    top: `${item.y}%`,
                    width: `${item.width}%`,
                    transform: `translate(-50%, -50%) rotate(${item.rotation}deg)`,
                  }}
                >
                  {/* Polaroid Frame & Fastener */}
                  <div className="bg-[#fffefc] p-2 pb-3.5 rounded-xs shadow-md border border-stone-200/90 relative">
                    {(item.tapeStyle ?? 'washi') === 'washi' && (
                      <div className="w-12 h-3 mx-auto -mt-3 mb-1 bg-[#e8dec0]/90 border-t border-b border-amber-200/60 transform rotate-1 opacity-90 shadow-2xs pointer-events-none" />
                    )}
                    {item.tapeStyle === 'pin' && (
                      <div className="w-3 h-3 mx-auto -mt-3 mb-1 rounded-full bg-amber-600 shadow-sm border border-amber-800 pointer-events-none" />
                    )}
                    {item.tapeStyle === 'clip' && (
                      <div className="w-2.5 h-4 mx-auto -mt-3.5 mb-1 border-2 border-stone-400 rounded-t-full pointer-events-none" />
                    )}

                    {/* Image */}
                    <div
                      className={`w-full ${aspectClass} overflow-hidden rounded-xs border border-stone-200/50 relative bg-stone-100 flex items-center justify-center`}
                    >
                      <img
                        src={item.src}
                        alt={item.caption || 'Memory'}
                        draggable={false}
                        onDragStart={(e) => e.preventDefault()}
                        referrerPolicy="no-referrer"
                        className="w-full h-full object-cover pointer-events-none"
                        style={{ transform: `scale(${zoomScale})` }}
                      />
                    </div>

                    {item.caption && (
                      <p className="font-handwriting text-center text-xs text-stone-700 mt-1.5 truncate px-1 pointer-events-none">
                        {item.caption}
                      </p>
                    )}

                    {/* Bottom-right interactive resize handle when selected */}
                    {isSelected && (
                      <div
                        onPointerDown={(e) => handleResizePointerDown(e, item)}
                        className="absolute bottom-0 right-0 w-4 h-4 bg-amber-900/80 hover:bg-amber-900 rounded-tl-sm cursor-nwse-resize flex items-center justify-center text-white text-[8px]"
                        title="Drag to resize photo"
                      >
                        ↘
                      </div>
                    )}
                  </div>
                </div>
              );
            }

            if (item.type === 'sticker') {
              return (
                <div
                  key={item.id}
                  onPointerDown={(e) => handleItemPointerDown(e, item)}
                  className={`absolute touch-none select-none ${
                    isDragging ? 'cursor-grabbing z-40 scale-110' : 'cursor-grab z-10'
                  } ${isSelected ? 'ring-2 ring-amber-800 ring-offset-2 z-30' : 'hover:scale-105'}`}
                  style={{
                    left: `${item.x}%`,
                    top: `${item.y}%`,
                    transform: `translate(-50%, -50%) rotate(${item.rotation}deg)`,
                  }}
                >
                  {item.stickerType === 'wax_seal' && (
                    <div className="w-10 h-10 rounded-full bg-[#9a3412] shadow-md border border-amber-900 flex items-center justify-center text-amber-200 text-xs font-serif font-bold pointer-events-none">
                      C
                    </div>
                  )}
                  {item.stickerType === 'washi_tape' && (
                    <div className="w-20 h-4 bg-[#e6dfc8]/95 border border-[#d8d0b6] shadow-xs flex items-center justify-center text-[9px] text-stone-600 font-serif tracking-widest uppercase pointer-events-none">
                      Chronicle
                    </div>
                  )}
                  {item.stickerType === 'stamp' && (
                    <div className="w-10 h-12 bg-[#fbf9f4] border-2 border-dashed border-stone-400 p-1 flex flex-col items-center justify-between text-[7px] text-stone-500 font-mono shadow-xs pointer-events-none">
                      <span>POSTAGE</span>
                      <div className="w-5 h-5 rounded-full bg-amber-900/15 flex items-center justify-center font-serif text-[9px] text-stone-700">
                        26
                      </div>
                      <span>OCT 26</span>
                    </div>
                  )}
                  {(item.stickerType === 'botanical' || item.stickerType === 'emoji') && (
                    <div className="text-2xl filter drop-shadow-xs pointer-events-none">
                      {item.emojiChar || '🌿'}
                    </div>
                  )}
                </div>
              );
            }

            return null;
          })}
        </div>

        {/* Page Footer */}
        <div className="mt-auto pt-2 border-t border-stone-200/60 flex items-center justify-between text-[11px] text-stone-500 font-serif shrink-0">
          <span>{data.items.length} items &bull; Drag to move &bull; Tap corners to snap</span>
          <span>p. 6</span>
        </div>
      </div>

      {/* RIGHT PAGE: Simple Photo Inspector & Spacious Memory Story Journal */}
      <div
        className={`flex-1 flex flex-col h-full relative ${paperToneClass} book-spine-right p-3.5 sm:p-6 select-text overflow-y-auto`}
      >
        {/* Right Page Header */}
        <div className="border-b border-stone-200/80 pb-2 mb-2.5 flex items-center justify-between shrink-0">
          <div>
            <span className="font-serif text-base sm:text-lg font-semibold text-stone-900 tracking-tight">
              Scrapbook Framing &amp; Journal
            </span>
            <p className="text-[11px] text-stone-500 font-sans mt-0.5">
              Photo adjustments and reflections for this day
            </p>
          </div>
        </div>

        {/* Dynamic Section: Photo Inspector (if selected) OR Quick Add Cards (if none selected) */}
        {selectedItem ? (
          <div className="mb-3 p-3 bg-stone-100/90 border border-stone-300 rounded-lg shadow-2xs shrink-0">
            <div className="flex items-center justify-between mb-2 pb-1 border-b border-stone-200">
              <span className="text-xs font-semibold text-stone-800 font-sans uppercase flex items-center gap-1.5">
                <Move className="w-3.5 h-3.5 text-amber-900" />
                <span>Selected {selectedItem.type === 'photo' ? 'Photo' : 'Sticker'}</span>
              </span>
              <div className="flex items-center gap-1">
                <button
                  onClick={() => handleDeleteItem(selectedItem.id)}
                  className="text-stone-400 hover:text-red-700 p-1 rounded"
                  title="Remove item"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
                <button
                  onClick={() => setSelectedItemId(null)}
                  className="px-2 py-0.5 text-xs text-stone-600 hover:text-stone-900 bg-white border border-stone-200 rounded"
                >
                  Done
                </button>
              </div>
            </div>

            {/* Quick Corner Snap Buttons */}
            <div className="mb-2.5">
              <span className="text-[11px] font-sans font-medium text-stone-700 block mb-1">
                Position in Corner:
              </span>
              <div className="grid grid-cols-5 gap-1 text-[11px]">
                <button
                  onClick={() => handleSetCornerPosition('top-left')}
                  className="p-1 bg-white hover:bg-amber-50 hover:border-amber-700 border border-stone-200 rounded text-center transition-colors font-sans text-stone-700"
                  title="Top-Left"
                >
                  ↖ Top-L
                </button>
                <button
                  onClick={() => handleSetCornerPosition('top-right')}
                  className="p-1 bg-white hover:bg-amber-50 hover:border-amber-700 border border-stone-200 rounded text-center transition-colors font-sans text-stone-700"
                  title="Top-Right"
                >
                  ↗ Top-R
                </button>
                <button
                  onClick={() => handleSetCornerPosition('center')}
                  className="p-1 bg-white hover:bg-amber-50 hover:border-amber-700 border border-stone-200 rounded text-center transition-colors font-sans text-stone-700"
                  title="Center"
                >
                  ⏺ Center
                </button>
                <button
                  onClick={() => handleSetCornerPosition('bottom-left')}
                  className="p-1 bg-white hover:bg-amber-50 hover:border-amber-700 border border-stone-200 rounded text-center transition-colors font-sans text-stone-700"
                  title="Bottom-Left"
                >
                  ↙ Bot-L
                </button>
                <button
                  onClick={() => handleSetCornerPosition('bottom-right')}
                  className="p-1 bg-white hover:bg-amber-50 hover:border-amber-700 border border-stone-200 rounded text-center transition-colors font-sans text-stone-700"
                  title="Bottom-Right"
                >
                  ↘ Bot-R
                </button>
              </div>
            </div>

            {selectedItem.type === 'photo' && (
              <>
                {/* Crop Shapes */}
                <div className="mb-2">
                  <span className="text-[11px] font-sans font-medium text-stone-700 block mb-1">
                    Frame Aspect Ratio:
                  </span>
                  <div className="grid grid-cols-4 gap-1 text-[11px]">
                    {[
                      { id: 'square', label: '1:1 Square' },
                      { id: 'portrait', label: '3:4 Portrait' },
                      { id: 'landscape', label: '4:3 Wide' },
                      { id: 'circle', label: 'Oval' },
                    ].map((asp) => (
                      <button
                        key={asp.id}
                        onClick={() => handleUpdateItem(selectedItem.id, { cropAspect: asp.id as any })}
                        className={`p-1 rounded border text-center transition-colors text-xs ${
                          (selectedItem.cropAspect || 'square') === asp.id
                            ? 'bg-amber-900 text-white border-amber-900 font-medium'
                            : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-50'
                        }`}
                      >
                        {asp.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Size Presets & Slider */}
                <div className="mb-2 flex items-center gap-2">
                  <span className="text-[11px] text-stone-700 font-sans w-14">Card Size:</span>
                  <div className="flex items-center gap-1">
                    <button
                      onClick={() => handleUpdateItem(selectedItem.id, { width: 30 })}
                      className={`px-1.5 py-0.5 text-[10px] rounded border ${
                        selectedItem.width <= 32
                          ? 'bg-amber-900 text-white border-amber-900'
                          : 'bg-white border-stone-200 text-stone-700'
                      }`}
                    >
                      Small
                    </button>
                    <button
                      onClick={() => handleUpdateItem(selectedItem.id, { width: 44 })}
                      className={`px-1.5 py-0.5 text-[10px] rounded border ${
                        selectedItem.width > 32 && selectedItem.width < 55
                          ? 'bg-amber-900 text-white border-amber-900'
                          : 'bg-white border-stone-200 text-stone-700'
                      }`}
                    >
                      Medium
                    </button>
                    <button
                      onClick={() => handleUpdateItem(selectedItem.id, { width: 60 })}
                      className={`px-1.5 py-0.5 text-[10px] rounded border ${
                        selectedItem.width >= 55
                          ? 'bg-amber-900 text-white border-amber-900'
                          : 'bg-white border-stone-200 text-stone-700'
                      }`}
                    >
                      Large
                    </button>
                  </div>
                  <input
                    type="range"
                    min="20"
                    max="75"
                    value={selectedItem.width}
                    onChange={(e) =>
                      handleUpdateItem(selectedItem.id, { width: parseInt(e.target.value, 10) })
                    }
                    className="flex-1 accent-amber-900"
                  />
                  <span className="text-[10px] text-stone-600 font-mono w-7 text-right">
                    {selectedItem.width}%
                  </span>
                </div>

                {/* Fasteners */}
                <div className="mb-2 flex items-center gap-2">
                  <span className="text-[11px] text-stone-700 font-sans w-14">Fastener:</span>
                  <div className="grid grid-cols-4 gap-1 flex-1 text-[11px]">
                    {[
                      { id: 'washi', label: 'Tape' },
                      { id: 'pin', label: 'Pin' },
                      { id: 'clip', label: 'Clip' },
                      { id: 'none', label: 'None' },
                    ].map((tape) => (
                      <button
                        key={tape.id}
                        onClick={() =>
                          handleUpdateItem(selectedItem.id, { tapeStyle: tape.id as any })
                        }
                        className={`p-0.5 rounded border text-center transition-colors text-xs ${
                          (selectedItem.tapeStyle || 'washi') === tape.id
                            ? 'bg-amber-900 text-white border-amber-900 font-medium'
                            : 'bg-white text-stone-700 border-stone-200 hover:bg-stone-50'
                        }`}
                      >
                        {tape.label}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Caption input */}
                <div>
                  <input
                    type="text"
                    value={selectedItem.caption || ''}
                    onChange={(e) => handleUpdateItem(selectedItem.id, { caption: e.target.value })}
                    placeholder="Add polaroid handwritten note..."
                    className="w-full text-xs font-serif p-1.5 bg-white border border-stone-300 rounded text-stone-800 focus:outline-hidden"
                  />
                </div>
              </>
            )}
          </div>
        ) : (
          /* When nothing is selected: Quick add photos */
          <div className="mb-3 shrink-0">
            <span className="text-xs font-sans font-semibold tracking-wide text-stone-700 uppercase mb-1.5 block">
              Curated Aesthetic Memories
            </span>
            <div className="grid grid-cols-3 gap-2">
              {PRESET_PHOTOS.map((preset) => (
                <div
                  key={preset.label}
                  onClick={() => handleAddPresetPhoto(preset.url, preset.label)}
                  className="group cursor-pointer p-1.5 bg-[#fbf9f4] border border-stone-200 rounded-md hover:border-amber-700 transition-all text-center"
                >
                  <img
                    src={preset.url}
                    alt={preset.label}
                    draggable={false}
                    className="w-full aspect-square object-cover rounded-xs mb-1 pointer-events-none"
                  />
                  <span className="text-[10px] font-serif text-stone-700 group-hover:text-amber-900 block truncate">
                    + {preset.label}
                  </span>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Story Behind The Keepsakes - Beautiful lined journal space */}
        <div className="flex-1 flex flex-col min-h-0 pt-2 border-t border-stone-200/80">
          <span className="text-xs font-sans font-semibold tracking-wide text-stone-700 uppercase mb-1 shrink-0">
            Story Behind These Keepsakes
          </span>
          <textarea
            value={data.note || ''}
            onChange={(e) => onSaveData({ ...data, note: e.target.value })}
            placeholder="Write the memories, context, and feelings captured by these snapshots..."
            className="flex-1 w-full bg-transparent resize-none font-body-serif text-xs leading-relaxed text-stone-800 focus:outline-hidden p-2 border border-stone-200/50 rounded-md"
            style={{
              backgroundImage:
                'repeating-linear-gradient(transparent, transparent 27px, rgba(180, 160, 140, 0.15) 27px, rgba(180, 160, 140, 0.15) 28px)',
              lineHeight: '28px',
            }}
          />
        </div>

        {/* Right Page Footer */}
        <div className="mt-auto pt-2 border-t border-stone-200/60 flex items-center justify-between text-[11px] text-stone-400 font-serif shrink-0">
          <span>Memories Journal</span>
          <span>p. 7</span>
        </div>
      </div>
    </div>
  );
};
