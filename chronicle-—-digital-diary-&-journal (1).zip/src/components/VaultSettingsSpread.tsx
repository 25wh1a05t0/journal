/**
 * Vault & Settings Spread Component
 * Left Page: Privacy PIN code protection, author name, paper tone, paper ruling
 * Right Page: Sound preferences, backup JSON export/import, print view
 */

import React, { useState } from 'react';
import {
  Lock,
  Unlock,
  Volume2,
  VolumeX,
  Download,
  Upload,
  Printer,
  ShieldCheck,
  Palette,
  FileText,
} from 'lucide-react';
import { UserSettings, PaperTone, RulingType } from '../types/diary';

interface VaultSettingsSpreadProps {
  settings: UserSettings;
  onSaveSettings: (settings: UserSettings) => void;
  onExportData: () => void;
  onImportData: (e: React.ChangeEvent<HTMLInputElement>) => void;
  paperToneClass: string;
}

export const VaultSettingsSpread: React.FC<VaultSettingsSpreadProps> = ({
  settings,
  onSaveSettings,
  onExportData,
  onImportData,
  paperToneClass,
}) => {
  const [pinInput, setPinInput] = useState(settings.pinCode || '');
  const [isChangingPin, setIsChangingPin] = useState(false);
  const [pinError, setPinError] = useState('');

  const handleToggleLock = () => {
    if (!settings.isLocked) {
      if (!pinInput || pinInput.length < 4) {
        setPinError('Please set a 4-digit PIN code first.');
        setIsChangingPin(true);
        return;
      }
      onSaveSettings({ ...settings, isLocked: true, pinCode: pinInput });
      setPinError('');
    } else {
      onSaveSettings({ ...settings, isLocked: false });
    }
  };

  const handleSavePin = (e: React.FormEvent) => {
    e.preventDefault();
    if (pinInput.length !== 4) {
      setPinError('PIN must be exactly 4 digits.');
      return;
    }
    onSaveSettings({ ...settings, pinCode: pinInput, isLocked: true });
    setIsChangingPin(false);
    setPinError('');
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="w-full h-full flex flex-col md:flex-row divide-y md:divide-y-0 md:divide-x divide-stone-300/60 overflow-hidden">
      {/* LEFT PAGE: Privacy Vault & Aesthetic Preferences */}
      <div className={`flex-1 flex flex-col h-full relative ${paperToneClass} book-spine-left p-6 sm:p-8 select-none overflow-y-auto`}>
        {/* Header */}
        <div className="border-b border-stone-200/80 pb-3 mb-4">
          <span className="text-[11px] font-sans font-medium uppercase tracking-widest text-stone-500 block">
            Security & Customization
          </span>
          <h2 className="font-serif text-2xl font-medium text-stone-900 mt-0.5">
            The Journal Vault
          </h2>
        </div>

        {/* Author / Journal Owner */}
        <div className="mb-5 pb-4 border-b border-stone-200/60">
          <label className="text-xs font-sans font-semibold tracking-wide text-stone-700 uppercase mb-1 block">
            Diary Inscription & Name
          </label>
          <input
            type="text"
            value={settings.authorName}
            onChange={(e) => onSaveSettings({ ...settings, authorName: e.target.value })}
            placeholder="Your name or monogram..."
            className="w-full text-sm font-serif p-2 bg-[#f4efe5]/60 border border-stone-300 rounded-md text-stone-800 focus:outline-hidden focus:border-amber-700"
          />
        </div>

        {/* Passcode Lock */}
        <div className="mb-5 pb-4 border-b border-stone-200/60">
          <div className="flex items-center justify-between mb-2">
            <div>
              <span className="text-xs font-sans font-semibold tracking-wide text-stone-700 uppercase block">
                Passcode Lock
              </span>
              <p className="text-[11px] text-stone-500">
                Require a 4-digit PIN before opening your private diary
              </p>
            </div>
            <button
              onClick={handleToggleLock}
              className={`p-2 rounded-md transition-colors ${
                settings.isLocked
                  ? 'bg-amber-900 text-white'
                  : 'bg-stone-200 text-stone-700 hover:bg-stone-300'
              }`}
            >
              {settings.isLocked ? <Lock className="w-4 h-4" /> : <Unlock className="w-4 h-4" />}
            </button>
          </div>

          {(isChangingPin || !settings.pinCode) && (
            <form onSubmit={handleSavePin} className="mt-2 p-2.5 bg-stone-100/70 border border-stone-200 rounded-lg">
              <span className="text-[11px] text-stone-600 block mb-1">Set 4-Digit Security PIN:</span>
              <div className="flex items-center gap-2">
                <input
                  type="password"
                  maxLength={4}
                  value={pinInput}
                  onChange={(e) => setPinInput(e.target.value.replace(/\D/g, ''))}
                  placeholder="0000"
                  className="w-24 text-center font-mono text-base tracking-widest p-1 bg-white border border-stone-300 rounded"
                />
                <button
                  type="submit"
                  className="px-3 py-1 text-xs bg-stone-800 text-white rounded hover:bg-stone-900"
                >
                  Save PIN
                </button>
              </div>
              {pinError && <p className="text-[10px] text-red-600 mt-1">{pinError}</p>}
            </form>
          )}

          {settings.isLocked && !isChangingPin && (
            <div className="flex items-center justify-between text-xs text-stone-600 mt-1">
              <span>Status: <strong className="text-emerald-800">Protected</strong></span>
              <button
                onClick={() => setIsChangingPin(true)}
                className="text-[11px] text-amber-900 hover:underline"
              >
                Change PIN
              </button>
            </div>
          )}
        </div>

        {/* Hardcover Theme Selection (Dark & Pastel Mix) */}
        <div className="mb-4 pb-4 border-b border-stone-200/60">
          <span className="text-xs font-sans font-semibold tracking-wide text-stone-700 uppercase mb-2 block flex items-center gap-1.5">
            <Palette className="w-3.5 h-3.5 text-stone-500" />
            <span>Hardcover Palette (Dark &amp; Pastel)</span>
          </span>
          <div className="space-y-2">
            <div>
              <span className="text-[10px] uppercase font-sans font-semibold tracking-wider text-stone-400 block mb-1">
                Deep Elegance
              </span>
              <div className="grid grid-cols-3 gap-1.5">
                {[
                  { id: 'sage', name: 'Forest Sage', color: '#2b3b2e' },
                  { id: 'espresso', name: 'Espresso Noir', color: '#2d2018' },
                  { id: 'navy', name: 'Midnight Navy', color: '#1b2636' },
                  { id: 'terracotta', name: 'Terracotta', color: '#6c3422' },
                  { id: 'charcoal', name: 'Charcoal', color: '#252525' },
                  { id: 'plum', name: 'Velvet Plum', color: '#3c1f2b' },
                ].map((theme) => (
                  <button
                    key={theme.id}
                    onClick={() => onSaveSettings({ ...settings, coverTheme: theme.id as any })}
                    className={`p-1.5 rounded-md border flex items-center gap-1.5 transition-all ${
                      settings.coverTheme === theme.id
                        ? 'border-amber-800 ring-1 ring-amber-800 font-semibold bg-amber-50/50'
                        : 'border-stone-200 hover:border-stone-300'
                    }`}
                  >
                    <span
                      className="w-3 h-3 rounded-full border border-stone-300 shrink-0"
                      style={{ backgroundColor: theme.color }}
                    />
                    <span className="text-[11px] text-stone-800 truncate">{theme.name}</span>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <span className="text-[10px] uppercase font-sans font-semibold tracking-wider text-stone-400 block mb-1">
                Soft Pastels
              </span>
              <div className="grid grid-cols-3 gap-1.5">
                {[
                  { id: 'pastel_matcha', name: 'Matcha Mint', color: '#cfded0' },
                  { id: 'pastel_rose', name: 'Blush Rose', color: '#fae2e6' },
                  { id: 'pastel_lavender', name: 'Lavender', color: '#ded7e8' },
                  { id: 'pastel_peach', name: 'Peach', color: '#fce8dd' },
                  { id: 'pastel_sky', name: 'Cloud Sky', color: '#e0ecf7' },
                  { id: 'ivory', name: 'Alabaster', color: '#f5efe6' },
                ].map((theme) => (
                  <button
                    key={theme.id}
                    onClick={() => onSaveSettings({ ...settings, coverTheme: theme.id as any })}
                    className={`p-1.5 rounded-md border flex items-center gap-1.5 transition-all ${
                      settings.coverTheme === theme.id
                        ? 'border-amber-800 ring-1 ring-amber-800 font-semibold bg-amber-50/50'
                        : 'border-stone-200 hover:border-stone-300'
                    }`}
                  >
                    <span
                      className="w-3 h-3 rounded-full border border-stone-300 shrink-0"
                      style={{ backgroundColor: theme.color }}
                    />
                    <span className="text-[11px] text-stone-800 truncate">{theme.name}</span>
                  </button>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Paper Tone Selection */}
        <div className="mb-4">
          <span className="text-xs font-sans font-semibold tracking-wide text-stone-700 uppercase mb-2 block flex items-center gap-1.5">
            <Palette className="w-3.5 h-3.5 text-stone-500" />
            <span>Paper Tone</span>
          </span>
          <div className="grid grid-cols-2 gap-2">
            {(
              [
                { id: 'cream', name: 'Warm Cream', bg: '#fdfbf7' },
                { id: 'chamois', name: 'Soft Chamois', bg: '#fbf7ee' },
                { id: 'linen', name: 'Antique Linen', bg: '#f6f3eb' },
                { id: 'sage', name: 'Quiet Sage', bg: '#f4f6f2' },
              ] as const
            ).map((tone) => (
              <button
                key={tone.id}
                onClick={() => onSaveSettings({ ...settings, paperTone: tone.id })}
                className={`p-2 rounded-md border flex items-center gap-2 transition-all ${
                  settings.paperTone === tone.id
                    ? 'border-amber-800 ring-1 ring-amber-800 font-semibold'
                    : 'border-stone-200 hover:border-stone-300'
                }`}
                style={{ backgroundColor: tone.bg }}
              >
                <span className="w-3 h-3 rounded-full border border-stone-300 shrink-0" />
                <span className="text-xs text-stone-800">{tone.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Left Page Footer */}
        <div className="mt-auto pt-2 border-t border-stone-200/60 flex items-center justify-between text-[11px] text-stone-400 font-serif">
          <span>Vault Preferences</span>
          <span>p. 12</span>
        </div>
      </div>

      {/* RIGHT PAGE: Paper Ruling, Sounds, Backup & Export */}
      <div className={`flex-1 flex flex-col h-full relative ${paperToneClass} book-spine-right p-6 sm:p-8 select-none overflow-y-auto`}>
        {/* Header */}
        <div className="border-b border-stone-200/80 pb-3 mb-4">
          <span className="text-[11px] font-sans font-medium uppercase tracking-widest text-stone-500 block">
            Atmosphere & Archival
          </span>
          <h2 className="font-serif text-2xl font-medium text-stone-900 mt-0.5">
            Export & Sensory Tuning
          </h2>
        </div>

        {/* Paper Ruling Style */}
        <div className="mb-5 pb-4 border-b border-stone-200/60">
          <span className="text-xs font-sans font-semibold tracking-wide text-stone-700 uppercase mb-2 block flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5 text-stone-500" />
            <span>Page Texture Ruling</span>
          </span>
          <div className="grid grid-cols-3 gap-2">
            {(
              [
                { id: 'ruled', label: 'Classic Ruled' },
                { id: 'dotted', label: 'Dotted Grid' },
                { id: 'blank', label: 'Plain Parchment' },
              ] as const
            ).map((r) => (
              <button
                key={r.id}
                onClick={() => onSaveSettings({ ...settings, rulingType: r.id })}
                className={`py-2 px-1 text-center text-xs rounded-md border transition-all ${
                  settings.rulingType === r.id
                    ? 'bg-amber-900 text-white border-amber-900 font-medium'
                    : 'bg-stone-100/60 text-stone-700 border-stone-200 hover:bg-stone-200/60'
                }`}
              >
                {r.label}
              </button>
            ))}
          </div>
        </div>

        {/* Ambient Sounds Toggle */}
        <div className="mb-5 pb-4 border-b border-stone-200/60 flex items-center justify-between">
          <div>
            <span className="text-xs font-sans font-semibold tracking-wide text-stone-700 uppercase block">
              Sensory Audio Whispers
            </span>
            <p className="text-[11px] text-stone-500">
              Gentle paper rustle on page turn & soft pen stroke chimes
            </p>
          </div>
          <button
            onClick={() => onSaveSettings({ ...settings, audioEnabled: !settings.audioEnabled })}
            className={`p-2 rounded-md transition-colors ${
              settings.audioEnabled
                ? 'bg-amber-900 text-white'
                : 'bg-stone-200 text-stone-700 hover:bg-stone-300'
            }`}
          >
            {settings.audioEnabled ? <Volume2 className="w-4 h-4" /> : <VolumeX className="w-4 h-4" />}
          </button>
        </div>

        {/* Backup, Import & Print */}
        <div className="space-y-2.5">
          <span className="text-xs font-sans font-semibold tracking-wide text-stone-700 uppercase block">
            Archival & Backup
          </span>

          <button
            onClick={onExportData}
            className="w-full py-2.5 px-3 bg-[#ede6d8] hover:bg-[#e4dcce] text-stone-800 text-xs font-medium rounded-md transition-colors flex items-center justify-center gap-2 border border-stone-300"
          >
            <Download className="w-3.5 h-3.5 text-amber-900" />
            <span>Export Complete Journal Backup (JSON)</span>
          </button>

          <label className="w-full py-2.5 px-3 bg-[#ede6d8] hover:bg-[#e4dcce] text-stone-800 text-xs font-medium rounded-md transition-colors flex items-center justify-center gap-2 border border-stone-300 cursor-pointer">
            <Upload className="w-3.5 h-3.5 text-amber-900" />
            <span>Restore From Backup File</span>
            <input type="file" accept=".json" onChange={onImportData} className="hidden" />
          </label>

          <button
            onClick={handlePrint}
            className="w-full py-2.5 px-3 bg-stone-900 hover:bg-stone-800 text-white text-xs font-medium rounded-md transition-colors flex items-center justify-center gap-2"
          >
            <Printer className="w-3.5 h-3.5 text-amber-300" />
            <span>Print Current Spread</span>
          </button>
        </div>

        {/* Right Page Footer */}
        <div className="mt-auto pt-2 border-t border-stone-200/60 flex items-center justify-between text-[11px] text-stone-400 font-serif">
          <span>Archival Engine</span>
          <span>p. 13</span>
        </div>
      </div>
    </div>
  );
};
